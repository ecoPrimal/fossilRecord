# Handler Trait Consolidation Plan

**Date**: October 1, 2025  
**Status**: Ready for execution  
**Findings**: Better than expected - minimal work needed

---

## 📊 AUDIT FINDINGS

### Handler Traits Found: 22 references

#### ✅ ALREADY CONSOLIDATED
- **CommandHandler**: Already deprecated in 2 locations pointing to `CanonicalCommandHandler` ✅
- **CanonicalCommandHandler**: Properly established in `universal-patterns/src/traits/ai_traits.rs` ✅

#### 🔄 NEED CONSOLIDATION (EventHandler variants)

**EventHandler Definitions:**
1. `crates/main/src/communication/events.rs` - `EventHandler<T: Send + Sync + 'static>`
2. `crates/main/src/communication/mod.rs` - `EventHandler: Send + Sync`
3. `crates/main/src/events.rs` - `UniversalEventHandler: Send + Sync`

**Analysis**: These appear to be:
- Generic parameterized version (events.rs)
- Simple non-generic version (mod.rs)
- Universal domain-specific version (events.rs)

**Decision**: 
- Keep generic `EventHandler<T>` as the canonical version
- Deprecate simple `EventHandler` → point to `EventHandler<Event>`
- Keep `UniversalEventHandler` (domain-specific for universal events)

#### ✅ DOMAIN-SPECIFIC (KEEP AS-IS)
These are legitimate domain-specific handlers that should NOT be consolidated:

1. `AlertHandler` - `main/src/monitoring/production_monitoring.rs` ✅
2. `ShutdownHandler` - `main/src/shutdown.rs` ✅
3. `ZeroCostHandler` - `main/src/zero_cost_traits.rs` ✅
4. `LocalServiceHandler` - `ecosystem-api/src/universal_adapter/handlers.rs` ✅
5. `FallbackHandler` - `ecosystem-api/src/universal_adapter/sovereignty/manager.rs` ✅
6. `CanonicalHandler` - `canonical-modernization/src/trait_modernization.rs` ✅

---

## 🎯 CONSOLIDATION ACTIONS

### Action 1: Create CanonicalEventHandler (Optional)
**Decision**: The current EventHandler<T> is already well-designed. 

**Recommendation**: Add a type alias for convenience:
```rust
// In universal-patterns/src/traits/core_traits.rs or events.rs
pub type CanonicalEventHandler<T> = EventHandler<T>;
```

### Action 2: Deprecate Non-Generic EventHandler
**Location**: `crates/main/src/communication/mod.rs`

**Change**:
```rust
#[deprecated(since = "4.2.0", note = "Use EventHandler<Event> from communication::events instead")]
pub trait EventHandler: Send + Sync {
    // ...
}
```

### Action 3: Document Handler Pattern
Create documentation explaining when to create new handlers vs. use existing ones.

---

## 📝 ASSESSMENT

**Result**: Handler traits are actually in EXCELLENT shape!
- ✅ CommandHandler already properly deprecated
- ✅ Most handlers are legitimate domain-specific traits
- ✅ Only 1 minor consolidation needed (EventHandler in mod.rs)

**Time Required**: 15 minutes (much less than expected!)

---

## ✅ CONCLUSION

The handler trait situation is **much better organized than initially assessed**. The apparent "25+ handler traits" were mostly:
- Re-exports and type aliases (counted multiple times)
- Deprecation warnings (already handled)
- Legitimate domain-specific handlers

**Actual work needed**: Minimal - just add one deprecation warning. 