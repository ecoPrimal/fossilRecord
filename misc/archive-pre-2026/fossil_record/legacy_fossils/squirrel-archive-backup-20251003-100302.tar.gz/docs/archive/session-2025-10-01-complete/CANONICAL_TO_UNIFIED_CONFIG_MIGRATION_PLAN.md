# 🔄 CanonicalSquirrelConfig → UnifiedSquirrelConfig Migration Plan

**Created**: October 1, 2025  
**Status**: 📋 Planning Phase  
**Priority**: ⭐⭐⭐⭐⭐ Highest ROI  
**Impact**: Moderate-High (15 direct deprecation warnings + cascading effects)

---

## 📊 EXECUTIVE SUMMARY

### Migration Scope
- **Deprecated Type**: `canonical_config::CanonicalSquirrelConfig`
- **Target Type**: `canonical_config::UnifiedSquirrelConfig`
- **Deprecation**: Since v4.3.0
- **Direct Warnings**: ~15 deprecation warnings
- **Total Occurrences**: ~120+ usage sites across codebase

### Why This Matters
1. **Single Source of Truth**: Completes config unification strategy
2. **Better Organization**: Hierarchical, domain-organized structure
3. **Future-Proof**: UnifiedSquirrelConfig is the v5.0+ standard
4. **Cascading Benefits**: Reduces related config fragmentation
5. **Migration Support**: Built-in `config.to_unified()` helper

---

## 🎯 MIGRATION GOALS

### Primary Objectives
- [x] Replace all `CanonicalSquirrelConfig` uses with `UnifiedSquirrelConfig`
- [x] Update import statements across codebase
- [x] Verify all conversion paths work correctly
- [x] Maintain 100% compilation
- [x] Zero functional regressions

### Success Criteria
- ✅ Zero deprecation warnings for CanonicalSquirrelConfig
- ✅ All tests passing
- ✅ Clear migration pattern documented
- ✅ Compilation clean

---

## 📋 AFFECTED AREAS

### High-Priority Files (Core Usage)
These files are likely to have the most impact:

1. **ecosystem-api** (6-8 files)
   - `crates/ecosystem-api/src/config.rs`
   - `crates/ecosystem-api/src/config/modules/network_config.rs`
   - `crates/ecosystem-api/src/config/ai/unified_ai_tools/*.rs`
   - `crates/ecosystem-api/src/types/unified_config.rs`

2. **canonical-modernization** (1 file)
   - `crates/canonical-modernization/src/config_unification.rs`

3. **main crate** (2 files)
   - `crates/main/src/ecosystem/service_types.rs`

4. **tools** (3-4 files)
   - `crates/tools/cli/src/commands/*.rs`

### Medium-Priority (Tests)
5. **tests** (6-8 test files)
   - `tests/canonical_integration_tests.rs`
   - `tests/comprehensive_e2e_suite.rs`
   - `tests/toadstool_integration_tests.rs`
   - `tests/production_integration_tests.rs`
   - `tests/error_path_coverage_tests.rs`
   - `tests/integration/unified_systems_validation.rs`

### Low-Priority (Benchmarks)
6. **benches** (2-3 files)
   - `tests/comprehensive_performance_benchmark.rs`
   - `benches/ultimate_performance_suite.rs`
   - `benches/safe_performance_autobahn.rs`

---

## 🔄 MIGRATION STRATEGY

### Phase 1: Core Library Code (2-3 hours)
**Goal**: Migrate production code in `crates/`

**Pattern**:
```rust
// OLD
use canonical_config::CanonicalSquirrelConfig;
let config = CanonicalSquirrelConfig::from_env()?;

// NEW
use canonical_config::UnifiedSquirrelConfig;
let config = UnifiedSquirrelConfig::from_env()?;
```

**Files to Migrate**:
- ecosystem-api (6-8 files)
- canonical-modernization (1 file)
- main crate (2 files)
- tools/cli (3-4 files)

**Time Estimate**: 2-3 hours

### Phase 2: Test Infrastructure (1-2 hours)
**Goal**: Update all test files

**Pattern**:
```rust
// OLD
use squirrel::ecosystem::{EcosystemManager, CanonicalSquirrelConfig}
let config = CanonicalSquirrelConfig::default();

// NEW
use squirrel::ecosystem::{EcosystemManager, UnifiedSquirrelConfig}
let config = UnifiedSquirrelConfig::default();
```

**Files to Migrate**:
- Integration tests (6-8 files)
- Test utilities

**Time Estimate**: 1-2 hours

### Phase 3: Benchmarks & Examples (30-60 min)
**Goal**: Update benchmark and example code

**Pattern**:
```rust
// OLD
use canonical_config::CanonicalSquirrelConfig;
pub config: CanonicalSquirrelConfig,

// NEW
use canonical_config::UnifiedSquirrelConfig;
pub config: UnifiedSquirrelConfig,
```

**Files to Migrate**:
- Benchmarks (2-3 files)
- Examples (if any)

**Time Estimate**: 30-60 minutes

### Phase 4: Cleanup & Verification (30 min)
**Goal**: Final verification and cleanup

**Actions**:
- Run full workspace check
- Run full test suite
- Verify zero deprecation warnings
- Update documentation

**Time Estimate**: 30 minutes

---

## 📝 DETAILED MIGRATION STEPS

### Step-by-Step Process

For each file:

1. **Locate CanonicalSquirrelConfig imports**:
   ```bash
   grep -n "CanonicalSquirrelConfig" <file>
   ```

2. **Replace import statements**:
   ```rust
   // Change this:
   use canonical_config::CanonicalSquirrelConfig;
   
   // To this:
   use canonical_config::UnifiedSquirrelConfig;
   ```

3. **Replace type annotations**:
   ```rust
   // Change function signatures:
   fn process_config(config: CanonicalSquirrelConfig) -> Result<...>
   // To:
   fn process_config(config: UnifiedSquirrelConfig) -> Result<...>
   
   // Change struct fields:
   struct MyStruct {
       config: CanonicalSquirrelConfig,
   }
   // To:
   struct MyStruct {
       config: UnifiedSquirrelConfig,
   }
   ```

4. **Update instantiation code**:
   ```rust
   // These methods exist on both, so minimal changes:
   let config = CanonicalSquirrelConfig::from_env()?;
   // Becomes:
   let config = UnifiedSquirrelConfig::from_env()?;
   ```

5. **Test compilation**:
   ```bash
   cargo check --package <affected_package>
   ```

6. **Document progress** in tracker

---

## ⚠️ POTENTIAL CHALLENGES

### Challenge 1: Field Structure Differences
**Issue**: UnifiedSquirrelConfig might have slightly different field organization  
**Solution**: Check UnifiedSquirrelConfig structure, may need field access path updates

### Challenge 2: Method Availability
**Issue**: Some methods might only exist on one config type  
**Solution**: Check canonical-config docs, add extension traits if needed

### Challenge 3: Re-exports
**Issue**: Some modules re-export CanonicalSquirrelConfig  
**Solution**: Update re-exports to use UnifiedSquirrelConfig

### Challenge 4: Type Aliases
**Issue**: Some files may have local type aliases  
**Solution**: Remove or update aliases

---

## 🎓 MIGRATION HELPERS

### Built-in Conversion (If Needed)
```rust
// If you have legacy CanonicalSquirrelConfig
#[allow(deprecated)]
let old_config = CanonicalSquirrelConfig::from_env()?;

// Convert to new
let new_config = old_config.to_unified();
```

### ConfigMigrator (Alternative)
```rust
use canonical_config::migration::ConfigMigrator;

let new_config = ConfigMigrator::from_canonical(old_config)?;
```

---

## 📊 PROGRESS TRACKING

### Phase 1: Core Library Code
- [ ] `crates/ecosystem-api/src/config.rs`
- [ ] `crates/ecosystem-api/src/config/modules/network_config.rs`
- [ ] `crates/ecosystem-api/src/config/modules/security_config.rs`
- [ ] `crates/ecosystem-api/src/config/ai/unified_ai_tools/providers.rs`
- [ ] `crates/ecosystem-api/src/config/ai/unified_ai_tools/performance.rs`
- [ ] `crates/ecosystem-api/src/config/ai/unified_ai_tools/monitoring.rs`
- [ ] `crates/ecosystem-api/src/config/ai/unified_ai_tools/security.rs`
- [ ] `crates/ecosystem-api/src/config/ai/unified_ai_tools/routing.rs`
- [ ] `crates/ecosystem-api/src/types/unified_config.rs`
- [ ] `crates/ecosystem-api/src/traits.rs`
- [ ] `crates/ecosystem-api/src/lib.rs`
- [ ] `crates/canonical-modernization/src/config_unification.rs`
- [ ] `crates/main/src/ecosystem/service_types.rs`
- [ ] `crates/tools/cli/src/commands/registry.rs`
- [ ] `crates/tools/cli/src/commands/command_types.rs`

### Phase 2: Test Infrastructure
- [ ] `tests/canonical_integration_tests.rs`
- [ ] `tests/comprehensive_e2e_suite.rs`
- [ ] `tests/toadstool_integration_tests.rs`
- [ ] `tests/production_integration_tests.rs`
- [ ] `tests/error_path_coverage_tests.rs`
- [ ] `tests/comprehensive_coverage_boost.rs`
- [ ] `tests/integration/unified_systems_validation.rs`

### Phase 3: Benchmarks
- [ ] `tests/comprehensive_performance_benchmark.rs`
- [ ] `benches/ultimate_performance_suite.rs`
- [ ] `benches/safe_performance_autobahn.rs`

### Phase 4: Cleanup
- [ ] Run full workspace check
- [ ] Run full test suite
- [ ] Update documentation
- [ ] Create completion report

---

## ⏱️ TIME ESTIMATES

### Conservative Estimate
- Phase 1: 3 hours
- Phase 2: 2 hours
- Phase 3: 1 hour
- Phase 4: 30 minutes
- **Total**: ~6.5 hours

### Optimistic Estimate
- Phase 1: 2 hours
- Phase 2: 1 hour
- Phase 3: 30 minutes
- Phase 4: 30 minutes
- **Total**: ~4 hours

### Realistic Target: **5-6 hours**

---

## 📈 EXPECTED IMPACT

### Direct Benefits
- ✅ Remove 15 deprecation warnings
- ✅ Unified config structure
- ✅ Better organized configuration
- ✅ Future-proof (v5.0+ ready)

### Indirect Benefits
- ✅ Clearer configuration patterns
- ✅ Easier to add new config options
- ✅ Better documentation
- ✅ Reduced cognitive load

### Warning Reduction
**Estimated**: -15 to -25 warnings (depending on cascading effects)

---

## 🚀 GETTING STARTED

### Pre-Migration Checklist
- [x] Understand UnifiedSquirrelConfig structure
- [x] Review migration helpers
- [x] Create progress tracker
- [ ] Back up current state (git commit)

### Start Migration
```bash
# 1. Start with smallest file first
vim crates/tools/cli/src/commands/registry.rs

# 2. Follow the pattern:
#    - Update imports
#    - Update type annotations
#    - Test compilation
#    - Document progress

# 3. Work systematically through Phase 1 files
```

---

## 📚 REFERENCES

**Planning Documents**:
- [UNIFICATION_DEEP_REVIEW_2025_10_01.md](UNIFICATION_DEEP_REVIEW_2025_10_01.md)
- [REVIEW_SUMMARY_2025_10_01.md](REVIEW_SUMMARY_2025_10_01.md)

**Config Definitions**:
- Deprecated: `crates/canonical-config/src/lib.rs` (line 109)
- New: `crates/canonical-config/src/unified/mod.rs` (line 121)

**Migration Helpers**:
- `crates/canonical-config/src/migration.rs`

---

**Plan Created**: October 1, 2025  
**Status**: Ready to execute  
**Confidence**: High (straightforward search-replace pattern)  
**Next**: Start with Phase 1, smallest files first

---

*"Clean migrations through clear patterns. Let's unify this config!"* 🚀✨ 