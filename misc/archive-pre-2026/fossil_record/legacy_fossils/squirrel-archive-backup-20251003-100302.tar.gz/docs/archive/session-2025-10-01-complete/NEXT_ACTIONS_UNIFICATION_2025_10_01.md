# 🎯 Next Actions: Unification Completion
## October 1, 2025 - Action Plan

**Current Status**: 96% Unified, 83 warnings, 100% compiling  
**Target**: 98% Unified, 0 warnings  
**Estimated Remaining**: 26-39 hours

---

## 📊 QUICK STATUS

✅ **What's Done** (Celebrate these wins!):
- ✅ 84% warning reduction (522 → 83)
- ✅ HealthCheckConfig consolidated (14 → 1)
- ✅ Production config migrated (100%)
- ✅ All files under 2000 lines
- ✅ 100% compilation success

🎯 **What Remains**:
- 🔧 83 deprecation warnings (systematic cleanup)
- 🔧 Result type aliases (14 different aliases)
- 🔧 Type aliases (10+ types)
- 🔧 Config test migration (6-8 files)
- 🔧 15 TODO comments (optional)

---

## 🚀 PHASE 1: QUICK WINS (10-15 hours) ⭐⭐⭐⭐⭐

**Expected Impact**: Eliminate ~75% of remaining warnings!

### Action 1A: Result Type Alias Cleanup (8-12h, ~45 warnings)

**What**: Replace deprecated `XxxResult<T>` with `CanonicalResult<T>`

**Aliases to Fix** (14 total):
```rust
AIResult<T>              → CanonicalResult<T>
CLIResult<T>             → CanonicalResult<T>
MCPResult<T>             → CanonicalResult<T>
SquirrelResult<T>        → CanonicalResult<T>
ToadstoolResult<T>       → CanonicalResult<T>
CommandResult<T>         → CanonicalResult<T>
EventResult<T>           → CanonicalResult<T>
MainResult<T>            → CanonicalResult<T>
ConsensusResult<T>       → CanonicalResult<T>
ZeroToleranceResult<T>   → CanonicalResult<T>
PrimalResult<T>          → CanonicalResult<T>
ProductionResult<T>      → CanonicalResult<T>
CapabilityResult<T>      → CanonicalResult<T>
TrackingResult<T>        → CanonicalResult<T>
```

**Method**: Systematic search-replace
```bash
# For each alias:
rg "AIResult<" --files-with-matches | \
  xargs sed -i 's/AIResult</CanonicalResult</g'

# Also update type definitions:
rg "AIResult<" --files-with-matches | \
  xargs sed -i 's/: AIResult</: CanonicalResult</g'

# Verify after each:
cargo check --workspace

# Track: Mark off each alias as you complete it
```

**Order of operations** (easiest to hardest):
1. `AIResult` (simple, well-isolated)
2. `CLIResult` (simple)
3. `ToadstoolResult` (simple)
4. `ProductionResult` (simple)
5. `MainResult` (medium)
6. `SquirrelResult` (medium)
7. `EventResult` (medium)
8. `CommandResult` (medium - may have conflicts)
9. `MCPResult` (medium - check for local Result aliases)
10. Rest (easier ones)

---

### Action 1B: Type Alias Cleanup (6-8h, ~25 warnings)

**What**: Replace deprecated type aliases with `Canonical*` versions

**Aliases to Fix** (10+ types):
```rust
ServiceInfo           → CanonicalServiceInfo
ServiceQuery          → CanonicalServiceQuery
HealthStatus          → CanonicalHealthStatus
HealthInfo            → CanonicalHealthInfo
AIRequest             → CanonicalAIRequest
AIResponse            → CanonicalAIResponse
AIStreamResponse      → CanonicalAIStreamResponse
PrimalInfo            → CanonicalPrimalInfo
PrimalRequest         → CanonicalPrimalRequest
PrimalResponse        → CanonicalPrimalResponse
```

**Method**: Same as Result aliases
```bash
rg "ServiceInfo" --files-with-matches | \
  xargs sed -i 's/ServiceInfo/CanonicalServiceInfo/g'

cargo check --workspace
```

---

### Action 1C: Config Re-export Cleanup (2-3h, ~12 warnings)

**What**: Remove deprecated config re-exports

**Files to update**:
```rust
crates/universal-patterns/src/config/mod.rs
crates/universal-patterns/src/config/types.rs
```

**Method**:
1. Find all usages of re-exported config types
2. Update to direct imports
3. Remove re-export lines
4. Verify compilation

---

## 🔧 PHASE 2: STRUCTURAL CLEANUP (8-12 hours) ⭐⭐⭐⭐

### Action 2A: Complete Config Migration (4-6h)

**Test Files** (6-8 files):
```
tests/comprehensive_performance_benchmark.rs
tests/comprehensive_coverage_boost.rs
tests/toadstool_integration_tests.rs
tests/production_integration_tests.rs
tests/error_path_coverage_tests.rs
tests/canonical_integration_tests.rs
tests/comprehensive_e2e_suite.rs
```

**Benchmark Files** (2-3 files):
```
benches/ultimate_performance_suite.rs
benches/safe_performance_autobahn.rs
tests/comprehensive_performance_benchmark.rs
```

**Method**: For each file:
```rust
// Change:
use canonical_config::CanonicalSquirrelConfig;
let config = CanonicalSquirrelConfig::default();

// To:
use canonical_config::UnifiedSquirrelConfig;
let config = UnifiedSquirrelConfig::default();
```

---

### Action 2B: Adapter Layer Audit (3-5h)

**Files to review**:
```
crates/main/src/universal/adapter.rs (29 lines)
crates/main/src/universal/mod.rs (90 lines)
crates/adapter-pattern-tests/src/lib.rs
```

**Method**:
1. Identify all usages of re-exported adapter names
2. Update to direct canonical imports
3. Decision: Remove or keep as intentional facade
4. Document decision

---

### Action 2C: Final Verification (1h)

```bash
# Check warnings
cargo check --workspace 2>&1 | grep -c "warning:"
# Target: 0

# Run tests
cargo test --workspace

# Run benchmarks
cargo bench --workspace

# Update STATUS.md
```

---

## ✨ PHASE 3: POLISH (Optional, 8-12 hours) ⭐⭐⭐

### Action 3A: TODO Resolution (5-8h)

**Priority TODOs** (only if time permits):
1. `service-discovery/src/lib.rs:26` - Unify config
2. `core/mcp/src/protocol/production_handler.rs:65` - Remove shim
3. AI tools capabilities (optional feature work)

---

## 📈 TRACKING PROGRESS

### Phase 1 Checklist: Result Aliases
- [ ] AIResult → CanonicalResult
- [ ] CLIResult → CanonicalResult
- [ ] ToadstoolResult → CanonicalResult
- [ ] ProductionResult → CanonicalResult
- [ ] MainResult → CanonicalResult
- [ ] SquirrelResult → CanonicalResult
- [ ] EventResult → CanonicalResult
- [ ] CommandResult → CanonicalResult
- [ ] MCPResult → CanonicalResult
- [ ] ConsensusResult → CanonicalResult
- [ ] ZeroToleranceResult → CanonicalResult
- [ ] PrimalResult → CanonicalResult
- [ ] CapabilityResult → CanonicalResult
- [ ] TrackingResult → CanonicalResult

**After each**: Run `cargo check`, track warnings

---

### Phase 1 Checklist: Type Aliases
- [ ] ServiceInfo → CanonicalServiceInfo
- [ ] ServiceQuery → CanonicalServiceQuery
- [ ] HealthStatus → CanonicalHealthStatus
- [ ] HealthInfo → CanonicalHealthInfo
- [ ] AIRequest → CanonicalAIRequest
- [ ] AIResponse → CanonicalAIResponse
- [ ] AIStreamResponse → CanonicalAIStreamResponse
- [ ] PrimalInfo → CanonicalPrimalInfo
- [ ] PrimalRequest → CanonicalPrimalRequest
- [ ] PrimalResponse → CanonicalPrimalResponse

---

### Phase 2 Checklist: Config Migration
- [ ] tests/comprehensive_performance_benchmark.rs
- [ ] tests/comprehensive_coverage_boost.rs
- [ ] tests/toadstool_integration_tests.rs
- [ ] tests/production_integration_tests.rs
- [ ] tests/error_path_coverage_tests.rs
- [ ] tests/canonical_integration_tests.rs
- [ ] benches/ultimate_performance_suite.rs
- [ ] benches/safe_performance_autobahn.rs

---

## 🎯 SUCCESS METRICS

**Track after each session**:
```bash
# Warning count
cargo check --workspace 2>&1 | grep -c "warning:"

# Update this table:
```

| Date | Warnings | Phase | Time Spent | Notes |
|------|----------|-------|------------|-------|
| Oct 1 | 83 | Baseline | - | After HealthCheckConfig |
| Oct X | ? | 1A Started | ?h | Result aliases |
| ... | ... | ... | ... | ... |

---

## 💡 TIPS & BEST PRACTICES

### Before Starting Each Session
1. ✅ `git commit` - Save current state
2. ✅ `cargo check --workspace` - Verify starting state
3. ✅ Count warnings: `cargo check --workspace 2>&1 | grep -c "warning:"`
4. ✅ Choose ONE alias/type to work on

### During Work
1. ✅ Work on ONE alias at a time
2. ✅ Test after each change: `cargo check --workspace`
3. ✅ If errors appear, fix immediately
4. ✅ Track progress in checklist

### After Each Session
1. ✅ `git commit -m "feat: Migrate XxxResult to CanonicalResult"`
2. ✅ Update STATUS.md with new warning count
3. ✅ Update this document's progress tracking
4. ✅ Celebrate the wins! 🎉

---

## 🚨 TROUBLESHOOTING

### If you see compilation errors:
```bash
# Pattern 1: Missing imports
# Fix: Add canonical_errors::CanonicalResult import

# Pattern 2: Type conflicts
# Fix: Use fully qualified paths: canonical_errors::CanonicalResult

# Pattern 3: Generic conflicts
# Fix: Check for local Result<T> type aliases that shadow
```

### If warnings don't decrease:
1. Check you're updating both type definitions AND usages
2. Search for patterns like `: XxxResult<` not just `XxxResult<`
3. Check for re-exports that need updating

---

## 📚 REFERENCE COMMANDS

```bash
# Count warnings
cargo check --workspace 2>&1 | grep -c "warning:"

# Find all usages of an alias
rg "AIResult<" --type rust

# Find files with alias
rg "AIResult<" --files-with-matches --type rust

# Replace in files (use with caution!)
rg "AIResult<" --files-with-matches | \
  xargs sed -i 's/AIResult</CanonicalResult</g'

# Check specific crate
cargo check --package canonical-errors

# Find deprecated items
rg "#\[deprecated" --type rust

# Find TODO comments
rg "TODO:|FIXME:" --type rust
```

---

## 🎉 RECOMMENDED FIRST SESSION

**Start Here** (2-3 hours):

1. **AIResult Migration** (1-1.5h)
   ```bash
   rg "AIResult<" --files-with-matches
   # Update each file
   cargo check --workspace
   ```

2. **CLIResult Migration** (0.5-1h)
   ```bash
   rg "CLIResult<" --files-with-matches
   # Update each file
   cargo check --workspace
   ```

3. **Verify & Commit** (0.5h)
   ```bash
   cargo check --workspace 2>&1 | grep -c "warning:"
   # Should be ~5-10 warnings fewer
   git add -A
   git commit -m "feat: Migrate AIResult and CLIResult to CanonicalResult"
   ```

**Expected Result**: ~5-10 fewer warnings, clean compilation, momentum built!

---

## 🏁 FINAL NOTES

### You're in GREAT shape!
- ✅ Clear path forward
- ✅ Low-risk changes
- ✅ Systematic approach
- ✅ Well-documented codebase

### The finish line is close!
- 🎯 ~26-39 hours remaining
- 🎯 ~83 warnings to eliminate
- 🎯 98% unification target

### You've got this! 💪

---

**Document Created**: October 1, 2025  
**Status**: Ready to execute  
**Next Action**: Pick a session time, start with AIResult migration  

---

*"Rome wasn't built in a day, but they were laying bricks every hour."*  
*Start with one alias. Build momentum. Finish strong!* ✨ 