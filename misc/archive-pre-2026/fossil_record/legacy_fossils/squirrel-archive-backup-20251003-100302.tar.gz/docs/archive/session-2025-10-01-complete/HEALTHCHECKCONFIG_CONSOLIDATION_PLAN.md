# 🏥 HealthCheckConfig Consolidation Plan
**Created**: October 1, 2025  
**Priority**: HIGH  
**Estimated Time**: 8-12 hours  
**Expected Impact**: 30-40% reduction in deprecation warnings

---

## 📋 EXECUTIVE SUMMARY

**Problem**: 15 files contain duplicate HealthCheckConfig struct definitions  
**Solution**: Consolidate to single canonical version in `canonical-config/src/services.rs`  
**Risk**: Medium (extensive usage, careful migration needed)

---

## 🎯 CANONICAL VERSION

### Location
`crates/canonical-config/src/services.rs` (lines 100-150)

### Structure
```rust
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct HealthCheckConfig {
    pub enabled: bool,
    pub interval_seconds: u64,
    pub timeout_seconds: u64,
    pub failure_threshold: u32,
    pub success_threshold: u32,
}
```

### Key Features
- ✅ Has `from_env()` method
- ✅ Has `validate()` method
- ✅ Implements `Default`
- ✅ Serde serialization support
- ✅ Well-documented

---

## 📊 DUPLICATE LOCATIONS (15 files)

Found duplicate HealthCheckConfig definitions in:

1. ✅ `crates/canonical-config/src/services.rs` - **CANONICAL** (keep this!)
2. ❌ `crates/canonical-config/src/capability_based.rs` - **FIXED** (now uses CapabilityHealthCheckConfig)
3. ❌ `crates/core/core/src/routing/agent.rs` - TO MIGRATE
4. ❌ `crates/core/mcp/src/enhanced/service_composition/health_types.rs` - TO MIGRATE
5. ❌ `crates/core/mcp/src/enhanced/service_composition/types/service.rs` - TO MIGRATE
6. ❌ `crates/core/mcp/src/resilience/health/mod.rs` - TO MIGRATE
7. ❌ `crates/ecosystem-api/src/config/ai/unified_ai_tools/routing.rs` - TO MIGRATE
8. ❌ `crates/ecosystem-api/src/types/health.rs` - TO MIGRATE
9. ❌ `crates/main/src/biomeos_integration/manifest.rs` - TO MIGRATE
10. ❌ `crates/main/src/biomeos_integration/mod.rs` - TO MIGRATE
11. ❌ `crates/main/src/ecosystem/service_types.rs` - TO MIGRATE
12. ❌ `crates/main/src/ecosystem/types.rs` - TO MIGRATE
13. ❌ `crates/main/src/monitoring/config.rs` - TO MIGRATE
14. ❌ `crates/main/src/monitoring/health.rs` - TO MIGRATE
15. ❌ `crates/providers/local/src/native/models.rs` - TO MIGRATE
16. ❌ `crates/universal-patterns/src/traits/service_types.rs` - TO MIGRATE

**Total to migrate**: 14 files (1 already canonical, 1 already fixed)

---

## 📋 MIGRATION PHASES

### Phase 1: Analysis & Deprecation (2-3 hours)

**Tasks**:
1. Read each duplicate definition
2. Document field differences
3. Identify all usage sites
4. Mark duplicates as deprecated
5. Add canonical import guidance

**Deliverable**: Deprecation analysis document

---

### Phase 2: Update Imports (3-4 hours)

**Tasks**:
1. For each consuming file:
   - Update import to use `canonical_config::services::HealthCheckConfig`
   - Handle any field name differences
   - Test compilation
2. Create conversion functions if needed
3. Update tests

**Deliverable**: All imports updated, code compiles

---

### Phase 3: Remove Duplicates (2-3 hours)

**Tasks**:
1. Verify no direct usage of duplicate structs
2. Remove deprecated struct definitions
3. Clean up any unused imports
4. Final compilation verification
5. Run full test suite

**Deliverable**: Single HealthCheckConfig, all tests passing

---

### Phase 4: Documentation (1-2 hours)

**Tasks**:
1. Update migration patterns guide
2. Document any breaking changes
3. Update examples
4. Create PR description

**Deliverable**: Complete documentation

---

## 🔧 MIGRATION STRATEGY

### Step-by-Step Process

#### For Each Duplicate File:

1. **Mark as Deprecated**
```rust
#[deprecated(
    since = "4.2.0", 
    note = "Use canonical_config::services::HealthCheckConfig instead"
)]
pub struct HealthCheckConfig {
    // ... existing fields
}
```

2. **Update Consumers**
```rust
// OLD:
use crate::monitoring::health::HealthCheckConfig;

// NEW:
use canonical_config::services::HealthCheckConfig;
```

3. **Handle Field Differences**
If fields differ, create conversion:
```rust
impl From<OldHealthCheckConfig> for canonical_config::services::HealthCheckConfig {
    fn from(old: OldHealthCheckConfig) -> Self {
        Self {
            enabled: old.enabled,
            interval_seconds: old.interval.as_secs(),
            timeout_seconds: old.timeout.as_secs(),
            failure_threshold: old.unhealthy_threshold,
            success_threshold: old.healthy_threshold,
        }
    }
}
```

4. **Test & Verify**
```bash
cargo check --package <package>
cargo test --package <package>
```

5. **Remove After Grace Period**
After 1-2 weeks, remove the deprecated struct entirely.

---

## 📝 DETAILED FILE ANALYSIS

### Priority Groups

#### Group A: High Priority (main crate - 5 files)
Most visible, highest usage:
- `main/src/biomeos_integration/manifest.rs`
- `main/src/biomeos_integration/mod.rs`
- `main/src/ecosystem/service_types.rs`
- `main/src/ecosystem/types.rs`
- `main/src/monitoring/config.rs`
- `main/src/monitoring/health.rs`

**Approach**: Migrate these first for maximum impact

---

#### Group B: Medium Priority (core/mcp - 4 files)
Core MCP functionality:
- `core/mcp/src/enhanced/service_composition/health_types.rs`
- `core/mcp/src/enhanced/service_composition/types/service.rs`
- `core/mcp/src/resilience/health/mod.rs`
- `core/core/src/routing/agent.rs`

**Approach**: Migrate after Group A

---

#### Group C: Lower Priority (ecosystem-api, providers - 3 files)
Less frequently used:
- `ecosystem-api/src/config/ai/unified_ai_tools/routing.rs`
- `ecosystem-api/src/types/health.rs`
- `providers/local/src/native/models.rs`

**Approach**: Migrate after Groups A & B

---

#### Group D: Pattern/Trait files (1 file)
Type definitions:
- `universal-patterns/src/traits/service_types.rs`

**Approach**: May just need import update

---

## ✅ MIGRATION CHECKLIST

### Pre-Migration
- [x] Identify canonical version
- [x] Find all duplicates (15 files)
- [x] Create migration plan (this document)
- [ ] Review migration patterns guide

### Phase 1: Analysis
- [ ] Document field differences for each duplicate
- [ ] Identify all usage sites
- [ ] Create field mapping guide
- [ ] Mark duplicates as deprecated

### Phase 2: Group A Migration
- [ ] main/src/biomeos_integration/manifest.rs
- [ ] main/src/biomeos_integration/mod.rs
- [ ] main/src/ecosystem/service_types.rs
- [ ] main/src/ecosystem/types.rs
- [ ] main/src/monitoring/config.rs
- [ ] main/src/monitoring/health.rs
- [ ] Test Group A compilation

### Phase 3: Group B Migration
- [ ] core/mcp/src/enhanced/service_composition/health_types.rs
- [ ] core/mcp/src/enhanced/service_composition/types/service.rs
- [ ] core/mcp/src/resilience/health/mod.rs
- [ ] core/core/src/routing/agent.rs
- [ ] Test Group B compilation

### Phase 4: Group C Migration
- [ ] ecosystem-api/src/config/ai/unified_ai_tools/routing.rs
- [ ] ecosystem-api/src/types/health.rs
- [ ] providers/local/src/native/models.rs
- [ ] Test Group C compilation

### Phase 5: Group D Migration
- [ ] universal-patterns/src/traits/service_types.rs
- [ ] Test Group D compilation

### Phase 6: Cleanup
- [ ] Verify all imports use canonical version
- [ ] Run `cargo check --workspace`
- [ ] Run `cargo test --workspace`
- [ ] Count remaining deprecation warnings
- [ ] Document changes

### Phase 7: Remove Duplicates (After Grace Period)
- [ ] Remove deprecated structs from all files
- [ ] Final verification
- [ ] Update documentation

---

## 🎯 SUCCESS CRITERIA

### Immediate (After Phase 2)
- ✅ All code uses canonical `HealthCheckConfig`
- ✅ All duplicates marked as deprecated
- ✅ Code compiles successfully
- ✅ Tests pass

### Long-term (After Phase 7)
- ✅ Single `HealthCheckConfig` definition
- ✅ 30-40% reduction in deprecation warnings
- ✅ Zero import conflicts
- ✅ Clear, documented migration

---

## 📊 EXPECTED IMPACT

### Deprecation Warnings
```
Current:  267 deprecation warnings
Expected: ~160-180 warnings (30-40% reduction)
Improvement: ~80-100 warnings eliminated
```

### Code Quality
- ✅ Single source of truth
- ✅ No import conflicts
- ✅ Clearer API
- ✅ Easier maintenance

### Developer Experience
- ✅ Clear which type to use
- ✅ No confusion about differences
- ✅ Consistent behavior
- ✅ Better documentation

---

## ⏱️ TIME ESTIMATES

### By Phase
```
Phase 1 (Analysis):        2-3 hours
Phase 2 (Imports):         3-4 hours
Phase 3 (Removal):         2-3 hours
Phase 4 (Documentation):   1-2 hours
Total:                     8-12 hours
```

### By Group
```
Group A (main):            2-3 hours
Group B (core/mcp):        2-3 hours
Group C (ecosystem):       1-2 hours
Group D (patterns):        30 minutes
Cleanup & Testing:         2-3 hours
Total:                     8-12 hours
```

---

## 🛠️ USEFUL COMMANDS

### Find Usage
```bash
# Find all HealthCheckConfig usage
grep -r "HealthCheckConfig" --include="*.rs" crates/main/

# Find struct definitions
grep -r "struct HealthCheckConfig" --include="*.rs" crates/

# Count deprecation warnings
cargo check 2>&1 | grep "warning: use of deprecated.*HealthCheckConfig" | wc -l
```

### Test Commands
```bash
# Check specific package
cargo check --package squirrel

# Test specific package
cargo test --package squirrel --lib

# Full workspace check
cargo check --workspace
```

---

## 📚 REFERENCE MATERIALS

### Canonical Location
- **File**: `crates/canonical-config/src/services.rs`
- **Lines**: 100-150
- **Import**: `use canonical_config::services::HealthCheckConfig;`

### Migration Guide
- **File**: `docs/MIGRATION_PATTERNS.md`
- **Section**: 3. HealthCheckConfig Consolidation
- **Examples**: Before/After, conversion functions

### Related Issues
- Deprecation warnings: 267 total (HealthCheckConfig ~30-40%)
- Import conflicts: Multiple definitions cause confusion
- API clarity: Unclear which version to use

---

## 🚀 GETTING STARTED

### Ready to Begin?

1. **Read**: Section 3 of `docs/MIGRATION_PATTERNS.md`
2. **Start**: Phase 1 - Analysis & Deprecation
3. **Focus**: Group A files first (main crate)
4. **Test**: After each file or small group
5. **Track**: Update this checklist as you go

### First Steps
```bash
# 1. Read a duplicate to understand differences
cat crates/main/src/monitoring/health.rs

# 2. Find usage in that file
grep -n "HealthCheckConfig" crates/main/src/monitoring/health.rs

# 3. Start with deprecation
# (Edit file, add #[deprecated] attribute)

# 4. Test
cargo check --package squirrel
```

---

## 💡 TIPS FOR SUCCESS

1. **One File at a Time**: Don't try to do everything at once
2. **Test Frequently**: Run `cargo check` after each file
3. **Document Differences**: Note any field mapping needed
4. **Use Git Branches**: `git checkout -b healthcheck-consolidation`
5. **Take Breaks**: This is 8-12 hours of work, pace yourself
6. **Track Progress**: Update this checklist as you complete items

---

**Status**: ✅ Plan Complete, Ready to Execute  
**Next Step**: Begin Phase 1 - Analysis & Deprecation  
**Estimated Completion**: 8-12 hours of focused work

---

*"A good plan today is better than a perfect plan tomorrow. Let's execute!"* 🚀 