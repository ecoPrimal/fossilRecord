# 🎯 IMMEDIATE NEXT ACTIONS
**Date**: October 2, 2025  
**Current**: 98.3% Unified  
**Target**: 98.8% (This Week)  
**Effort**: 8-12 hours

---

## 🚀 THIS WEEK'S FOCUS: SecurityContext Consolidation

### Priority 1: SecurityContext Audit (2 hours) ⭐⭐⭐⭐⭐

**THE BIGGEST WIN AVAILABLE**: 13 SecurityContext definitions → 3-4 legitimate

#### Step 1: Comprehensive Audit (30 minutes)
```bash
cd /home/eastgate/Development/ecoPrimals/squirrel

# Create audit file
cat > unification_work/SECURITY_CONTEXT_AUDIT.md << 'EOF'
# SecurityContext Consolidation Audit
**Date**: October 2, 2025
**Found**: 13 definitions
**Goal**: Reduce to 3-4 legitimate contexts

## All Definitions
1. universal-patterns/src/security/context.rs ← CANONICAL?
2. universal-patterns/src/traits/core_types.rs
3. universal-patterns/src/security/traits.rs
4. universal-patterns/src/federation/universal_executor.rs
5. ecosystem-api/src/types/security.rs
6. main/src/security_client/types.rs
7. main/src/security/types.rs
8. main/src/universal/security.rs
9. main/src/universal/requests.rs (UniversalSecurityContext)
10. main/src/ai_integration/security.rs
11. plugins/src/wasm_manager.rs
12. core/security/src/enterprise_hardening/policy_engine.rs
13. core/mcp/src/integration/types.rs
14. core/mcp/src/enhanced/workflow_management/types.rs
15. tests/security_integration_comprehensive.rs (MockSecurityContext)

## Audit Questions
- [ ] Which is the canonical version?
- [ ] Which have unique, domain-specific fields?
- [ ] Which are true duplicates?
- [ ] Which can be deprecated with type aliases?
EOF

# Read each SecurityContext definition
echo "Reading SecurityContext definitions..."
```

#### Step 2: Read & Compare Each Definition (1 hour)
```bash
# Use these commands to read each file:
bat crates/universal-patterns/src/security/context.rs
bat crates/universal-patterns/src/traits/core_types.rs
bat crates/ecosystem-api/src/types/security.rs
bat crates/main/src/security/types.rs
# ... etc for all 13 files

# Document in SECURITY_CONTEXT_AUDIT.md:
# - Fields in each struct
# - Traits implemented
# - Dependencies
# - Usage patterns
```

#### Step 3: Categorize (30 minutes)
```
Canonical (1):
- universal-patterns/src/security/context.rs (or identify best candidate)

Domain-Specific (Keep 2-3):
- MCP protocol security context (if has unique protocol fields)
- Plugin security context (if has unique plugin fields)
- Enterprise hardening context (if has unique policy fields)

True Duplicates (Deprecate 8-10):
- [List duplicates that can be replaced with type aliases]
```

---

### Priority 2: SecurityContext Consolidation (4-6 hours) ⭐⭐⭐⭐⭐

#### Step 1: Enhance Canonical (if needed) (1 hour)
```rust
// If canonical needs fields from domain-specific versions
// crates/universal-patterns/src/security/context.rs

pub struct SecurityContext {
    // Core fields
    pub user_id: Option<String>,
    pub session_id: Option<String>,
    pub permissions: Vec<Permission>,
    pub authentication_method: AuthMethod,
    
    // Extended fields for advanced use cases
    pub trust_level: Option<f64>,  // From ecosystem patterns
    pub device_context: Option<DeviceInfo>,
    pub temporal_constraints: Option<TimeConstraints>,
    
    // Audit & compliance
    pub audit_trail: Vec<AuditEntry>,
    pub compliance_tags: HashSet<String>,
}
```

#### Step 2: Deprecate Duplicates (2-3 hours)
```rust
// Example: crates/main/src/security/types.rs
// IF this is determined to be a duplicate

#[deprecated(
    since = "4.6.0",
    note = "Use universal_patterns::security::context::SecurityContext - canonical version with all features"
)]
pub type SecurityContext = universal_patterns::security::context::SecurityContext;

// Migration Guide (in file comments):
// OLD: use crate::security::types::SecurityContext;
// NEW: use universal_patterns::security::context::SecurityContext;
```

#### Step 3: Update Imports (1-2 hours)
```bash
# For each deprecated SecurityContext:
# 1. Add type alias with deprecation
# 2. Test builds:
cargo build -p [affected-package]

# 3. Document in migration guide
```

#### Step 4: Create Decision Tree (30 minutes)
```markdown
# SecurityContext Decision Tree

**Q: Which SecurityContext should I use?**

→ General purpose security context?
  ✅ Use: universal_patterns::security::context::SecurityContext

→ MCP protocol-specific security (retry, severity)?
  ✅ Use: core::mcp::security::MCPSecurityContext

→ Plugin sandbox security (capabilities, isolation)?
  ✅ Use: sdk::plugin::PluginSecurityContext

→ Enterprise policy engine (rules, compliance)?
  ✅ Use: core::security::enterprise::PolicySecurityContext
```

---

### Priority 3: RequestContext Quick Win (2 hours) ⭐⭐⭐

**Found**: 6 RequestContext definitions (all AI/routing related)

```bash
# Similar process to SecurityContext:
# 1. Audit (30 min)
# 2. Categorize (30 min)
# 3. Deprecate duplicates (1 hour)

Files to review:
- main/examples/ai_service_types.rs:105
- main/src/ai_integration/providers.rs:149
- tools/ai-tools/src/router/types.rs:101
- universal-patterns/src/capability_adapter.rs:202
- core/mcp/src/enhanced/coordinator/types.rs:322
- core/mcp/src/enhanced/ai_types.rs:319
```

---

## 📊 THIS WEEK'S GOALS

### Targets
- ✅ SecurityContext: 13 → 3-4 legitimate (8-9 eliminated)
- ✅ RequestContext: 6 → 2-3 legitimate (3-4 eliminated)
- ✅ Documentation: 2 comprehensive audit docs
- ✅ Build: 0 errors maintained
- ✅ Progress: 98.3% → 98.8% (+0.5%)

### Success Criteria
- [ ] SecurityContext audit complete
- [ ] 8+ SecurityContext duplicates deprecated
- [ ] Decision tree created
- [ ] RequestContext audit complete
- [ ] 3+ RequestContext duplicates deprecated
- [ ] All builds passing (0 errors)
- [ ] Migration guides complete
- [ ] Documentation: SECURITY_CONTEXT_CONSOLIDATION.md + REQUEST_CONTEXT_CONSOLIDATION.md

---

## 🛠️ COMMANDS REFERENCE

### Build Verification
```bash
# After each change:
cargo build -p canonical-errors -p canonical-config -p universal-patterns

# Full check:
cargo check --workspace

# Test affected packages:
cargo test -p [package-name]
```

### Search Utilities
```bash
# Find all uses of a type:
rg "SecurityContext" --type rust

# Find struct definitions:
rg "pub struct SecurityContext" --type rust

# Find imports:
rg "use.*SecurityContext" --type rust
```

---

## 📈 EXPECTED OUTCOMES

### By End of Week
```
Overall Unification:    98.3% → 98.8% (+0.5%)
SecurityContext:        13 → 3-4 (70% reduction)
RequestContext:         6 → 2-3 (50% reduction)
Code Eliminated:        ~150-200 lines
Documentation:          2 comprehensive audits
Confidence:            Very High (proven patterns)
```

### Next Week Preview
- PrimalContext (4 → 1)
- SessionContext (3 → 1-2)
- PluginContext (3 → 1-2)
- Progress: 98.8% → 99.2%

---

## 💡 KEY INSIGHTS

### Why SecurityContext First?
1. **Biggest single win**: 13 definitions (most duplicated)
2. **High visibility**: Security is critical, well-documented consolidation shows quality
3. **Clear boundaries**: Easy to identify legitimate vs duplicate
4. **Proven pattern**: Same approach as ErrorContext (completed successfully)

### Lessons from ErrorContext Success
- ✅ Audit first, act second
- ✅ Document domain-specific as legitimate
- ✅ Create decision trees for clarity
- ✅ Zero breaking changes with type aliases
- ✅ Build after every change

---

## 🚀 GET STARTED NOW

### First 30 Minutes
```bash
cd /home/eastgate/Development/ecoPrimals/squirrel

# 1. Create audit directory
mkdir -p unification_work

# 2. Start SecurityContext audit
$EDITOR unification_work/SECURITY_CONTEXT_AUDIT.md

# 3. Read first 3 SecurityContext definitions
bat crates/universal-patterns/src/security/context.rs
bat crates/universal-patterns/src/traits/core_types.rs
bat crates/ecosystem-api/src/types/security.rs
```

### Momentum Builder
After 30 minutes, you'll have:
- ✅ Clear view of canonical SecurityContext
- ✅ Understanding of field differences
- ✅ Initial categorization started
- ✅ **Confidence to proceed with consolidation**

---

**Status**: 🎯 **READY TO START**  
**Next**: SecurityContext audit (30 minutes)  
**Impact**: Biggest single unification win available  
**Confidence**: Very high (proven pattern)

---

*Let's eliminate 8-9 SecurityContext duplicates this week!* 🚀 