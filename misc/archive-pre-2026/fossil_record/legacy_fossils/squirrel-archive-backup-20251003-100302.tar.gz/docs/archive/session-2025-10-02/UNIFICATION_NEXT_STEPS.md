# 🎯 UNIFICATION NEXT STEPS - IMMEDIATE ACTION PLAN

**Date**: October 2, 2025  
**Current**: 97.9% Unified  
**Target**: 99%+ by end of October  
**Effort**: 30-40 focused hours

---

## 🚀 THIS WEEK (10-15 hours)

### Priority 1: LoadBalancingStrategy Unification (2-3 hours)
**Impact**: ⭐⭐⭐⭐⭐ (Last major enum duplication)

**Current**: 4-5 duplicate definitions  
**Goal**: Single canonical version

**Steps**:
1. Enhance `canonical-config/src/services.rs::LoadBalancingStrategy`:
   ```rust
   pub enum LoadBalancingStrategy {
       // Basic
       RoundRobin,
       Random,
       LeastConnections,
       WeightedRoundRobin,
       
       // Hash-based
       ConsistentHash,
       IpHash,
       
       // Metric-based
       QualityBased,
       ResponseTimeBased,
       HealthBased,
       Geographic,
       LowestLatency,
       
       // Advanced
       Adaptive,
       CapabilityBased,
       First,
   }
   ```

2. Deprecate duplicates:
   - `canonical-config/src/capability_based.rs` (Line 312)
   - `main/src/universal/agnostic_adapter.rs` (Line 118)

3. Test and document

**Files**: `unification_work/LOADBALANCING_UNIFICATION.md` (tracking doc)

---

### Priority 2: Helper Consolidation Final 5% (2-3 hours)
**Impact**: ⭐⭐⭐⭐ (Complete cleanup)

**Remaining**: 4 test helper files + 1 serialization duplicate

**Steps**:
1. Migrate to `test-utils`:
   - `core/mcp/src/sync/tests/sync_modules/helpers.rs`
   - `core/mcp/src/observability/tests/test_helpers.rs`
   - `core/plugins/src/simple_test_utils.rs`
   - `adapter-pattern-tests/src/test_utils.rs`

2. Investigate serialization duplication:
   - `core/mcp/src/protocol/serialization_utils.rs`
   - `core/mcp/src/protocol/serialization_helpers.rs`

3. Keep domain-specific (legitimate):
   - `core/mcp/src/utils.rs` ✅
   - `main/src/observability/tracing_utils.rs` ✅
   - `universal-patterns/src/performance/zero_copy_utils.rs` ✅

---

### Priority 3: TODO/FIXME Cleanup (3-5 hours)
**Impact**: ⭐⭐⭐ (Professional hygiene)

**Found**: 40+ TODO markers

**Focus on**:
1. Resolve temporarily disabled features:
   ```rust
   // ⚠️ TEMPORARILY DISABLED: UnifiedCLIConfigManager doesn't exist
   // ⚠️ TEMPORARILY DISABLED: ai-tools dependency is WIP
   ```

2. Convert vague TODOs to tracked issues:
   ```rust
   // TODO: Unify with canonical_config::ServiceDiscoveryConfig later
   // TODO: Implement specific logic for each strategy
   ```

3. Keep legitimate feature TODOs with context

---

### Priority 4: Default Implementation Audit (5-8 hours)
**Impact**: ⭐⭐⭐⭐ (Type system correctness)

**Found**: 1,057 Default implementations (many legitimate)

**Focus on**:
1. Incorrect Default impls on external types (orphan rule violations)
2. Example found:
   ```rust
   // core/mcp/src/protocol/production_handler.rs:64
   // NOTE: This Default implementation is incorrect
   impl Default for UnifiedSquirrelConfig { ... } // WRONG!
   ```

3. Create automated scan
4. Document complex Default impls

---

## 📅 NEXT 2-4 WEEKS (15-20 hours)

### Priority 5: Context Consolidation (8-12 hours)
**Impact**: ⭐⭐⭐⭐⭐ (Massive clarity improvement)

**Found**: 60+ different Context struct definitions

**Strategy**:
1. Create canonical hierarchy in `universal-patterns/src/context/`:
   ```rust
   context/
   ├── error.rs      // ErrorContext (5 duplicates found)
   ├── security.rs   // SecurityContext (8 duplicates found)
   ├── execution.rs  // ExecutionContext, RequestContext (12+ duplicates)
   ├── plugin.rs     // PluginContext (6 duplicates)
   └── primal.rs     // PrimalContext
   ```

2. Deprecate duplicates:
   - Keep only canonical versions
   - Deprecate domain-specific duplicates
   - Preserve truly domain-specific contexts (AIComputeContext, etc.)

**Target**: Reduce from 60+ to <20 canonical types

---

### Priority 6: Config Audit (Quick Wins: 3-5 hours)
**Impact**: ⭐⭐⭐⭐ (High visibility)

**Found**: 679 config struct definitions

**Quick wins**:
1. Generate audit:
   ```bash
   grep -r "pub struct.*Config" crates --include="*.rs" | grep -v target > config_audit.txt
   ```

2. Focus on known duplicates:
   - SecurityConfig variants (8 found)
   - Already consolidated: CircuitBreaker, LoadBalancing, Monitoring, Retry, HealthCheck ✅

3. Categorize:
   - Domain-specific (keep)
   - Duplicates (consolidate)
   - Deprecated (remove)

**Full audit**: 15-20 hours (schedule for Phase 3)

---

## 📊 PROGRESS TRACKING

### Current Metrics
```
Overall:                 97.9%
LoadBalancing:           20% → Target: 100%
Helper Consolidation:    95% → Target: 100%
Context Consolidation:   40% → Target: 90%
TODO Cleanup:            60% → Target: 95%
Config Consolidation:    Unknown → Target: 98%+
```

### Target Metrics (End of Week 1)
```
Overall:                 98.5% (+0.6%)
LoadBalancing:           100% ✅
Helper Consolidation:    100% ✅
TODO Cleanup:            80%
Default Impl Audit:      Complete
```

### Target Metrics (End of Week 4)
```
Overall:                 99%+ ✅
Context Consolidation:   90%+ ✅
Config Consolidation:    95%+ ✅
All Priorities:          Complete ✅
```

---

## 🎯 SUCCESS CRITERIA

### Week 1 Complete When:
- ✅ LoadBalancingStrategy: Single canonical version
- ✅ Helper files: 100% consolidated (0 remaining fragments)
- ✅ TODOs: <25 markers (all with clear context)
- ✅ Default impls: Audit complete, incorrect ones removed
- ✅ Build: 0 errors
- ✅ Documentation: All work tracked

### Month Complete When:
- ✅ Overall: 99%+ unified
- ✅ Context types: <20 canonical types
- ✅ Config structs: Audited, top duplicates removed
- ✅ Ecosystem: Ready to share template with toadstool/songbird

---

## 📝 TRACKING DOCUMENTS

### Create These:
1. `unification_work/LOADBALANCING_UNIFICATION.md` - Strategy consolidation
2. `unification_work/CONTEXT_CONSOLIDATION.md` - Context unification
3. `unification_work/CONFIG_AUDIT.md` - Config consolidation
4. `unification_work/TODO_CLEANUP.md` - TODO tracking
5. `unification_work/DEFAULT_IMPL_AUDIT.md` - Default impl audit

### Update These:
1. `STATUS.md` - After each priority completion
2. `README.md` - After week 1 completion
3. `CHANGELOG.md` - Document all changes

---

## 🚀 GET STARTED NOW

### Immediate First Step (30 minutes):
```bash
cd /home/eastgate/Development/ecoPrimals/squirrel

# 1. Create LoadBalancing enhancement
$EDITOR crates/canonical-config/src/services.rs
# Add comprehensive strategy variants (see Priority 1 above)

# 2. Deprecate duplicates
$EDITOR crates/canonical-config/src/capability_based.rs
$EDITOR crates/main/src/universal/agnostic_adapter.rs
# Add deprecation notices with migration guides

# 3. Verify
cargo build -p canonical-config
cargo test -p canonical-config

# 4. Document
mkdir -p unification_work
$EDITOR unification_work/LOADBALANCING_UNIFICATION.md
```

---

**Status**: 🎯 **READY TO START**  
**Next**: LoadBalancingStrategy unification (Priority 1)  
**Tracking**: Update STATUS.md after each priority

*Let's reach 99%+ unification!* 🚀 