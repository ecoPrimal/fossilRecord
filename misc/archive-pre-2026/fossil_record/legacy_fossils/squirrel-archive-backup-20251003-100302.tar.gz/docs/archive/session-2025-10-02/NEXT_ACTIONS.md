# 🎯 IMMEDIATE NEXT ACTIONS

**Date**: October 2, 2025  
**Current Status**: 98.3% Unified ✅  
**Target**: 99%+ Unified (2-3 weeks)  
**Recent Progress**: +0.4% today (LoadBalancing, TODO cleanup, ErrorContext complete)

---

## ✅ COMPLETED TODAY

1. ✅ **LoadBalancingStrategy unified** (4-5 → 1 canonical)
2. ✅ **TODO cleanup** (quick wins: 3 items)
3. ✅ **ErrorContext 100% complete** (5 → 3 legitimate)
4. ✅ **Context audit** (84 types discovered, 44% duplicates)
5. ✅ **105 lines eliminated** (0 errors introduced)

---

## 🔴 HIGHEST IMPACT - DO NEXT (6-8 hours)

### 1. SecurityContext Consolidation ⚡ MASSIVE IMPACT
**Discovery**: **13 duplicate SecurityContext definitions!**  
**Impact**: Biggest single consolidation opportunity in entire codebase

**Locations**:
1. `crates/plugins/src/wasm_manager.rs`
2. `crates/core/mcp/src/integration/types.rs`
3. `crates/core/mcp/src/enhanced/workflow_management/types.rs`
4. `crates/core/security/src/enterprise_hardening/policy_engine.rs`
5. `crates/main/src/security_client/types.rs`
6. `crates/main/src/security/types.rs`
7. `crates/main/src/ai_integration/security.rs`
8. `crates/main/src/universal/security.rs` (+ UniversalSecurityContext)
9. `crates/main/src/universal/requests.rs` (UniversalSecurityContext)
10. `crates/universal-patterns/src/federation/universal_executor.rs`
11. `crates/universal-patterns/src/security/context.rs` ← **Likely canonical**
12. `crates/universal-patterns/src/security/traits.rs`
13. `crates/universal-patterns/src/traits/core_types.rs`

**Phase 1: Audit (2-3 hours)**
```bash
# Read each SecurityContext definition
for file in <locations>; do
  grep -A 20 "pub struct SecurityContext" $file
done

# Create comparison matrix
# Identify most comprehensive version
# Document unique requirements
```

**Phase 2: Consolidation (4-5 hours)**
- Enhance canonical version with all necessary fields
- Deprecate 12 duplicates with type aliases
- Create migration guides
- Verify builds

**Expected**: 12 duplicates removed, 1 canonical SecurityContext

---

## 🟡 HIGH VALUE - Quick Wins (1-2 hours each)

### 2. PrimalContext Consolidation 🎯 FAST WIN
**Discovery**: 4 duplicates + **CanonicalPrimalContext already exists!**

**Locations**:
1. `crates/universal-patterns/src/types/canonical.rs` ← **Canonical exists!**
2. `crates/ecosystem-api/src/types/primal.rs` ← Deprecate
3. `crates/main/src/universal/context.rs` ← Deprecate
4. `crates/main/src/universal_complete/types.rs` ← Deprecate

**Action**:
```rust
// In duplicates, replace with:
#[deprecated(
    since = "4.5.0",
    note = "Use universal_patterns::types::canonical::CanonicalPrimalContext"
)]
pub type PrimalContext = universal_patterns::types::canonical::CanonicalPrimalContext;
```

**Expected**: 3 duplicates deprecated, 1 canonical  
**Time**: 1-2 hours

---

### 3. RequestContext Consolidation 📊 DECISION NEEDED
**Discovery**: 6 duplicates, mostly AI-related

**Locations**:
1. `crates/tools/ai-tools/src/router/types.rs`
2. `crates/core/mcp/src/enhanced/ai_types.rs`
3. `crates/core/mcp/src/enhanced/coordinator/types.rs`
4. `crates/main/examples/ai_service_types.rs`
5. `crates/main/src/ai_integration/providers.rs`
6. `crates/universal-patterns/src/capability_adapter.rs`

**Decision Required**: 
- Option A: One canonical RequestContext
- Option B: Domain-specific (AIRequestContext, MCPRequestContext, etc.)

**Action**: Audit all 6, determine pattern, consolidate  
**Expected**: 6 → 1-2 legitimate contexts  
**Time**: 2-3 hours

#### B. Unify MonitoringConfig (3 duplicates → 1)

**Locations**:
1. `crates/main/src/monitoring/mod.rs` ← **Keep as canonical**
2. `crates/main/src/monitoring/production_monitoring.rs` ← Deprecate
3. `crates/main/src/monitoring/performance.rs` - PerformanceConfig (different, keep)

**Action**: Deprecate duplicate in production_monitoring.rs

---

## 🚀 HIGH IMPACT - DO SECOND (Week 2: 12-15 hours)

### 3. Native Async Migration - Phase 1 (4-5 hours)

**Target**: AI provider traits for immediate performance gain

**Files to migrate**:
```
crates/tools/ai-tools/src/providers/openai.rs
crates/tools/ai-tools/src/providers/anthropic.rs  
crates/tools/ai-tools/src/providers/ollama.rs
crates/tools/ai-tools/src/providers/huggingface.rs
crates/tools/ai-tools/src/gemini/mod.rs
```

**Pattern**:
```rust
// Before:
#[async_trait]
pub trait AIProvider {
    async fn generate(&self, prompt: String) -> Result<String>;
}

// After:
pub trait AIProvider {
    fn generate(&self, prompt: String) -> impl Future<Output = Result<String>> + Send + '_;
}
```

**Validation**:
```bash
# Run benchmark before
cargo bench --bench ai_provider_benchmark > before.txt

# Migrate traits

# Run benchmark after  
cargo bench --bench ai_provider_benchmark > after.txt

# Compare results
diff before.txt after.txt
```

**Expected Gain**: 20-30% improvement in AI calls

---

## 🟡 IMPORTANT - DO THIRD (Week 3: 9-12 hours)

### 4. Config Consolidation

#### A. MCP Configs (3-4 hours)
Create `canonical-config/src/mcp.rs`:
```rust
pub struct MCPConfig {
    pub server: MCPServerConfig,
    pub client: MCPClientConfig,
    pub processor: MCPProcessorConfig,
}
```

Consolidate from:
- `main/src/internal_mcp.rs` - MCPProcessorConfig
- `main/src/communication/mcp.rs` - McpServerConfig
- Other scattered MCP configs

#### B. Plugin Metadata (3-4 hours)
Migrate all plugins to `CanonicalPluginMetadata`:
- Update 15+ PluginMetadata usages
- Create String → Uuid migration helpers
- Add deprecation notices

#### C. Test Configs (2-3 hours)
Create `canonical-config/src/testing.rs`:
```rust
pub struct TestingConfig {
    pub chaos: ChaosConfig,
    pub e2e: E2EConfig,
    pub performance: PerformanceTestConfig,
    pub deployment: DeploymentTestConfig,
}
```

---

## 🟢 POLISH - DO LAST (Week 4: 4-6 hours)

### 5. Final Cleanup
- Deprecate simple EventHandler (30 min)
- Remove unused deprecated items (2-3 hours)
- Documentation pass (1-2 hours)
- Final validation (1 hour)

---

## 📊 PROGRESS TRACKING

### Week 1 Goals:
- [ ] Main package building (186 errors → 0)
- [ ] CircuitBreakerConfig unified
- [ ] MonitoringConfig unified
- [ ] Documentation updated

### Week 2 Goals:
- [ ] 50+ async traits migrated
- [ ] 20-30% performance improvement measured
- [ ] Benchmarks documented

### Week 3 Goals:
- [ ] All configs consolidated
- [ ] Plugin metadata unified
- [ ] 99% config unification achieved

### Week 4 Goals:
- [ ] All tests passing
- [ ] Documentation complete
- [ ] 99% unified declared! 🎉

---

## 🔧 USEFUL COMMANDS

### Build & Test
```bash
# Build all canonical packages
cargo build -p canonical-errors -p canonical-config \
  -p universal-patterns -p squirrel-sdk

# Test canonical packages
cargo test -p canonical-errors -p canonical-config \
  -p universal-constants

# Try building main (currently fails)
cargo build -p squirrel

# Check all warnings
cargo clippy --workspace

# Format code
cargo fmt --all
```

### Find Duplicates
```bash
# Find all Config structs
rg "pub struct.*Config" --type rust

# Find async_trait usage
rg "#\[async_trait\]" --type rust

# Find Handler traits
rg "pub trait.*Handler" --type rust

# Check file sizes
find . -name "*.rs" -not -path "./target/*" -exec wc -l {} + | \
  awk '$1 > 2000 {print $1 " " $2}' | sort -rn
```

### Benchmark
```bash
# Run specific benchmark
cargo bench --bench arc_str_performance_suite

# Run all benchmarks
cargo bench --workspace

# Compare results
cargo bench --bench <name> -- --save-baseline before
# ... make changes ...
cargo bench --bench <name> -- --baseline before
```

---

## 💡 QUICK WINS

### Easy Tasks (< 1 hour each):
1. ✅ Deprecate duplicate MonitoringConfig (30 min)
2. ✅ Deprecate simple EventHandler (30 min)  
3. ✅ Add CanonicalEventHandler type alias (15 min)
4. ✅ Update README.md progress metrics (30 min)

### Medium Tasks (1-3 hours each):
1. 🔧 Unify CircuitBreakerConfig (1-2 hours)
2. 🔧 Create MCP config module (2-3 hours)
3. 🔧 Migrate 10-15 async traits (2-3 hours)

### Large Tasks (3-5 hours each):
1. 🚀 Resolve universal-patterns blocker (2-3 hours)
2. 🚀 Migrate 50+ async traits in ai-tools (4-5 hours)
3. 🚀 Consolidate all test configs (3-4 hours)

---

## 📞 HELP & RESOURCES

### Documentation:
- Full analysis: `UNIFICATION_REVIEW_REPORT_2025_10_02.md`
- Current status: `STATUS.md`
- Patterns guide: `crates/canonical-modernization/`

### Example Migrations:
- LoadBalancing: See `unification_work/LOADBALANCING_UNIFICATION_AUDIT.md`
- Async patterns: See `crates/canonical-modernization/src/async_modernization.rs`
- Config patterns: See `crates/canonical-config/src/unified/`

---

**Start Here**: Resolve universal-patterns blocker → Quick config wins → Native async migration → Done! 🚀 