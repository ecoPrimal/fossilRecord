# 🚀 Migration Guide: Unified Trait System

**Version**: 2.0  
**Date**: September 26, 2025  
**Status**: **PRODUCTION READY**  
**Migration Difficulty**: **Easy → Medium**

---

## 🎯 **Overview**

The Squirrel ecosystem has been unified with a new trait system that consolidates **50+ scattered trait definitions** into **3 main unified traits**. This guide provides step-by-step migration instructions.

### **What Changed**

**Before** (Fragmented):
```rust
use crate::ai::AIProvider;
use crate::security::SecurityProvider;
use crate::orchestration::OrchestrationProvider;
use crate::plugins::Plugin;
use crate::adapters::UniversalAdapter;
// ... 50+ different trait imports
```

**After** (Unified):
```rust
use universal_patterns::traits::{
    UniversalProvider,  // Replaces all *Provider traits
    UniversalAdapter,   // Replaces all *Adapter traits  
    UniversalPlugin,    // Replaces all *Plugin traits
};
```

---

## 🏗️ **New Unified Architecture**

### **3 Main Traits Replace 50+ Scattered Traits**

#### **1. UniversalProvider** 
Consolidates all provider types:
- `AIProvider` → `UniversalProvider` with `provider_type() = "ai"`
- `SecurityProvider` → `UniversalProvider` with `provider_type() = "security"`
- `OrchestrationProvider` → `UniversalProvider` with `provider_type() = "orchestration"`
- `MonitoringProvider` → `UniversalProvider` with `provider_type() = "monitoring"`
- `ContextProvider` → `UniversalProvider` with `provider_type() = "context"`

#### **2. UniversalAdapter**
Consolidates all adapter types:
- `CommandAdapter` → `UniversalAdapter`
- `TestAdapter` → `UniversalAdapter`
- `ContextAdapter` → `UniversalAdapter`
- `EvolvedAdapter` → `UniversalAdapter`

#### **3. UniversalPlugin**
Consolidates all plugin types:
- `Plugin` → `UniversalPlugin`
- `WebPlugin` → `UniversalPlugin`
- `McpPlugin` → `UniversalPlugin`
- `ToolPlugin` → `UniversalPlugin`
- `CliPlugin` → `UniversalPlugin`

---

## 📋 **Step-by-Step Migration**

### **Step 1: Update Imports**

**Old Imports**:
```rust
use crate::ai::AIProvider;
use crate::security::SecurityProvider;
use crate::plugins::Plugin;
use crate::adapters::UniversalAdapter;
```

**New Imports**:
```rust
use universal_patterns::traits::{
    UniversalProvider, UniversalAdapter, UniversalPlugin,
    AIProvider, SecurityProvider, // Type aliases for backward compatibility
};
```

### **Step 2: Update Trait Implementations**

#### **Provider Migration Example**

**Before**:
```rust
#[async_trait]
impl AIProvider for MyAIService {
    async fn generate_text(&self, prompt: &str) -> Result<String> {
        // AI-specific implementation
    }
    
    fn get_models(&self) -> Vec<String> {
        vec!["gpt-4".to_string()]
    }
}
```

**After**:
```rust
use universal_patterns::traits::{UniversalProvider, UniversalRequest, UniversalResponse};

#[async_trait]
impl UniversalProvider for MyAIService {
    fn provider_type(&self) -> &str {
        "ai" // Identifies this as an AI provider
    }
    
    fn provider_id(&self) -> &str {
        "my-ai-service"
    }
    
    fn capabilities(&self) -> Vec<String> {
        vec!["text-generation".to_string(), "gpt-4".to_string()]
    }
    
    async fn handle_request(&self, request: UniversalRequest) -> CanonicalResult<UniversalResponse> {
        match request.operation.as_str() {
            "generate_text" => {
                let prompt = request.payload["prompt"].as_str().unwrap_or("");
                let result = self.generate_text_internal(prompt).await?;
                
                Ok(UniversalResponse {
                    id: request.id,
                    success: true,
                    data: serde_json::json!({"text": result}),
                    metadata: HashMap::new(),
                    timestamp: chrono::Utc::now(),
                    error: None,
                })
            }
            _ => Err(CanonicalError::Internal {
                message: format!("Unsupported operation: {}", request.operation),
                component: Some("MyAIService".to_string()),
                recoverable: false,
            })
        }
    }
    
    // ... other required methods with default implementations available
}

// Easy migration helper macro
impl_universal_provider!(MyAIService, "ai");
```

#### **Plugin Migration Example**

**Before**:
```rust
#[async_trait]
impl Plugin for MyPlugin {
    fn name(&self) -> &str { "my-plugin" }
    async fn execute(&self, input: Value) -> Result<Value> {
        // Plugin logic
    }
}
```

**After**:
```rust
#[async_trait]
impl UniversalPlugin for MyPlugin {
    fn name(&self) -> &str { "my-plugin" }
    fn version(&self) -> &str { "1.0.0" }
    fn description(&self) -> &str { "My universal plugin" }
    
    fn capabilities(&self) -> Vec<String> {
        vec!["data-processing".to_string()]
    }
    
    async fn execute(&self, input: PluginInput) -> CanonicalResult<PluginOutput> {
        // Unified plugin logic
        Ok(PluginOutput {
            data: input.data, // Echo for example
            metadata: HashMap::new(),
            status: "success".to_string(),
        })
    }
    
    // Other methods have sensible defaults
}
```

### **Step 3: Update Usage Code**

**Before**:
```rust
async fn use_ai_provider(provider: &dyn AIProvider) {
    let result = provider.generate_text("Hello").await?;
    println!("Result: {}", result);
}
```

**After**:
```rust
async fn use_ai_provider(provider: &dyn UniversalProvider) {
    // Verify it's an AI provider
    if provider.provider_type() != "ai" {
        return Err("Expected AI provider".into());
    }
    
    let request = UniversalRequest {
        id: uuid::Uuid::new_v4().to_string(),
        operation: "generate_text".to_string(),
        payload: serde_json::json!({"prompt": "Hello"}),
        metadata: HashMap::new(),
        timestamp: chrono::Utc::now(),
    };
    
    let response = provider.handle_request(request).await?;
    if response.success {
        let text = response.data["text"].as_str().unwrap_or("");
        println!("Result: {}", text);
    }
}
```

---

## 🛠️ **Migration Helpers**

### **Helper Macro for Easy Migration**

The `impl_universal_provider!` macro provides default implementations:

```rust
use universal_patterns::impl_universal_provider;

struct MyService;

// Automatically implements UniversalProvider with defaults
impl_universal_provider!(MyService, "custom");

// Override specific methods as needed
impl MyService {
    fn provider_id(&self) -> &str {
        "my-custom-service"
    }
    
    fn capabilities(&self) -> Vec<String> {
        vec!["custom-capability".to_string()]
    }
}
```

### **Type Aliases for Backward Compatibility**

Type aliases are provided for smooth migration:

```rust
// These work during migration period
use universal_patterns::traits::{
    AIProvider,           // = UniversalProvider (for AI providers)
    SecurityProvider,     // = UniversalProvider (for security providers)
    OrchestrationProvider,// = UniversalProvider (for orchestration providers)
};

// Usage remains the same during transition
fn my_function<T: AIProvider>(provider: T) {
    // Works with both old and new implementations
}
```

---

## ⚡ **Quick Migration Checklist**

### **For Providers**
- [ ] Replace `impl AIProvider` with `impl UniversalProvider`
- [ ] Add `provider_type()` method returning your provider type
- [ ] Replace custom methods with `handle_request()` pattern
- [ ] Update error handling to use `CanonicalResult`
- [ ] Test with unified request/response structures

### **For Adapters**
- [ ] Replace `impl *Adapter` with `impl UniversalAdapter`
- [ ] Implement `supported_types()` method
- [ ] Replace custom adaptation logic with `adapt()` method
- [ ] Update to use `AdapterInput`/`AdapterOutput`

### **For Plugins**
- [ ] Replace `impl Plugin` with `impl UniversalPlugin`
- [ ] Add `capabilities()` method
- [ ] Update `execute()` to use `PluginInput`/`PluginOutput`
- [ ] Add metadata support

### **For Consumers**
- [ ] Update imports to use unified traits
- [ ] Replace direct method calls with universal request pattern
- [ ] Update error handling for `CanonicalResult`
- [ ] Use capability checking instead of type checking

---

## 🎯 **Advanced Usage Patterns**

### **Capability-Based Provider Selection**

```rust
use universal_patterns::traits::{UniversalProvider, UniversalRequest};

async fn select_and_use_provider(
    providers: &[Box<dyn UniversalProvider>],
    required_capability: &str
) -> CanonicalResult<UniversalResponse> {
    // Find provider with required capability
    let provider = providers
        .iter()
        .find(|p| p.capabilities().contains(&required_capability.to_string()))
        .ok_or_else(|| CanonicalError::Internal {
            message: format!("No provider found with capability: {}", required_capability),
            component: None,
            recoverable: false,
        })?;
    
    // Use the provider
    let request = UniversalRequest {
        id: uuid::Uuid::new_v4().to_string(),
        operation: "process".to_string(),
        payload: serde_json::json!({"capability": required_capability}),
        metadata: HashMap::new(),
        timestamp: chrono::Utc::now(),
    };
    
    provider.handle_request(request).await
}
```

### **Health Monitoring Across All Providers**

```rust
async fn check_ecosystem_health(providers: &[Box<dyn UniversalProvider>]) -> Vec<ProviderHealth> {
    let mut health_reports = Vec::new();
    
    for provider in providers {
        match provider.health_check().await {
            Ok(health) => health_reports.push(health),
            Err(e) => {
                health_reports.push(ProviderHealth {
                    healthy: false,
                    message: format!("Health check failed: {}", e),
                    checks: HashMap::new(),
                    timestamp: chrono::Utc::now(),
                });
            }
        }
    }
    
    health_reports
}
```

---

## 🚨 **Common Migration Issues**

### **Issue 1: Missing Capability Definitions**

**Problem**: Provider doesn't declare capabilities
```rust
fn capabilities(&self) -> Vec<String> {
    vec![] // Empty capabilities
}
```

**Solution**: Define specific capabilities
```rust
fn capabilities(&self) -> Vec<String> {
    vec![
        "text-generation".to_string(),
        "gpt-4".to_string(),
        "streaming".to_string(),
    ]
}
```

### **Issue 2: Request Handling Complexity**

**Problem**: Complex request routing
```rust
async fn handle_request(&self, request: UniversalRequest) -> CanonicalResult<UniversalResponse> {
    match request.operation.as_str() {
        "op1" => self.handle_op1(request).await,
        "op2" => self.handle_op2(request).await,
        // ... many operations
    }
}
```

**Solution**: Use operation registry pattern
```rust
use std::collections::HashMap;

struct OperationRegistry {
    handlers: HashMap<String, Box<dyn Fn(UniversalRequest) -> BoxFuture<CanonicalResult<UniversalResponse>>>>,
}

impl MyProvider {
    fn new() -> Self {
        let mut registry = OperationRegistry::new();
        registry.register("op1", Box::new(|req| Box::pin(self.handle_op1(req))));
        registry.register("op2", Box::new(|req| Box::pin(self.handle_op2(req))));
        // ...
    }
}
```

---

## ✅ **Validation and Testing**

### **Testing Unified Providers**

```rust
#[cfg(test)]
mod tests {
    use super::*;
    use universal_patterns::traits::*;
    
    #[tokio::test]
    async fn test_provider_capabilities() {
        let provider = MyAIService::new();
        
        // Test provider identification
        assert_eq!(provider.provider_type(), "ai");
        assert!(provider.capabilities().contains(&"text-generation".to_string()));
        
        // Test health check
        let health = provider.health_check().await.unwrap();
        assert!(health.healthy);
        
        // Test request handling
        let request = UniversalRequest {
            id: "test-123".to_string(),
            operation: "generate_text".to_string(),
            payload: serde_json::json!({"prompt": "test"}),
            metadata: HashMap::new(),
            timestamp: chrono::Utc::now(),
        };
        
        let response = provider.handle_request(request).await.unwrap();
        assert!(response.success);
    }
}
```

---

## 📚 **Additional Resources**

### **Documentation**
- [Unified Traits API Reference](./docs/API_REFERENCE_UNIFIED.md)
- [Architecture Decision Records](./docs/architecture/)
- [Performance Benchmarks](./benchmarks/)

### **Examples**
- [Provider Migration Examples](./examples/migration/)
- [Plugin Migration Examples](./examples/plugins/)
- [Integration Patterns](./examples/integration/)

### **Tools**
- Migration helper scripts in `./scripts/migration/`
- Automated trait detection: `cargo run --bin trait-detector`
- Compatibility checker: `cargo run --bin compat-check`

---

## 🎉 **Migration Benefits**

### **Developer Experience**
- **Simplified APIs**: 3 traits instead of 50+
- **Consistent Patterns**: Same interface across all providers
- **Better Tooling**: Unified debugging and monitoring
- **Easier Testing**: Standard test patterns

### **Runtime Benefits**
- **Performance**: Optimized trait object dispatch
- **Memory**: Reduced trait object overhead
- **Capability Discovery**: Runtime capability checking
- **Health Monitoring**: Unified health checking

### **Maintenance**
- **Reduced Complexity**: Single trait hierarchy
- **Better Documentation**: Consolidated API docs
- **Easier Refactoring**: Consistent patterns
- **Future-Proof**: Extensible design

---

**Migration Status**: **READY FOR PRODUCTION** ✅  
**Support**: Available via GitHub issues and documentation  
**Timeline**: Gradual migration recommended over 2-4 weeks 