# 🏆 **Modernized Development Best Practices**

**Version**: 2.0 (Post-Modernization)  
**Date**: September 26, 2025  
**Status**: Production Standards

---

## 🎯 **Core Principles**

The modernized Squirrel codebase follows these fundamental principles:

1. **🛡️ Zero Panic Tolerance** - Never use `panic!()` in production code
2. **🏗️ Canonical Systems** - Always use unified error/config/constants
3. **📏 Size Discipline** - Maximum 2000 lines per file
4. **🔧 Type Safety** - Comprehensive error handling and validation
5. **📚 Self-Documenting** - Code that explains itself

---

## 🛡️ **Error Handling Standards**

### **✅ Required Patterns**

#### **1. Use Canonical Error System**
```rust
use canonical_errors::{CanonicalError, CanonicalResult};

// ✅ CORRECT - Proper error creation
pub fn process_request(data: &str) -> CanonicalResult<Response> {
    if data.is_empty() {
        return Err(CanonicalError::validation("Request data cannot be empty"));
    }
    
    let parsed = serde_json::from_str(data)
        .map_err(|e| CanonicalError::parsing(
            format!("Failed to parse request: {}", e),
            Some("json".to_string())
        ))?;
    
    Ok(Response::from(parsed))
}
```

#### **2. Never Use Panic Patterns**
```rust
// ❌ FORBIDDEN - Never use these patterns
panic!("Something went wrong");
data.unwrap();  // Only in tests or with SAFETY comment
data.expect("This should never fail");  // Only with proper justification

// ✅ CORRECT - Safe error handling
let data = match get_data() {
    Ok(data) => data,
    Err(e) => return Err(CanonicalError::processing(
        format!("Failed to get data: {}", e),
        Some("data_retrieval".to_string()),
        Some("external".to_string())
    )),
};
```

#### **3. Rich Error Context**
```rust
// ✅ CORRECT - Comprehensive error context
pub fn connect_to_service(endpoint: &str) -> CanonicalResult<Connection> {
    let connection = TcpStream::connect(endpoint)
        .map_err(|e| CanonicalError::network(
            format!("Failed to connect to service: {}", e),
            Some(endpoint.to_string()),
            Some(408) // Request timeout
        ))?;
    
    Ok(Connection::new(connection))
}
```

### **❌ Prohibited Patterns**
- `panic!()` in any production code path
- `unwrap()` without SAFETY comments
- `expect()` without detailed justification
- Generic error messages without context
- Error swallowing (`let _ = result;`)

---

## 🏗️ **Configuration Standards**

### **✅ Use Canonical Configuration**
```rust
use canonical_config::CanonicalSquirrelConfig;
use universal_constants::{ports, timeouts};

pub fn initialize_service() -> CanonicalResult<Service> {
    // Load unified configuration
    let config = CanonicalSquirrelConfig::from_env()?;
    
    // Always validate configuration
    config.validate()?;
    
    // Use constants for defaults
    let service_port = config.network.port
        .unwrap_or(ports::constants::SQUIRREL_DEFAULT);
    
    let timeout = Duration::from_secs(
        config.network.timeout_secs
            .unwrap_or(timeouts::DEFAULT_REQUEST_TIMEOUT_SECS)
    );
    
    Service::builder()
        .port(service_port)
        .timeout(timeout)
        .config(config)
        .build()
}
```

### **❌ Prohibited Configuration Patterns**
```rust
// ❌ FORBIDDEN - Don't use these
use squirrel::AgnosticConfig;  // Deprecated
use squirrel::LegacyConfig;    // Deprecated
const HARDCODED_PORT: u16 = 8080;  // Use universal_constants

// ❌ FORBIDDEN - Direct environment access without validation
let port: u16 = env::var("PORT").unwrap().parse().unwrap();
```

---

## 📐 **Constants and Types**

### **✅ Use Universal Constants**
```rust
use universal_constants::{ports, timeouts, resources, system};

pub fn create_server() -> CanonicalResult<Server> {
    Server::builder()
        .port(ports::constants::SQUIRREL_DEFAULT)
        .timeout(Duration::from_secs(timeouts::DEFAULT_REQUEST_TIMEOUT_SECS))
        .memory_limit(resources::DEFAULT_MEMORY_LIMIT_MB * 1024 * 1024)
        .name(system::NAME)
        .version(system::VERSION)
        .build()
}
```

### **✅ Unified Type System**
```rust
use universal_patterns::traits::{UniversalProvider, UniversalAdapter};
use ecosystem_api::traits::{UniversalResult, EcosystemError};

pub trait MyServiceProvider: UniversalProvider {
    fn process(&self, input: ServiceInput) -> UniversalResult<ServiceOutput>;
}

impl MyServiceProvider for ConcreteService {
    fn process(&self, input: ServiceInput) -> UniversalResult<ServiceOutput> {
        input.validate()
            .map_err(|e| EcosystemError::validation(format!("Invalid input: {}", e)))?;
        
        let result = self.internal_process(input)
            .map_err(|e| EcosystemError::processing(
                format!("Processing failed: {}", e),
                Some("internal_process".to_string()),
                Some("core".to_string())
            ))?;
        
        Ok(ServiceOutput::success(result))
    }
}
```

---

## 📏 **File Organization Standards**

### **File Size Limits**
- **Maximum**: 2000 lines per file
- **Recommended**: 500-1000 lines per file
- **Action Required**: Split files exceeding 2000 lines

### **Module Structure**
```rust
// ✅ CORRECT - Well-organized module
//! Module documentation explaining purpose and usage
//!
//! This module provides [specific functionality] with [key features].

// Standard library imports first
use std::collections::HashMap;
use std::sync::Arc;

// Third-party crates
use tokio::sync::RwLock;
use serde::{Deserialize, Serialize};

// Canonical foundation (always include these)
use canonical_errors::{CanonicalError, CanonicalResult};
use canonical_config::CanonicalSquirrelConfig;
use universal_constants::{ports, timeouts};

// Local imports last
use crate::types::*;
use super::utils;

// Module contents with clear organization
pub mod submodule;

pub use submodule::PublicType;

// Constants, types, structs, implementations, tests
```

---

## 🧪 **Testing Standards**

### **✅ Test Structure**
```rust
#[cfg(test)]
mod tests {
    use super::*;
    use test_utils::*;  // Use centralized test utilities
    use canonical_errors::CanonicalError;
    
    #[tokio::test]
    async fn test_service_success_case() -> CanonicalResult<()> {
        // Arrange
        let config = create_test_config()?;
        let service = TestService::new(config)?;
        let input = create_mock_input("test_data");
        
        // Act
        let result = service.process(input).await?;
        
        // Assert
        assert!(result.success);
        assert_eq!(result.data.len(), 5);
        assert!(result.metadata.contains_key("processed_at"));
        
        Ok(())
    }
    
    #[tokio::test]
    async fn test_service_error_handling() {
        // Test error conditions
        let service = TestService::default();
        let invalid_input = create_mock_input("");
        
        let result = service.process(invalid_input).await;
        
        assert!(result.is_err());
        match result.unwrap_err() {
            CanonicalError::Validation { message, .. } => {
                assert!(message.contains("cannot be empty"));
            }
            _ => panic!("Expected validation error"),
        }
    }
}
```

### **Testing Requirements**
- Use `test_utils` crate for common utilities
- Test both success and error paths
- Use proper error matching, not panic assertions
- Include async test patterns where needed
- Validate error messages and context

---

## 🔧 **Development Workflow**

### **Pre-Commit Checklist**
```bash
# 1. Format code
cargo fmt --all

# 2. Check compilation
cargo check --workspace --lib

# 3. Run clippy
cargo clippy --workspace --lib -- -D warnings

# 4. Run tests
cargo test --workspace

# 5. Check for panic patterns
grep -r "panic!" --include="*.rs" crates/ || echo "✅ No panic patterns"

# 6. Validate file sizes
find crates/ -name "*.rs" -exec wc -l {} + | awk '$1 > 2000 {print "❌ " $2 " exceeds 2000 lines"}'
```

### **Code Review Standards**
- ✅ No panic patterns in production code
- ✅ All errors use canonical error system
- ✅ Configuration uses canonical config
- ✅ Constants use universal-constants
- ✅ Files under 2000 lines
- ✅ Comprehensive error handling
- ✅ Proper documentation

---

## 📚 **Documentation Standards**

### **✅ Module Documentation**
```rust
//! # Service Management Module
//!
//! This module provides comprehensive service management capabilities including
//! service registration, health monitoring, and lifecycle management.
//!
//! ## Features
//!
//! - **Service Registration**: Register services with the ecosystem
//! - **Health Monitoring**: Continuous health checking and alerting
//! - **Lifecycle Management**: Start, stop, restart service operations
//!
//! ## Usage
//!
//! ```rust
//! use service_management::{ServiceManager, ServiceConfig};
//! use canonical_errors::CanonicalResult;
//!
//! async fn example() -> CanonicalResult<()> {
//!     let manager = ServiceManager::new().await?;
//!     let service = manager.register_service(ServiceConfig::default()).await?;
//!     Ok(())
//! }
//! ```
//!
//! ## Error Handling
//!
//! All functions return `CanonicalResult<T>` and use the unified error system.
//! See [`canonical_errors`] for error handling patterns.
```

### **✅ Function Documentation**
```rust
/// Processes a service request with comprehensive validation and error handling.
///
/// This function validates the input request, processes it through the service pipeline,
/// and returns a structured response with detailed error context if processing fails.
///
/// # Arguments
///
/// * `request` - The service request to process, must be valid JSON
/// * `context` - Processing context including user information and session data
///
/// # Returns
///
/// Returns `Ok(ServiceResponse)` on success, or a `CanonicalError` with detailed
/// context on failure. Common error scenarios:
///
/// - `ValidationError` - Invalid request format or missing required fields
/// - `ProcessingError` - Internal processing failure with recovery information
/// - `NetworkError` - External service communication failure
///
/// # Examples
///
/// ```rust
/// use service::process_request;
/// use canonical_errors::CanonicalResult;
///
/// async fn example() -> CanonicalResult<()> {
///     let request = ServiceRequest::new("test_data")?;
///     let context = ProcessingContext::default();
///     
///     let response = process_request(request, context).await?;
///     println!("Response: {:?}", response);
///     
///     Ok(())
/// }
/// ```
///
/// # Errors
///
/// This function will return an error if:
/// - The request format is invalid
/// - Required fields are missing
/// - External services are unavailable
/// - Internal processing fails
pub async fn process_request(
    request: ServiceRequest,
    context: ProcessingContext,
) -> CanonicalResult<ServiceResponse> {
    // Implementation...
}
```

---

## 🚀 **Performance Guidelines**

### **Memory Management**
```rust
// ✅ CORRECT - Efficient patterns
use std::sync::Arc;
use parking_lot::RwLock;

// Share data efficiently
pub struct ServiceManager {
    config: Arc<CanonicalSquirrelConfig>,
    services: Arc<RwLock<HashMap<String, Service>>>,
}

// Use zero-copy patterns where possible
pub fn process_data(data: &[u8]) -> CanonicalResult<&str> {
    std::str::from_utf8(data)
        .map_err(|e| CanonicalError::parsing(
            format!("Invalid UTF-8 data: {}", e),
            Some("utf8".to_string())
        ))
}
```

### **Async Patterns**
```rust
// ✅ CORRECT - Proper async usage
use tokio::time::{timeout, Duration};

pub async fn call_external_service(endpoint: &str) -> CanonicalResult<Response> {
    let client = reqwest::Client::new();
    
    let response = timeout(
        Duration::from_secs(timeouts::DEFAULT_REQUEST_TIMEOUT_SECS),
        client.get(endpoint).send()
    )
    .await
    .map_err(|_| CanonicalError::network(
        "Request timeout".to_string(),
        Some(endpoint.to_string()),
        Some(408)
    ))?
    .map_err(|e| CanonicalError::network(
        format!("Request failed: {}", e),
        Some(endpoint.to_string()),
        None
    ))?;
    
    Ok(Response::from(response))
}
```

---

## 🔒 **Security Guidelines**

### **Input Validation**
```rust
use canonical_errors::{CanonicalError, CanonicalResult};

pub fn validate_user_input(input: &str) -> CanonicalResult<String> {
    // Length validation
    if input.len() > 1000 {
        return Err(CanonicalError::validation(
            "Input too long (max 1000 characters)"
        ));
    }
    
    // Content validation
    if input.contains('<') || input.contains('>') {
        return Err(CanonicalError::validation(
            "Input contains potentially unsafe characters"
        ));
    }
    
    // Sanitization
    let sanitized = input.trim().to_string();
    
    Ok(sanitized)
}
```

### **Safe Defaults**
```rust
// ✅ CORRECT - Secure by default
pub struct SecurityConfig {
    pub enable_tls: bool,
    pub require_authentication: bool,
    pub rate_limit_enabled: bool,
}

impl Default for SecurityConfig {
    fn default() -> Self {
        Self {
            enable_tls: true,           // Secure by default
            require_authentication: true, // Secure by default
            rate_limit_enabled: true,   // Secure by default
        }
    }
}
```

---

## ✅ **Quality Checklist**

Before submitting code, ensure:

### **Code Quality**
- [ ] No `panic!()` patterns in production code
- [ ] All errors use `CanonicalError`
- [ ] All configuration uses `CanonicalSquirrelConfig`
- [ ] All constants use `universal_constants`
- [ ] Files are under 2000 lines
- [ ] Comprehensive documentation

### **Testing**
- [ ] Unit tests for all public functions
- [ ] Error path testing
- [ ] Integration tests where appropriate
- [ ] Use `test_utils` for common functionality
- [ ] All tests pass: `cargo test --workspace`

### **Performance**
- [ ] No unnecessary allocations
- [ ] Proper async usage
- [ ] Efficient data structures
- [ ] Zero-copy patterns where applicable

### **Security**
- [ ] Input validation
- [ ] Secure defaults
- [ ] No hardcoded secrets
- [ ] Proper error message sanitization

---

## 🎯 **Modernization Compliance**

Your code is modernization-compliant when:

1. **✅ Zero Technical Debt** - No deprecated patterns or compatibility layers
2. **✅ Unified Systems** - Uses canonical error/config/constants throughout
3. **✅ Production Safe** - No panic patterns, comprehensive error handling
4. **✅ Well Organized** - Files under size limits, clear module structure
5. **✅ Thoroughly Tested** - Comprehensive test coverage with proper patterns
6. **✅ Well Documented** - Self-explanatory code with comprehensive docs

---

**Welcome to production-grade development with the modernized Squirrel codebase!** 🐿️✨

*These practices ensure maintainability, reliability, and excellence in every line of code.* 