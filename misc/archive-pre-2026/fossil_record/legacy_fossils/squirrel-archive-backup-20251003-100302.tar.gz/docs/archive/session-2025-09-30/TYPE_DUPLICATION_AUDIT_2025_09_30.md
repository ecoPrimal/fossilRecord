# Type Duplication Audit - September 30, 2025

**Phase**: 2 of 6-Phase Unification  
**Focus**: Consolidate duplicate type definitions  
**Status**: Initial Audit Complete  

---

## 📊 **DUPLICATION PATTERNS IDENTIFIED**

### Category 1: **ErrorContext** - Duplicate Struct (3 instances)

| Location | Type | Lines | Action |
|----------|------|-------|--------|
| `canonical-errors/src/types.rs` | `pub struct ErrorContext` | ~20 | ✅ KEEP (canonical) |
| `core/mcp/src/error/types.rs` | `pub struct ErrorContext` | ~15 | ❌ REMOVE (duplicate) |
| `core/mcp/src/enhanced/error_types.rs` | `pub struct ErrorContext` | ~15 | ❌ REMOVE (duplicate) |

**Impact**: 2 duplicate definitions  
**Recommendation**: Use `canonical_errors::ErrorContext` everywhere

### Category 2: **SecurityContext** - Duplicate Struct (3 instances)

| Location | Type | Lines | Action |
|----------|------|-------|--------|
| `plugins/src/wasm_manager.rs` | `pub struct SecurityContext` | ~15 | ⚠️ REVIEW (specific) |
| `core/mcp/src/integration/types.rs` | `pub struct SecurityContext` | ~15 | ❌ CONSOLIDATE |
| `core/mcp/src/enhanced/workflow_management/types.rs` | `pub struct SecurityContext` | ~15 | ❌ CONSOLIDATE |

**Impact**: 2-3 duplicate definitions  
**Recommendation**: Create canonical SecurityContext in universal-patterns

### Category 3: **DatabaseConfig** - Duplicate Struct (2 instances)

| Location | Type | Lines | Action |
|----------|------|-------|--------|
| `integration/web/src/database.rs` | `pub struct DatabaseConfig` | ~20 | ✅ KEEP |
| `integration/web/src/auth/database.rs` | `pub struct DatabaseConfig` | ~20 | ❌ RENAME or remove |

**Impact**: 1 duplicate within same crate  
**Recommendation**: Rename auth one to `AuthDatabaseConfig` or consolidate

### Category 4: **HealthCheckConfig** - Duplicate Struct (2 instances)

| Location | Type | Lines | Action |
|----------|------|-------|--------|
| `canonical-config/src/services.rs` | `pub struct HealthCheckConfig` | ~15 | ✅ KEEP (canonical) |
| `providers/local/src/native/models.rs` | `pub struct HealthCheckConfig` | ~15 | ❌ USE CANONICAL |

**Impact**: 1 duplicate  
**Recommendation**: Use canonical-config version

### Category 5: **ContextTransformation** - Duplicate Struct (2 instances)

| Location | Type | Lines | Action |
|----------|------|-------|--------|
| `core/interfaces/src/context.rs` | `pub struct TransformationMetadata` | ~20 | ✅ KEEP (canonical) |
| `core/plugins/src/context/mod.rs` | `pub struct ContextTransformation` | ~20 | ❌ USE INTERFACE |

**Impact**: 1 duplicate  
**Recommendation**: Use squirrel-interfaces version

### Category 6: **ContextPlugin** - Duplicate Trait (2 instances)

| Location | Type | Lines | Action |
|----------|------|-------|--------|
| `core/interfaces/src/context.rs` | `pub trait ContextPlugin` | ~15 | ✅ KEEP (canonical) |
| `core/plugins/src/context/mod.rs` | `pub trait ContextPlugin` | ~15 | ❌ REMOVE (use interface) |

**Impact**: 1 duplicate trait  
**Recommendation**: Import from squirrel-interfaces

### Category 7: **Redundant Type Aliases** - Config Aliases (12 instances)

| Location | Alias | Points To | Action |
|----------|-------|-----------|--------|
| `canonical-config/src/lib.rs` | `CanonicalConfig` | `CanonicalSquirrelConfig` | ⚠️ KEEP (main alias) |
| `universal-patterns/src/config/types.rs` | `PrimalConfig` | `UnifiedSquirrelConfig` | ❌ DEPRECATE |
| `universal-patterns/src/config/types.rs` | `UniversalPrimalConfig` | `UnifiedUniversalPatternsConfig` | ❌ DEPRECATE |
| `universal-patterns/src/config/types.rs` | `PrimalInstanceConfig` | `MultiInstanceConfig` | ❌ DEPRECATE |
| `universal-patterns/src/config/mod.rs` | `PrimalInstanceConfig` | `UnifiedSquirrelConfig` | ❌ DEPRECATE (duplicate) |
| `universal-patterns/src/config/mod.rs` | `UniversalPrimalConfig` | `UnifiedSquirrelConfig` | ❌ DEPRECATE (duplicate) |
| `canonical-config/src/unified/security.rs` | `SecurityConfig` | `UnifiedSecurityConfig` | ❌ DEPRECATE |
| `main/src/universal/types.rs` | `MainPrimalInfo` | `CanonicalPrimalInfo` | ❌ DEPRECATE |
| `main/src/universal/types.rs` | `MainPrimalRequest` | `CanonicalPrimalRequest` | ❌ DEPRECATE |
| `main/src/universal/types.rs` | `MainPrimalResponse` | `CanonicalPrimalResponse` | ❌ DEPRECATE |
| `main/src/universal/types.rs` | `MainPrimalContext` | `CanonicalPrimalContext` | ❌ DEPRECATE |

**Impact**: 11 redundant aliases (1 keep, 10 deprecate)  
**Recommendation**: Apply deprecation attributes

### Category 8: **Redundant Type Aliases** - Type Re-exports (8 instances)

| Location | Alias | Points To | Action |
|----------|-------|-----------|--------|
| `universal-patterns/src/types/canonical.rs` | `HealthStatus` | `CanonicalHealthStatus` | ❌ DEPRECATE |
| `universal-patterns/src/types/canonical.rs` | `ServiceQuery` | `CanonicalServiceQuery` | ❌ DEPRECATE |
| `universal-patterns/src/types/canonical.rs` | `ServiceInfo` | `CanonicalServiceInfo` | ❌ DEPRECATE |
| `universal-patterns/src/types/canonical.rs` | `AIRequest` | `CanonicalAIRequest` | ❌ DEPRECATE |
| `universal-patterns/src/types/canonical.rs` | `AIResponse` | `CanonicalAIResponse` | ❌ DEPRECATE |
| `universal-patterns/src/types/canonical.rs` | `ModelInfo` | `CanonicalModelInfo` | ❌ DEPRECATE |
| `universal-patterns/src/types/canonical_health.rs` | `HealthStatus` | `CanonicalHealthStatus` | ❌ DEPRECATE (duplicate) |
| `universal-patterns/src/types/canonical_health.rs` | `HealthInfo` | `CanonicalHealthInfo` | ❌ DEPRECATE |

**Impact**: 8 redundant type aliases  
**Recommendation**: Use Canonical* types directly

---

## 📋 **SUMMARY STATISTICS**

| Category | Count | Action | Priority |
|----------|-------|--------|----------|
| Duplicate Structs | 6 | Consolidate/Remove | HIGH |
| Duplicate Traits | 1 | Remove (use interface) | HIGH |
| Config Aliases (redundant) | 11 | Deprecate | MEDIUM |
| Type Re-export Aliases | 8 | Deprecate | MEDIUM |
| **TOTAL** | **26** | - | - |

### Breakdown by Action

```
Remove/Consolidate:  7 duplicate definitions
Deprecate:          19 redundant aliases
Keep/Review:         0 (all duplicates identified)
```

---

## 🎯 **PHASE 2 ACTION PLAN**

### Step 1: Remove Duplicate Structs (7 files - 30 min)

1. **ErrorContext duplicates**
   - Remove from `core/mcp/src/error/types.rs`
   - Remove from `core/mcp/src/enhanced/error_types.rs`
   - Update imports to use `canonical_errors::ErrorContext`

2. **SecurityContext duplicates**
   - Consolidate to universal-patterns (or keep plugin-specific)
   - Update imports in MCP crates

3. **DatabaseConfig duplicate**
   - Rename in `web/auth/database.rs` to `AuthDatabaseConfig`
   - Or consolidate if they're the same

4. **HealthCheckConfig duplicate**
   - Update `providers/local` to use `canonical_config::HealthCheckConfig`

5. **ContextTransformation duplicate**
   - Remove from `plugins/src/context/mod.rs`
   - Use `squirrel-interfaces::context::TransformationMetadata`

6. **ContextPlugin duplicate trait**
   - Remove from `plugins/src/context/mod.rs`
   - Import from `squirrel-interfaces::context`

### Step 2: Deprecate Redundant Config Aliases (11 files - 20 min)

Apply `#[deprecated]` to:
1. `universal-patterns/src/config/types.rs` - 3 aliases
2. `universal-patterns/src/config/mod.rs` - 2 aliases (duplicates!)
3. `canonical-config/src/unified/security.rs` - 1 alias
4. `main/src/universal/types.rs` - 4 aliases

### Step 3: Deprecate Type Re-export Aliases (2 files - 15 min)

Apply `#[deprecated]` to:
1. `universal-patterns/src/types/canonical.rs` - 6 aliases
2. `universal-patterns/src/types/canonical_health.rs` - 2 aliases

### Step 4: Update Imports (Multiple files - 30 min)

- Find all uses of deprecated types
- Update imports to canonical versions
- Verify builds

### Step 5: Verification (20 min)

- Run workspace build
- Run test suite
- Verify deprecation warnings
- Document changes

---

## 📊 **EXPECTED IMPACT**

### Before Phase 2
- Duplicate structs: 7
- Redundant aliases: 19
- Total duplication: 26 items

### After Phase 2
- Duplicate structs: 0 (all consolidated)
- Redundant aliases: 0 (all deprecated)
- Remaining: Only canonical definitions

### Metrics
- **Files Modified**: ~20-25 files
- **Deprecations Applied**: 19
- **Struct Removals**: 6
- **Trait Removals**: 1
- **Import Updates**: ~30-50 locations

---

## 🎓 **PATTERNS TO ESTABLISH**

### ✅ RECOMMENDED: Use Canonical Types Directly

```rust
// ✅ Good - Use canonical type directly
use canonical_errors::ErrorContext;
use canonical_config::HealthCheckConfig;

pub fn my_function(ctx: ErrorContext) -> Result<()> {
    // ...
}
```

### ❌ AVOID: Redundant Type Aliases

```rust
// ❌ Bad - Unnecessary alias
pub type MyContext = CanonicalContext; // Just use CanonicalContext!
```

### ✅ ACCEPTABLE: Semantic Aliases (Rare)

```rust
// ✅ Acceptable - Adds semantic meaning
pub type RequestContext = CanonicalContext; // OK if it clarifies intent
```

---

## 🚀 **IMPLEMENTATION ORDER**

### Phase 2A: High-Impact Duplicates (45 min)
1. ErrorContext (2 removals) - 15 min
2. ContextPlugin trait (1 removal) - 10 min
3. ContextTransformation (1 removal) - 10 min
4. HealthCheckConfig (1 removal) - 10 min

### Phase 2B: Config Aliases (30 min)
1. universal-patterns config aliases (5 deprecations) - 15 min
2. main/universal/types.rs aliases (4 deprecations) - 10 min
3. canonical-config security alias (1 deprecation) - 5 min

### Phase 2C: Type Re-export Aliases (20 min)
1. canonical.rs type aliases (6 deprecations) - 10 min
2. canonical_health.rs aliases (2 deprecations) - 5 min
3. Verify builds - 5 min

### Phase 2D: SecurityContext & DatabaseConfig (30 min)
1. Review SecurityContext usage patterns - 10 min
2. Consolidate or keep distinct - 10 min
3. Fix DatabaseConfig duplicate - 10 min

---

## 📁 **FILES TO MODIFY**

### Remove Duplicate Definitions (6 files)
1. `core/mcp/src/error/types.rs` - Remove ErrorContext
2. `core/mcp/src/enhanced/error_types.rs` - Remove ErrorContext
3. `core/plugins/src/context/mod.rs` - Remove ContextPlugin trait + struct
4. `providers/local/src/native/models.rs` - Remove HealthCheckConfig
5. `integration/web/src/auth/database.rs` - Rename DatabaseConfig

### Apply Deprecations (4 files)
1. `universal-patterns/src/config/types.rs` - 3 aliases
2. `universal-patterns/src/config/mod.rs` - 2 aliases
3. `main/src/universal/types.rs` - 4 aliases
4. `canonical-config/src/unified/security.rs` - 1 alias
5. `universal-patterns/src/types/canonical.rs` - 6 aliases
6. `universal-patterns/src/types/canonical_health.rs` - 2 aliases

### Update Imports (Estimated 15-20 files)
- All files using removed ErrorContext
- All files using removed ContextPlugin
- All files using removed HealthCheckConfig
- Test files

---

## ✅ **SUCCESS CRITERIA**

- [ ] All 6 duplicate structs removed or consolidated
- [ ] All 1 duplicate trait removed
- [ ] All 19 redundant aliases deprecated
- [ ] All imports updated to canonical versions
- [ ] Workspace builds cleanly
- [ ] All tests pass
- [ ] Zero breaking changes (deprecation only)
- [ ] Documentation updated

---

## 📈 **PROGRESS TRACKING**

**Target**: 26 duplications identified  
**To Remove**: 7 definitions  
**To Deprecate**: 19 aliases  
**Estimated Time**: 2-2.5 hours  

**Current Status**: Audit complete, ready for implementation

---

*Audit completed: September 30, 2025*  
*Next: Begin Phase 2A - Remove high-impact duplicates* 