# 🏗️ Architectural Issues: squirrel-plugins (Final 6 Errors)

**Date**: September 30, 2025  
**Status**: 93% Complete (84 → 6 errors)  
**Remaining**: 6 architectural design issues  

---

## 📊 Executive Summary

We've successfully fixed **78 of 84 errors** (93%) in squirrel-plugins through systematic pattern-based fixes. The remaining **6 errors** are all architectural design issues that require design decisions and potentially API changes.

### Error Breakdown
- **4 errors**: Async lifetime issues in `ZeroCostPlugin` trait (E0477)
- **1 error**: Missing `execute()` method on `Plugin` trait (E0599)
- **1 error**: Missing `handle_web_endpoint()` method (E0599)

---

## 🔴 Issue #1: Async Lifetime in ZeroCostPlugin Trait (4 errors)

### Location
`crates/core/plugins/src/zero_cost_plugin.rs`  
Lines: 182, 233, 284, 335

### Error Details
```
error[E0477]: the type `impl Future<Output = Result<String, <... as ZeroCostPlugin>::Error>>` 
does not fulfill the required lifetime
```

### Root Cause
The `ZeroCostPlugin` trait defines methods with `&self` that return `impl Future`, but the compiler cannot prove that the returned future doesn't capture references with lifetimes shorter than `'static`.

### Current Code Pattern
```rust
pub trait ZeroCostPlugin {
    async fn execute(&self, input: &str) -> Result<String, Self::Error>;
    // ↑ Problematic: `&self` lifetime conflicts with async return
}
```

### Why This Fails
When you have:
1. A trait method taking `&self`
2. Returning an `impl Future`
3. The future captures `&self`

The compiler needs to know the lifetime relationship, but `impl Future` hides this.

### Solutions

#### Option 1: Use `Box<dyn Future>` with explicit lifetimes ⭐ **Recommended**
```rust
pub trait ZeroCostPlugin {
    fn execute<'a>(&'a self, input: &'a str) 
        -> Box<dyn Future<Output = Result<String, Self::Error>> + Send + 'a>;
}
```

**Pros**: 
- Explicit lifetime control
- Trait object allows flexibility
- Well-understood pattern

**Cons**:
- Small heap allocation overhead
- Slightly more verbose

#### Option 2: Redesign to use message passing
```rust
pub trait ZeroCostPlugin {
    fn execute(&self, input: String, response_tx: oneshot::Sender<Result<String, Self::Error>>);
}
```

**Pros**:
- Avoids lifetime issues entirely
- Better for concurrent systems
- Matches MCP pattern (see TODO in websocket.rs)

**Cons**:
- More complex API
- Requires refactoring call sites

#### Option 3: Use `async-trait` crate ⚡ **Easiest**
```rust
use async_trait::async_trait;

#[async_trait]
pub trait ZeroCostPlugin {
    async fn execute(&self, input: &str) -> Result<String, Self::Error>;
}
```

**Pros**:
- Simple, just add macro
- Already used elsewhere in codebase
- Handles lifetimes automatically

**Cons**:
- Uses `Box<dyn Future>` under the hood
- Adds dependency (already present)

### Recommendation
**Use `#[async_trait]` macro (Option 3)** - it's already used throughout the codebase, and provides the cleanest API while handling lifetimes correctly.

### Implementation Steps
1. Add `use async_trait::async_trait;` to `zero_cost_plugin.rs`
2. Add `#[async_trait]` above the trait definition
3. Keep method signatures as-is
4. Recompile and verify

### Estimated Time
15-30 minutes

---

## 🔴 Issue #2: Missing `execute()` Method on Plugin Trait (1 error)

### Location
`crates/core/plugins/src/unified_manager.rs:109`

### Error Details
```
error[E0599]: no method named `execute` found for reference 
`&Arc<dyn plugin::Plugin + Send + Sync>` in the current scope
```

### Root Cause
The `Plugin` trait (in `plugin.rs`) only defines:
- `metadata()` - Get plugin metadata
- `initialize()` - Initialize the plugin
- `shutdown()` - Shutdown the plugin
- `as_any()` - Type casting helper

But `UnifiedPluginManager.execute_plugin()` tries to call `plugin.execute(input)`.

### Current Plugin Trait
```rust
#[async_trait]
pub trait Plugin: Send + Sync {
    fn metadata(&self) -> &PluginMetadata;
    async fn initialize(&self) -> Result<()>;
    async fn shutdown(&self) -> Result<()>;
    fn as_any(&self) -> &dyn Any;
    // ❌ No execute() method!
}
```

### Design Questions

#### Question 1: Should all plugins be executable?
- **Yes**: Add `execute()` to `Plugin` trait
- **No**: Create separate `ExecutablePlugin` trait

#### Question 2: What should execute() signature be?
```rust
// Option A: String input/output (current usage)
async fn execute(&self, input: &str) -> Result<String>;

// Option B: Generic with serde
async fn execute(&self, input: Value) -> Result<Value>;

// Option C: Typed request/response
async fn execute(&self, request: PluginRequest) -> Result<PluginResponse>;
```

### Solutions

#### Solution 1: Add execute() to Plugin trait ⭐ **Recommended**
```rust
#[async_trait]
pub trait Plugin: Send + Sync {
    fn metadata(&self) -> &PluginMetadata;
    async fn initialize(&self) -> Result<()>;
    async fn shutdown(&self) -> Result<()>;
    async fn execute(&self, input: &str) -> Result<String>; // ← Add this
    fn as_any(&self) -> &dyn Any;
}
```

**Pros**:
- Matches current usage
- Simple and clear
- Works for `UnifiedPluginManager`

**Cons**:
- Not all plugins may need execution
- String-based API is limiting

#### Solution 2: Create ExecutablePlugin trait
```rust
#[async_trait]
pub trait ExecutablePlugin: Plugin {
    async fn execute(&self, input: &str) -> Result<String>;
}
```

Then update `UnifiedPluginManager`:
```rust
pub struct UnifiedPluginManager {
    plugins: Arc<RwLock<HashMap<String, Arc<dyn ExecutablePlugin + Send + Sync>>>>,
}
```

**Pros**:
- Separates concerns
- Not all plugins need execute
- More flexible

**Cons**:
- More complex type system
- Requires refactoring

#### Solution 3: Remove UnifiedPluginManager.execute_plugin() 🗑️
If plugins shouldn't have a generic execute method, remove this functionality.

**Pros**:
- Simplifies design
- Forces specific plugin interfaces

**Cons**:
- Breaks current API
- May be needed for dynamic plugins

### Recommendation
**Solution 1: Add execute() to Plugin trait** for now, with a TODO to potentially refactor into ExecutablePlugin later.

### Implementation
```rust
// In plugin.rs
#[async_trait]
pub trait Plugin: Send + Sync {
    fn metadata(&self) -> &PluginMetadata;
    async fn initialize(&self) -> Result<()>;
    async fn shutdown(&self) -> Result<()>;
    
    /// Execute the plugin with string input
    /// 
    /// # Default Implementation
    /// Returns an error indicating execution is not supported.
    async fn execute(&self, _input: &str) -> Result<String> {
        Err(anyhow::anyhow!("Plugin does not support execution"))
    }
    
    fn as_any(&self) -> &dyn Any;
}
```

### Estimated Time
15-20 minutes

---

## 🔴 Issue #3: Missing `handle_web_endpoint()` Method (1 error)

### Location
`crates/core/plugins/src/zero_cost_plugin_dispatch.rs:107`

### Error Details
```
error[E0599]: no method named `handle_web_endpoint` found for reference `&ExampleWebPlugin`
```

### Root Cause
`ZeroCostPlugin::handle_web_endpoint()` calls `plugin.handle_web_endpoint()`, but:
1. `ExampleWebPlugin` implements `WebPlugin` trait
2. `WebPlugin` doesn't have `handle_web_endpoint()` method
3. There's a `WebPluginExt` trait that defines it, but it's not implemented

### Current Code
```rust
// In zero_cost_plugin_dispatch.rs
pub async fn handle_web_endpoint(&self, endpoint: &str, data: Value) -> Result<String> {
    match self {
        Self::ExampleWeb(plugin) => plugin.handle_web_endpoint(endpoint, data).await,
        //                                 ^^^^^^^^^^^^^^^^^^^ Method doesn't exist
        _ => Err(/*...*/),
    }
}
```

### WebPlugin vs WebPluginExt
```rust
// Current WebPlugin trait (in web/mod.rs)
pub trait WebPlugin: Plugin {
    fn get_endpoints(&self) -> Vec<WebEndpoint>;
    fn get_components(&self) -> Vec<WebComponent>;
    async fn handle_request(&self, request: WebRequest) -> Result<WebResponse>;
    async fn get_component_markup(&self, id: Uuid, props: Value) -> Result<String>;
}

// WebPluginExt trait (in plugin.rs) - SEPARATE!
pub trait WebPluginExt {
    async fn handle_web_endpoint(&self, endpoint: &str, data: Value) -> Result<String>;
}
```

### Solutions

#### Solution 1: Implement WebPluginExt for ExampleWebPlugin ⭐ **Recommended**
```rust
// In web/example.rs
#[async_trait]
impl crate::plugin::WebPluginExt for ExampleWebPlugin {
    async fn handle_web_endpoint(&self, endpoint: &str, data: Value) -> Result<String> {
        // Convert endpoint string to WebRequest and call handle_request
        let request = WebRequest {
            path: endpoint.to_string(),
            method: HttpMethod::Post,
            headers: HashMap::new(),
            body: Some(data),
            query_params: HashMap::new(),
            route_params: HashMap::new(),
        };
        
        let response = self.handle_request(request).await?;
        response.body
            .map(|b| serde_json::to_string(&b).unwrap_or_default())
            .ok_or_else(|| anyhow::anyhow!("No response body"))
    }
}
```

**Pros**:
- Uses existing infrastructure
- Doesn't change API
- Simple adapter pattern

**Cons**:
- Adds another trait implementation
- Somewhat redundant with handle_request

#### Solution 2: Merge WebPluginExt into WebPlugin
```rust
pub trait WebPlugin: Plugin {
    fn get_endpoints(&self) -> Vec<WebEndpoint>;
    fn get_components(&self) -> Vec<WebComponent>;
    async fn handle_request(&self, request: WebRequest) -> Result<WebResponse>;
    async fn handle_web_endpoint(&self, endpoint: &str, data: Value) -> Result<String>; // ← Add
    async fn get_component_markup(&self, id: Uuid, props: Value) -> Result<String>;
}
```

**Pros**:
- Single trait, clearer API
- No need for extension trait

**Cons**:
- Changes existing trait
- May be redundant with handle_request

#### Solution 3: Remove handle_web_endpoint from ZeroCostPlugin
If this method isn't needed, just remove it or return an error for non-web plugins.

**Pros**:
- Simplifies code
- No trait changes needed

**Cons**:
- May break intended functionality

### Recommendation
**Solution 1: Implement WebPluginExt** as a quick fix, then consider merging traits in future refactor.

### Estimated Time
20-30 minutes

---

## 📋 Implementation Priority

### Phase 1: Quick Wins (1 hour)
1. ✅ **Add `#[async_trait]` to ZeroCostPlugin trait** (30 min)
   - Fixes 4 lifetime errors
   - No API changes required
   
2. ✅ **Add execute() to Plugin trait with default impl** (20 min)
   - Fixes 1 error
   - Non-breaking (default implementation)
   
3. ✅ **Implement WebPluginExt for ExampleWebPlugin** (30 min)
   - Fixes 1 error
   - Simple adapter code

### Phase 2: After 100% Compilation
1. **Review and refactor trait hierarchy** (2-4 hours)
   - Consider ExecutablePlugin trait
   - Merge WebPlugin/WebPluginExt
   - Standardize error types
   
2. **Consider message-passing pattern** (4-6 hours)
   - For better async handling
   - Matches MCP pattern
   - Improves testability

---

## 🎯 Success Criteria

### Compilation Success
- [ ] All 6 errors resolved
- [ ] squirrel-plugins compiles cleanly
- [ ] No new warnings introduced
- [ ] Tests pass (after implementation)

### Code Quality
- [ ] Consistent with existing patterns
- [ ] Well-documented design decisions
- [ ] TODOs added for future refactoring
- [ ] No performance regressions

---

## 📚 Related Issues

### Similar Patterns in Codebase
1. **MCP WebSocket** (`crates/core/mcp/src/transport/websocket/mod.rs:234`)
   - Has TODO for same lifetime issue
   - Uses commented-out code + TODO
   - Should use same solution

2. **Plugin Trait Fragmentation**
   - Multiple Plugin trait definitions
   - Need consolidation
   - See: `UNIFICATION_AUDIT_REPORT_2025_09_30.md`

3. **Error Type Conversions**
   - anyhow::Error vs PluginError
   - Need consistent pattern
   - Currently using `Into::into`

---

## 💡 Design Recommendations

### Long-Term Architecture

#### 1. Unified Plugin Trait Hierarchy
```rust
// Core trait - lifecycle only
pub trait Plugin: Send + Sync {
    fn metadata(&self) -> &PluginMetadata;
    async fn initialize(&self) -> Result<()>;
    async fn shutdown(&self) -> Result<()>;
}

// Capability traits - compose as needed
pub trait ExecutablePlugin: Plugin {
    async fn execute(&self, request: PluginRequest) -> Result<PluginResponse>;
}

pub trait WebPlugin: Plugin {
    async fn handle_request(&self, request: WebRequest) -> Result<WebResponse>;
}

pub trait StreamingPlugin: Plugin {
    async fn stream(&self, input: impl Stream) -> impl Stream;
}
```

#### 2. Message-Based Communication
For complex async scenarios, use channels:
```rust
pub struct PluginExecutor {
    command_tx: mpsc::Sender<PluginCommand>,
}

pub enum PluginCommand {
    Execute { input: String, response: oneshot::Sender<Result<String>> },
    Shutdown { ack: oneshot::Sender<()> },
}
```

#### 3. Zero-Cost Where Possible
- Use enums for known plugin types (current approach)
- Trait objects only when truly dynamic
- Inline small methods
- Avoid unnecessary boxing

---

## ⏱️ Estimated Timeline

| Task | Time | Cumulative |
|------|------|------------|
| Add #[async_trait] | 30 min | 30 min |
| Add execute() method | 20 min | 50 min |
| Implement WebPluginExt | 30 min | 1h 20min |
| Testing & verification | 20 min | 1h 40min |
| Documentation | 20 min | **2 hours** |

**Total to 100% compilation: ~2 hours**

---

## ✅ Next Steps

1. **Immediate**: Implement the 3 fixes above
2. **Short-term**: Achieve 100% compilation
3. **Medium-term**: Review and refactor trait hierarchy
4. **Long-term**: Consider message-passing architecture

---

## 📞 Decision Points Needed

Before implementing, consider:

1. **Plugin execute() API**: String vs Value vs custom types?
2. **Trait granularity**: Monolithic vs composable traits?
3. **Async pattern**: Current vs message-passing?
4. **Error handling**: Single error type or per-trait errors?

---

**Status**: Ready for implementation  
**Risk Level**: Low (non-breaking changes)  
**Expected Success**: High (95%+)

---

*Generated: September 30, 2025*  
*Session: Evening Compilation Sprint*  
*Progress: 93% Complete (84 → 6 errors)* 