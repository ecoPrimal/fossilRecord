# 🚨 CRITICAL FINDING: HealthCheckConfig Massive Duplication

**Date**: September 30, 2025  
**Severity**: **HIGH** ⚠️  
**Discovered During**: Phase 2A Type Unification  

---

## 📊 **DISCOVERY**

While auditing duplicate type definitions, I discovered **16 separate definitions** of `HealthCheckConfig` across the codebase - a far more severe duplication issue than initially identified.

### **Initial Assumption**
- Expected: 2 definitions (canonical + 1 duplicate)
- **Reality**: **16 definitions** found

### **Impact**
- Maintenance nightmare: Changes must be replicated 16 times
- Inconsistency risk: Definitions may have diverged
- Cognitive load: Developers don't know which one to use
- Technical debt: High priority for consolidation

---

## 📋 **ALL 16 HEALTHCHECKCONFIG LOCATIONS**

### Canonical Source (1)
1. ✅ `canonical-config/src/services.rs:79` - **CANONICAL** (keep)

### Duplicates to Consolidate (15)

#### Integration Layer (2)
2. ❌ `ecosystem-api/src/types/health.rs:48`
3. ❌ `ecosystem-api/src/config/ai/unified_ai_tools/routing.rs:94`

#### Canonical Config (Duplicate within same crate!) (1)
4. ⚠️ `canonical-config/src/capability_based.rs:124` - **INTERNAL DUPLICATE**

#### Providers (1)
5. ❌ `providers/local/src/native/models.rs:84`

#### Main Crate (6)
6. ❌ `main/src/biomeos_integration/manifest.rs:159`
7. ❌ `main/src/biomeos_integration/mod.rs:123`
8. ❌ `main/src/ecosystem/types.rs:134`
9. ❌ `main/src/ecosystem/service_types.rs:71`
10. ❌ `main/src/monitoring/health.rs:52`
11. ❌ `main/src/monitoring/config.rs:16`

#### Core (1)
12. ❌ `core/core/src/routing/agent.rs:60`

#### Universal Patterns (1)
13. ❌ `universal-patterns/src/traits/service_types.rs:70`

#### MCP (3)
14. ❌ `core/mcp/src/resilience/health/mod.rs:147`
15. ❌ `core/mcp/src/enhanced/service_composition/health_types.rs:128`
16. ❌ `core/mcp/src/enhanced/service_composition/types/service.rs:397`

---

## 🎯 **CONSOLIDATION STRATEGY**

### Phase 1: Identify Canonical Source ✅

**Selected**: `canonical-config/src/services.rs:79`

**Rationale**:
- In the canonical-config crate (designed for this purpose)
- Most likely to have complete, well-designed structure
- Already exported as part of canonical config system

### Phase 2: Compare Definitions (Next Step)

Need to verify all 16 definitions have:
- Same fields?
- Same types?
- Same semantics?
- Any specializations?

### Phase 3: Create Migration Plan

1. **Mark all 15 duplicates as deprecated** (quick win)
2. **Update imports gradually** (low risk)
3. **Remove deprecated definitions** (after migration complete)

### Phase 4: Document Internal Duplicate

There's a duplicate **within canonical-config itself**:
- `canonical-config/src/services.rs:79` (primary)
- `canonical-config/src/capability_based.rs:124` (duplicate)

This needs immediate attention!

---

## 📈 **PRIORITY ASSESSMENT**

### Immediate (This Session)
- ⏳ Document finding (this file) ✅
- ⏳ Compare canonical definition with 2-3 samples
- ⏳ Deprecate 1-2 obvious duplicates as proof of concept

### Short-term (Next Session)
- Apply deprecation attributes to all 15 duplicates
- Fix internal canonical-config duplicate
- Update documentation

### Medium-term (This Week)
- Audit usage of each HealthCheckConfig
- Update imports to canonical version
- Verify tests pass

### Long-term (Next Sprint)
- Remove all deprecated definitions
- Update architecture docs
- Add lint rule to prevent future duplication

---

## 💡 **RECOMMENDATIONS**

### For This Session
**Don't try to fix all 16 now** - that's 2-3 hours of work minimum.

**Instead**:
1. ✅ Document the finding (done)
2. Fix the Context plugin duplicates (original plan)
3. Note HealthCheckConfig as a Phase 2.5 task

### For Next Session
**Dedicated HealthCheckConfig Consolidation Session**:
- Expected time: 2-3 hours
- Apply all 15 deprecations
- Fix canonical-config internal duplicate
- Verify builds

---

## 🔍 **ROOT CAUSE ANALYSIS**

### Why Did This Happen?

1. **Pre-canonical era**: Each crate defined its own
2. **Copy-paste pattern**: Developers copied instead of importing
3. **Lack of central authority**: No clear "one true source"
4. **Gradual growth**: Problem accumulated over time
5. **No enforcement**: No lint rules preventing duplication

### Prevention Strategy

1. ✅ Establish canonical-config as authority (done)
2. ⏳ Deprecate all duplicates (in progress)
3. ⏳ Add clippy lint: `warn_on_duplicate_type_definitions`
4. ⏳ Update CONTRIBUTING.md with guidelines
5. ⏳ Code review checklist: "Check for duplicate types"

---

## 📊 **IMPACT ON PHASE 2**

### Original Phase 2 Estimate
- 26 duplications identified
- 2-2.5 hours estimated

### Revised Estimate
- **26 + 15 additional HealthCheckConfig** = 41 duplications
- **Revised time**: 3-4 hours total

### Adjusted Plan
**Today (Current Session)**:
- Complete Context plugin duplicates ✅
- Document HealthCheckConfig finding ✅
- Leave HealthCheckConfig for dedicated session

**Next Session (HealthCheckConfig)**:
- Deprecate all 15 duplicates
- Fix canonical-config internal duplicate
- Update imports

---

## ✅ **SUCCESS CRITERIA**

### Complete When:
- [ ] All 15 HealthCheckConfig duplicates deprecated
- [ ] Canonical-config internal duplicate fixed
- [ ] All imports point to canonical version
- [ ] Tests pass
- [ ] Lint rule added
- [ ] Documentation updated

### Measurements:
- **Before**: 16 definitions
- **After**: 1 canonical definition
- **Reduction**: 94% fewer definitions

---

## 🚀 **NEXT ACTIONS**

1. **Continue with original Phase 2A plan** (Context duplicates)
2. **Schedule dedicated HealthCheckConfig session**
3. **Update Phase 2 documentation** with revised estimates
4. **Add to technical debt backlog**

---

**Status**: Finding documented, plan established  
**Priority**: HIGH (but deferred to dedicated session)  
**Estimated Fix Time**: 2-3 hours (dedicated session needed)

---

*Critical finding documented: September 30, 2025* 