# 🎯 Next Actions - Squirrel Unification

**Date**: October 2, 2025 (Evening)  
**Status**: Ready for execution  
**Current State**: 95%+ unified  
**Target**: 99%+ unified (14-18 hours)

---

## 🔥 IMMEDIATE PRIORITIES (Week 1)

### 1. Result Type Consolidation Sprint (3-4 hours)

**Goal**: Deprecate 40+ unnecessary Result type wrapper aliases

**Status**: 5/50+ deprecated, 45 remaining

**Action Plan**:

#### Step 1: Identify All Wrapper Aliases (30 min)
```bash
# Find all Result type aliases that wrap CanonicalResult
cd /home/eastgate/Development/ecoPrimals/squirrel
grep -r "pub type.*Result.*=.*CanonicalResult" --include="*.rs" crates/ > result_aliases.txt

# Review and categorize
cat result_aliases.txt
```

#### Step 2: Batch Deprecate (2 hours)
Create deprecation template:
```rust
#[deprecated(
    since = "4.5.0",
    note = "Use canonical_errors::CanonicalResult<T> directly.
    
Migration:
```rust
// Old:
use crate::DomainResult;
fn process() -> DomainResult<()> { ... }

// New:
use canonical_errors::CanonicalResult;
fn process() -> CanonicalResult<()> { ... }
```
All functionality preserved, this is a type alias removal."
)]
pub type DomainResult<T> = CanonicalResult<T>;
```

**Files to Modify** (estimated 15-20 files):
- [ ] crates/main/src/communication/mod.rs (EventResult)
- [ ] crates/main/src/universal/evolved_adapter/tracking.rs (TrackingResult)
- [ ] crates/main/src/universal/evolved_adapter/capabilities.rs (CapabilityResult)
- [ ] crates/universal-patterns/src/federation/consensus.rs (ConsensusResult)
- [ ] crates/tools/ai-tools/src/error.rs (AIResult)
- [ ] crates/integration/toadstool/src/errors.rs (ToadstoolResult)
- [ ] crates/canonical-errors/src/lib.rs (ProductionResult - if still exists)
- [ ] crates/main/src/error/mod.rs (SquirrelResult)
- [ ] crates/main/src/universal/types.rs (MainResult)
- [ ] ... ~10 more files

#### Step 3: Test Builds (30 min)
```bash
# Test canonical packages after each batch of 5 deprecations
cargo build -p canonical-errors -p canonical-config -p universal-patterns

# Verify zero errors
echo "Build status: $?"
```

#### Step 4: Update Documentation (30 min)
- [ ] Update CHANGELOG.md
- [ ] Update RESULT_TYPE_STRATEGY_2025_10_02.md with progress
- [ ] Commit with clear message

**Success Criteria**:
- [ ] 20+ additional aliases deprecated (total 25/50)
- [ ] All canonical packages build clean (0 errors)
- [ ] Migration guides added to each deprecation
- [ ] CHANGELOG updated

---

### 2. LoadBalancingStrategy Cleanup (2-3 hours)

**Goal**: Complete LoadBalancingStrategy unification

**Status**: Canonical exists, 4/14 deprecated, 10 remaining

**Action Plan**:

#### Step 1: Verify Canonical (15 min)
```bash
# Review canonical implementation
cat crates/canonical-config/src/services.rs | grep -A 50 "pub enum LoadBalancingStrategy"
```

Confirm all variants present:
- Basic: RoundRobin, Random, LeastConnections, WeightedRoundRobin
- Hash: ConsistentHash, IpHash
- Metric: QualityBased, ResponseTimeBased, HealthBased, Geographic, LowestLatency
- Advanced: Adaptive, CapabilityBased, First

#### Step 2: Deprecate Remaining Definitions (1.5 hours)

**Template**:
```rust
#[deprecated(
    since = "4.5.0",
    note = "Use canonical_config::services::LoadBalancingStrategy instead.
    
Migration:
```rust
// Old:
use crate::LoadBalancingStrategy;

// New:
use canonical_config::services::LoadBalancingStrategy;
```

All strategy variants are preserved. This is a drop-in replacement."
)]
pub enum LoadBalancingStrategy {
    // ... existing variants
}

// Add type alias for backward compatibility
pub type LoadBalancingStrategy = canonical_config::services::LoadBalancingStrategy;
```

**Files to Modify** (10 remaining):
- [ ] crates/main/src/communication/routing.rs:86
- [ ] crates/service-discovery/src/lib.rs
- [ ] crates/main/src/universal/agnostic_adapter.rs:96
- [ ] crates/main/src/universal/service_discovery.rs:38
- [ ] crates/universal-patterns/src/service_mesh/agnostic_mesh.rs
- [ ] crates/canonical-config/src/unified/mod.rs:313
- [ ] crates/canonical-config/src/unified/network.rs
- [ ] crates/core/mcp/src/enhanced/transport.rs:889 (if not done)
- [ ] ... 2 more locations

#### Step 3: Test & Verify (45 min)
```bash
# Build workspace
cargo build --workspace 2>&1 | grep -c "error:"

# Should be 0 or minimal

# Run relevant tests
cargo test -p canonical-config
cargo test -p service-discovery
```

#### Step 4: Documentation (30 min)
- [ ] Update unification_work/LOADBALANCING_UNIFICATION_AUDIT.md
- [ ] Update CHANGELOG.md
- [ ] Mark as complete in STATUS.md

**Success Criteria**:
- [ ] All 14 definitions deprecated
- [ ] Type aliases provide backward compatibility
- [ ] Zero breaking changes
- [ ] All builds pass
- [ ] Documentation complete

---

## 📋 WEEK 2 PRIORITIES

### 3. Deprecated Items Audit (3-4 hours)

**Goal**: Remove zero-usage deprecated items safely

#### Phase 1: Usage Audit (2 hours)
```bash
# For each deprecated item, check usage
cd /home/eastgate/Development/ecoPrimals/squirrel

# Example: Check PrimalConfig usage
grep -r "PrimalConfig" --include="*.rs" crates/ | grep -v "#\[deprecated\]" | wc -l

# If result is 0 or very low (1-2), mark for removal
```

**Items to Audit**:
- [ ] PrimalConfig (59 usages reported previously - recheck)
- [ ] UniversalPrimalConfig (9 usages)
- [ ] UniversalResult<T> (check usage)
- [ ] Config aliases (6 items)
- [ ] Trait aliases (6 items)
- [ ] Type aliases (10+ items)

#### Phase 2: Safe Removal (1 hour)
For items with **zero usage**:
1. Remove the deprecated item
2. Add comment documenting removal:
   ```rust
   // **REMOVED**: ItemName (deprecated since X.X.X, zero usage as of 4.5.0)
   // Use CanonicalReplacement instead
   ```
3. Build test
4. Commit

#### Phase 3: v5.0.0 Planning (30 min)
- [ ] Document removal timeline for items with active usage
- [ ] Update v5.0.0 breaking changes list
- [ ] Add migration reminders to CHANGELOG

---

### 4. Error Fragment Consolidation (2-3 hours)

**Goal**: Clarify error type strategy, consolidate fragments

#### Phase 1: Categorization (1 hour)
```bash
# List all error enums
grep -r "pub enum.*Error" --include="*.rs" crates/ > all_errors.txt

# Manually categorize into:
# 1. Canonical (keep CanonicalError)
# 2. Domain-specific (legitimate - keep)
# 3. Should migrate to CanonicalError
# 4. Generic "Error" (rename for clarity)
```

#### Phase 2: Migration (1-2 hours)
Focus on simple error enums that should use CanonicalError:
- [ ] core/interfaces/src/error.rs::SquirrelError (evaluate)
- [ ] Generic "Error" enums (rename or consolidate)
- [ ] Small domain-specific errors that fit CanonicalError variants

#### Phase 3: Documentation (30 min)
- [ ] Update architecture docs with error strategy
- [ ] Document when to use CanonicalError vs domain errors
- [ ] Provide examples and guidelines

---

## 🔄 QUICK WINS (1-2 hours each)

### A. Remove PrimalInstanceConfig ✅
**Status**: ALREADY DONE in previous session ✅

### B. Audit and Remove Zero-Usage Config Aliases (1 hour)
```bash
# Check each deprecated config alias
grep -r "PrimalConfig[^a-zA-Z]" --include="*.rs" crates/
grep -r "UniversalPrimalConfig" --include="*.rs" crates/
grep -r "CanonicalConfig[^a-zA-Z]" --include="*.rs" crates/
```

Remove if usage is zero.

### C. Fix Generic "Error" Enum Names (1 hour)
Rename for clarity:
- main/src/communication/commands.rs::Error → CommandError
- main/src/communication/routing.rs::Error → RoutingError
- core/core/src/lib.rs::Error → CoreLibError

---

## 📊 PROGRESS TRACKING

### Result Type Consolidation
- [x] 5 deprecated (v4.5.0)
- [ ] 15 more deprecated (target: 20 total)
- [ ] 20 more deprecated (target: 40 total)
- [ ] 10 remaining (legitimate exceptions)
- Target: <10 aliases (90% reduction)

### LoadBalancingStrategy
- [x] Canonical created
- [x] 4 deprecated
- [ ] 10 more deprecated
- Target: 14/14 deprecated (100%)

### Deprecated Items
- [x] 1 removed (PrimalInstanceConfig)
- [ ] Usage audit complete
- [ ] 10-20 more removed
- Target: <20 deprecated items (70% reduction)

### Error Fragments
- [ ] Categorization complete
- [ ] Strategy documented
- [ ] 5-10 consolidated
- Target: Clear error strategy

---

## 🎯 SUCCESS METRICS

### This Week
- [ ] 20+ Result aliases deprecated
- [ ] 10 LoadBalancing definitions deprecated
- [ ] 5-10 deprecated items removed
- [ ] Zero build errors maintained

### Next Two Weeks
- [ ] 40+ Result aliases deprecated
- [ ] 14 LoadBalancing definitions complete
- [ ] 20-30 deprecated items removed
- [ ] Error strategy documented

### Goal: 99%+ Unification (3-4 weeks)
- [ ] <10 Result type aliases
- [ ] 1 LoadBalancingStrategy
- [ ] <20 deprecated items
- [ ] Clear error strategy
- [ ] All documentation current

---

## 🛠️ TOOLS & COMMANDS

### Useful Grep Patterns
```bash
# Find Result type aliases
grep -r "pub type.*Result" --include="*.rs" crates/

# Find LoadBalancingStrategy definitions
grep -r "pub enum LoadBalancingStrategy" --include="*.rs" crates/

# Find deprecated items
grep -r "#\[deprecated" --include="*.rs" crates/ | wc -l

# Check usage of specific item
grep -r "ItemName" --include="*.rs" crates/ | grep -v "#\[deprecated\]"
```

### Build Verification
```bash
# Canonical packages (should be 0 errors)
cargo build -p canonical-errors -p canonical-config -p universal-patterns -p squirrel-sdk

# Full workspace (may have some errors in non-critical packages)
cargo build --workspace 2>&1 | tee build_log.txt
```

### Quality Checks
```bash
# Count errors
cargo build --workspace 2>&1 | grep -c "^error:"

# Count warnings
cargo build --workspace 2>&1 | grep -c "^warning:"

# Run clippy
cargo clippy -p canonical-errors -p canonical-config
```

---

## 📚 REFERENCE DOCUMENTS

### Essential Reading Before Starting
1. **RESULT_TYPE_STRATEGY_2025_10_02.md** (500 lines)
   - Complete strategy for Result types
   - Decision matrix
   - Keep vs deprecate guidelines

2. **unification_work/LOADBALANCING_UNIFICATION_AUDIT.md** (221 lines)
   - Complete LoadBalancing analysis
   - All 14 locations documented
   - Migration plan

3. **UNIFICATION_AUDIT_REPORT_2025_10_02.md** (850 lines)
   - Comprehensive fragmentation analysis
   - 6-phase roadmap
   - Effort estimates

### Progress Tracking
- **STATUS.md** - Current status (update after each session)
- **CHANGELOG.md** - Log all deprecations and changes
- **CLEANUP_PROGRESS_2025_10_02.md** - Detailed progress log

---

## 🚀 EXECUTION TIPS

### Best Practices
1. **Work in batches** - Deprecate 5-10 items at a time
2. **Test incrementally** - Build after each batch
3. **Document as you go** - Update progress files immediately
4. **Commit frequently** - Clear messages for each batch
5. **Don't rush** - Quality over speed

### Session Structure
1. **Warm-up** (15 min): Review documents, plan session
2. **Execute** (2-3 hours): Batch deprecations/removals
3. **Test** (30 min): Verify builds, run tests
4. **Document** (30 min): Update progress, commit
5. **Cool-down** (15 min): Plan next session

### Avoid Pitfalls
- ❌ Don't remove deprecated items without usage check
- ❌ Don't skip migration guides
- ❌ Don't forget to test builds
- ❌ Don't modify multiple systems simultaneously
- ✅ Do focus on one category at a time
- ✅ Do verify zero errors after each change
- ✅ Do update documentation immediately

---

**Ready to Execute**: ✅  
**Next Session**: Result Type Consolidation (3-4 hours)  
**Expected Outcome**: 20+ aliases deprecated, 0 errors maintained  

*"Systematic progress, one deprecation at a time."* 🎯 