# 📋 Result Type Strategy - October 2, 2025

**Purpose**: Define clear strategy for Result type aliases in the Squirrel codebase  
**Goal**: Reduce from 50+ variations to ~10-15 legitimate exceptions  
**Approach**: Categorize, deprecate, document

---

## 🎯 STRATEGY OVERVIEW

### Guiding Principles

1. **Use `CanonicalResult<T>` directly** for all canonical/unified code
2. **Domain-specific Result types** are legitimate when they wrap domain-specific errors
3. **Test/Helper convenience types** using `Box<dyn Error>` are acceptable
4. **Tool-specific Result types** are acceptable for standalone tools
5. **Eliminate unnecessary wrapper aliases** that add no value

---

## 📊 RESULT TYPE CATEGORIES

### Category 1: USE CANONICAL DIRECTLY ✅

**Rule**: Use `canonical_errors::CanonicalResult<T>` directly - no aliases needed

**Examples of DEPRECATED aliases** (unnecessary wrappers):
- ✅ `CommandResult<T> = CanonicalResult<T>` - **DEPRECATED 4.5.0**
- ✅ `ProductionResult<T> = CanonicalResult<T>` - **DEPRECATED 4.5.0**
- ✅ `CanonicalTraitResult<T> = CanonicalResult<T>` - **DEPRECATED 4.5.0**
- ✅ `PluginResult<T> = CanonicalResult<T>` - **DEPRECATED 4.5.0**
- ✅ `PrimalResult<T> = Result<T, CanonicalError>` - **DEPRECATED 4.2.0**
- ✅ `UniversalResult<T> = Result<T, CanonicalError>` - **DEPRECATED 4.1.0**

**Migration**:
```rust
// ❌ Old (deprecated):
use crate::CommandResult;
fn process() -> CommandResult<()> { ... }

// ✅ New (canonical):
use canonical_errors::CanonicalResult;
fn process() -> CanonicalResult<()> { ... }
```

**Target**: All canonical/unified code uses `CanonicalResult<T>` directly

---

### Category 2: LEGITIMATE DOMAIN-SPECIFIC ✅

**Rule**: Keep Result types that wrap domain-specific errors with valid reasons

#### 2A. Module Boundary Result Types (KEEP)

These provide clear semantics at module boundaries:

```rust
/// **KEEP** - Orchestration domain
pub type OrchestrationResult<T> = Result<T, OrchestrationError>;

/// **KEEP** - Federation domain  
pub type FederationResult<T> = Result<T, FederationError>;

/// **KEEP** - Infrastructure domain
pub type InfrastructureResult<T> = Result<T, InfrastructureError>;

/// **KEEP** - Authentication domain
pub type AuthResult<T> = Result<T, AuthError>;

/// **KEEP** - Database operations
pub type DatabaseResult<T> = Result<T, DatabaseError>;

/// **KEEP** - Web integration
pub type WebIntegrationResult<T> = Result<T, WebIntegrationError>;

/// **KEEP** - API operations
pub type ApiResult<T> = Result<Json<ApiResponse<T>>, ApiError>;
```

**Why Keep**: These represent legitimate domain boundaries with specific error types that provide valuable context and type safety.

#### 2B. Specialized Domain Errors (KEEP)

```rust
/// **KEEP** - Circuit breaker operations
pub type BreakerResult<T> = Result<T, BreakerError>;

/// **KEEP** - Transaction management
pub type TransactionResult<T> = Result<T, TransactionError>;

/// **KEEP** - Sovereignty validation
pub type SovereigntyResult<T> = Result<T, SovereigntyError>;

/// **KEEP** - Enhanced operations
pub type EnhancedResult<T> = Result<T, EnhancedError>;
```

**Why Keep**: Specialized domains with specific error handling requirements.

---

### Category 3: TEST/HELPER CONVENIENCE ✅

**Rule**: Keep convenience Result types for contexts where precise errors don't matter

```rust
/// **KEEP** - Test utilities
pub type TestResult<T> = Result<T, Box<dyn std::error::Error + Send + Sync>>;

/// **KEEP** - Helper functions
pub type HelperResult<T> = Result<T, Box<dyn std::error::Error + Send + Sync>>;

/// **KEEP** - Plugin testing
pub type PluginTestResult<T> = Result<T, PluginTestError>;

/// **KEEP** - Simple test utilities
pub type SimpleResult<T> = Result<T, SimpleError>;
```

**Why Keep**: In test and helper contexts, `Box<dyn Error>` provides maximum flexibility without requiring precise error types. This is standard Rust practice.

---

### Category 4: TOOL-SPECIFIC (KEEP) ✅

**Rule**: Standalone tools can have their own Result types

```rust
/// **KEEP** - CLI operations
pub type ConfigResult<T> = Result<T, ConfigError>;

/// **KEEP** - Rule system
pub type RuleSystemResult<T> = Result<T, RuleSystemError>;

/// **KEEP** - Migrator tools
pub type MigratorResult<T> = Result<T, UnwrapMigratorError>;
pub type ValidatorResult<T> = Result<T, SovereigntyValidatorError>;
pub type EliminatorResult<T> = Result<T, HardcodeEliminatorError>;
pub type AnalyzerResult<T> = Result<T, ContextAnalyzerError>;
pub type ReportResult<T> = Result<T, ReportGeneratorError>;
```

**Why Keep**: Tools are standalone and have their own error domains. Forcing CanonicalError on tools adds unnecessary complexity.

---

### Category 5: MODULE-INTERNAL CONVENIENCE (REVIEW)

**Rule**: Module-internal Result types that don't cross public API boundaries

#### Examples - Core/MCP Domain

```rust
/// **REVIEW** - MCP module convenience
pub type Result<T> = canonical_errors::CanonicalResult<T>;

/// **KEEP** - MCP protocol operations
pub type McpResult<T> = Result<T, McpError>;

/// **KEEP** - Resilience operations
pub type Result<T> = std::result::Result<T, ResilienceError>;

/// **KEEP** - Observability operations
pub type ObservabilityResult<T> = std::result::Result<T, ObservabilityError>;
```

**Decision**: Keep domain-specific errors, review generic `Result<T>` aliases

---

### Category 6: CANDIDATES FOR DEPRECATION ⚠️

**Rule**: Aliases that add no value and should be deprecated

#### 6A. CanonicalResult Wrappers (DEPRECATE)

Already deprecated or should be:

```rust
// ❌ DEPRECATED - Use CanonicalResult<T> directly
pub type CommandResult<T> = CanonicalResult<T>;
pub type ProductionResult<T> = CanonicalResult<T>;
pub type CanonicalTraitResult<T> = CanonicalResult<T>;
pub type PluginResult<T> = CanonicalResult<T>;
```

#### 6B. Confusing Duplicates (DEPRECATE)

```rust
// ❌ DEPRECATED - Conflicts with other PrimalResult
pub type PrimalResult<T> = Result<T, CanonicalError>;
pub type PrimalResult<T> = Result<T, UniversalError>;

// ❌ DEPRECATED - Unclear necessity
pub type CommandResult<T> = Result<T, CommandError>; // Multiple definitions!
pub type MCPResult<T> = Result<T, MCPError>; // Multiple definitions!
```

---

## 📋 DECISION MATRIX

| Result Type | Category | Keep? | Reason |
|-------------|----------|-------|--------|
| `CanonicalResult<T>` | Canonical | ✅ YES | Primary unified Result type |
| `CommandResult<T>` (wraps Canonical) | Unnecessary wrapper | ❌ DEPRECATED | Use CanonicalResult directly |
| `OrchestrationResult<T>` | Domain-specific | ✅ YES | Valid domain boundary |
| `TestResult<T>` | Test convenience | ✅ YES | Standard test practice |
| `ConfigResult<T>` (tool) | Tool-specific | ✅ YES | Standalone tool domain |
| `ProductionResult<T>` | Unnecessary wrapper | ❌ DEPRECATED | Use CanonicalResult directly |

---

## 🔄 MIGRATION STRATEGY

### Phase 1: Deprecate Wrappers (Current) ✅

**Status**: 5/~15 deprecated (CommandResult, ProductionResult×2, CanonicalTraitResult, PluginResult)

**Target**: Deprecate all unnecessary CanonicalResult wrappers

**Time**: 2-3 hours remaining

---

### Phase 2: Document Legitimate (Current) ✅

**Status**: In progress

**Target**: Document why each kept Result type is legitimate

**Examples**:
- OrchestrationResult ✅ Documented
- FederationResult ✅ Documented  
- HelperResult ✅ Documented
- TestResult ✅ Documented

---

### Phase 3: Audit Duplicates (Next)

**Target**: Find and consolidate duplicate Result type names

**Known Duplicates**:
- `CommandResult` - Multiple definitions
- `MCPResult` - Multiple definitions
- `PrimalResult` - Two conflicting definitions (already deprecated)
- `ObservabilityResult` - Multiple definitions
- `ConfigResult` - Multiple definitions

**Action**: Consolidate or differentiate with clearer names

---

### Phase 4: Final Cleanup (v5.0.0)

**Target**: Remove deprecated aliases after migration period

**Timeline**: v5.0.0 (6-12 months)

**Action**: Remove all deprecated Result wrappers

---

## 📊 CURRENT STATUS

### Result Types by Category

| Category | Count | Status |
|----------|-------|--------|
| Canonical (use directly) | 1 | ✅ Defined |
| Unnecessary wrappers | ~15 | ⚠️ 5/15 deprecated |
| Domain-specific (keep) | ~20 | ✅ Documented 4/20 |
| Test/Helper (keep) | ~5 | ✅ Documented 2/5 |
| Tool-specific (keep) | ~8 | ✅ Acceptable |
| Module-internal (review) | ~5 | ⚠️ Needs review |
| **TOTAL** | ~54 | ⚠️ In progress |

### Progress

- **Deprecated**: 5 unnecessary wrappers
- **Documented**: 6 legitimate types
- **Remaining**: ~43 to categorize and address
- **Target**: ~10-15 final exceptions (all documented)

---

## ✅ RECOMMENDATIONS

### For New Code

1. **Use `CanonicalResult<T>` directly** for all canonical/unified code
2. **Use domain-specific Result** only for clear domain boundaries
3. **Use `TestResult<T>`** for test code requiring flexibility
4. **Never create wrapper aliases** without clear justification

### For Existing Code

1. **Deprecate unnecessary wrappers** with migration guides
2. **Document legitimate exceptions** with clear reasoning
3. **Consolidate duplicates** with distinct names
4. **Schedule v5.0.0 removal** of deprecated items

### For Reviews

1. **Question any new Result alias** - is it necessary?
2. **Check for existing equivalent** before creating new
3. **Require documentation** justifying any kept alias
4. **Prefer CanonicalResult** unless clear reason not to

---

## 📝 EXCEPTIONS LOG

### Approved Exceptions (Documented)

1. **OrchestrationResult** - Orchestration domain boundary ✅
2. **FederationResult** - Federation domain boundary ✅
3. **HelperResult** - Helper function convenience ✅
4. **TestResult** - Test utility convenience ✅
5. **AuthResult** - Authentication domain boundary ✅
6. **DatabaseResult** - Database domain boundary ✅
7. **InfrastructureResult** - Infrastructure domain boundary ✅
8. **WebIntegrationResult** - Web integration domain ✅
9. **ApiResult** - API response wrapper ✅
10. **Tool-specific Results** - Standalone tool domains ✅

### Pending Review

- Module-internal `Result<T>` aliases
- Duplicate definitions (CommandResult, etc.)
- SDK-specific Result types
- Integration-specific Result types

---

## 🎯 SUCCESS CRITERIA

### Complete When:

- ✅ All unnecessary wrappers deprecated (<15 total)
- ✅ All legitimate exceptions documented (10-15 types)
- ✅ Duplicates consolidated or differentiated
- ✅ Clear migration guides for all deprecations
- ✅ Decision matrix documented
- ✅ Review guidelines established

### Metrics:

- **Start**: 50+ Result type aliases
- **Target**: 10-15 documented exceptions + 1 canonical
- **Current**: 54 identified, 5 deprecated, 6 documented
- **Progress**: ~20% complete

---

## 📚 REFERENCES

### Rust Best Practices

From Rust Error Handling guidelines:
- Use specific error types at domain boundaries
- Use `Box<dyn Error>` for convenience in examples/tests
- Avoid unnecessary type aliases that obscure meaning
- Prefer explicit over implicit

### Squirrel Canonical System

- **Canonical Error**: `canonical-errors::CanonicalError`
- **Canonical Result**: `canonical-errors::CanonicalResult<T>`
- **Migration Guide**: See deprecated items' documentation

---

**Document Version**: 1.0  
**Last Updated**: October 2, 2025  
**Status**: Living document - update as strategy evolves

*"One canonical Result type to rule them all, with documented exceptions for legitimate cases."* 