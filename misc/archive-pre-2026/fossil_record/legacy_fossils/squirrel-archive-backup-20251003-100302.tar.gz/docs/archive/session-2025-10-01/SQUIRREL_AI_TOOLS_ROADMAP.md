# 🗺️ squirrel-ai-tools Compilation Roadmap

**Created**: September 30, 2025  
**Status**: Partial progress (20%), complex modernization in progress  
**Current Errors**: ~60-70 (fluctuating due to dependency issues)  
**Estimated Completion**: 2-3 hours with systematic approach

---

## 📊 Current State Analysis

### What Works
- ✅ Error system partially modernized (`AIError` → `CanonicalError`)
- ✅ Some trait implementations fixed
- ✅ Basic structure in place

### Challenges Identified
1. **Config System Migration** - Incomplete
   - Mix of `canonical_config` and local config types
   - Circular dependencies in `config/mod.rs`
   - `UnifiedAIConfig` vs local types confusion

2. **Import Path Issues** - ~20 errors
   - `ChatChoice`, `ChatChoiceChunk` not in expected locations
   - `CostMetrics`, `PerformanceMetrics`, `ResourceRequirements` missing
   - Module reorganization incomplete

3. **Trait Modernization** - ~10 errors  
   - `LocalModelProvider` trait mismatch
   - Associated types not specified
   - `CanonicalProvider` interface incomplete

4. **Type Resolution** - ~15 errors
   - Struct/variant not found errors
   - Type aliases causing confusion
   - Mixed use of old/new patterns

---

## 🎯 Systematic Fix Strategy

### Phase 1: Stabilize Config System (30 min)
**Goal**: Get config imports working without circular dependencies

1. **Audit config module**
   - Map out what types are actually needed
   - Check `canonical-config` crate for available types
   - Create minimal local types if canonical not ready

2. **Fix imports**
   - `AIToolsConfig` - define or import clearly
   - `ProviderConfig` - implement struct properly
   - `LocalModelConfig` - resolve path

3. **Test**
   - Compile config module standalone
   - Verify no circular deps

### Phase 2: Fix Common Module Imports (45 min)
**Goal**: All common types accessible from correct paths

1. **Audit `common/` module structure**
   ```bash
   ls -la crates/tools/ai-tools/src/common/
   ```

2. **Fix type exports in `common/mod.rs`**
   - Ensure `ChatChoice`, `ChatChoiceChunk`, etc. exported
   - Check `types.rs` vs `capability.rs` organization
   - Verify `CostMetrics`, `PerformanceMetrics` location

3. **Update imports systematically**
   - Use `crate::common::types::*` pattern
   - Fix all `crate::common::ChatChoice` references
   - Update `use` statements in affected files

4. **Test incrementally**
   - Compile after each file fix
   - Track error count

### Phase 3: Trait Implementation Fixes (45 min)
**Goal**: All trait implementations complete and compatible

1. **LocalModelProvider trait**
   - Check trait definition in `local/mod.rs`
   - Compare with `universal-patterns` CanonicalAIProvider
   - Implement missing methods or create adapter

2. **AIClient implementations**
   - Verify all required methods present
   - Check signatures match trait exactly
   - Add default implementations where appropriate

3. **Associated types**
   - Specify all required associated types in trait objects
   - Use `<Error = ..., Config = ...>` syntax

### Phase 4: Type Resolution (30 min)
**Goal**: All types findable and properly imported

1. **Missing struct errors**
   - `ResourceRequirements` - import from `universal-patterns` or define
   - `CostMetrics` - check if in capability module
   - `PerformanceMetrics` - verify location

2. **Function not found**
   - `create_ollama_provider` - implement or remove call
   - `create_native_provider` - implement or remove call

3. **Test compilation**

---

## 📝 File-by-File Checklist

### Priority Files (Most Impact)
- [ ] `src/lib.rs` - Main exports, fix config imports
- [ ] `src/config/mod.rs` - Config type definitions
- [ ] `src/common/mod.rs` - Module exports
- [ ] `src/common/types.rs` - Type definitions
- [ ] `src/local/mod.rs` - Local provider setup

### Client Implementations
- [x] `src/common/clients/anthropic.rs` - Trait methods added
- [x] `src/common/clients/ollama.rs` - Trait methods added  
- [x] `src/common/clients/openai.rs` - Trait methods added

### Complex Files (Defer if needed)
- [ ] `src/local/ollama.rs` - Provider implementation
- [ ] `src/local/native.rs` - Native provider
- [ ] `src/router/*` - Routing logic

---

## 🔧 Tools & Commands

### Check specific error types
```bash
cargo check -p squirrel-ai-tools 2>&1 | grep "E0432" | wc -l  # Import errors
cargo check -p squirrel-ai-tools 2>&1 | grep "E0422" | wc -l  # Struct not found
cargo check -p squirrel-ai-tools 2>&1 | grep "E0046" | wc -l  # Missing trait items
cargo check -p squirrel-ai-tools 2>&1 | grep "E0191" | wc -l  # Associated types
```

### Find type definitions
```bash
find crates/tools/ai-tools/src -name "*.rs" -exec grep -l "pub struct ChatChoice" {} \;
rg "pub enum CostMetrics" crates/tools/ai-tools/
```

### Check module exports
```bash
rg "pub use" crates/tools/ai-tools/src/common/mod.rs
```

---

## ⚠️ Key Learnings

### What NOT to Do
1. ❌ Don't make sweeping changes across multiple files
2. ❌ Don't assume imports work without checking module structure
3. ❌ Don't mix `canonical_config` and local types randomly

### What DOES Work
1. ✅ Fix one error type at a time
2. ✅ Verify each fix compiles before moving on
3. ✅ Use explicit, fully-qualified imports
4. ✅ Add placeholder/stub implementations when needed
5. ✅ Test incrementally

---

## 📈 Progress Tracking

### Session 1 (Sept 30, 2025 Evening)
- **Starting**: 76 errors
- **After initial fixes**: 61 errors (20% reduction)
  - Fixed: Duplicate imports, AIError conversions, trait methods
- **After import changes**: Regressed to 240+ (reverted)
- **Status**: Need systematic approach, not fast fixes

### Next Session Goals
- [ ] Stabilize at <40 errors
- [ ] Get local module compiling
- [ ] Fix all import issues
- [ ] Target: 100% compilation!

---

## 🎯 Success Criteria

### Must Have
- ✅ 0 compilation errors
- ✅ All tests pass
- ✅ Warnings reduced to <20

### Nice to Have
- ✅ Clean imports (no `use crate::Error;` ambiguity)
- ✅ Proper config system (canonical-config fully integrated)
- ✅ Complete trait implementations (no TODOs in required methods)

---

**Recommendation**: Start fresh next session with Phase 1, take it slow and systematic. This crate is 80% there but needs careful attention to finish properly. 