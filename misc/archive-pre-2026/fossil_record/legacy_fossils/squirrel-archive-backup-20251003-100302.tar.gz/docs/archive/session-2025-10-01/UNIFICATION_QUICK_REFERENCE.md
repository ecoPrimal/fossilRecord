# 🚀 Unification Quick Reference Guide
**Date**: September 30, 2025  
**Full Report**: See `UNIFICATION_AUDIT_REPORT_2025_09_30.md`

---

## 📊 Current Status at a Glance

| System | Status | Priority | Hours |
|--------|--------|----------|-------|
| **Compilation** | 60% (3/5 crates) | 🔥 CRITICAL | 14-20h |
| **Error System** | 95% unified | ⚡ HIGH | 6-8h |
| **Configuration** | 83% unified | ⚡ HIGH | 8-10h |
| **Constants** | 92% consolidated | ✅ LOW | 1-2h |
| **Traits** | 67% consolidated | ⚡ HIGH | 10-12h |
| **Test Helpers** | 70% organized | ⚡ HIGH | 4-6h |
| **Deprecations** | 148+ warnings | ⚡ HIGH | 12-16h |

---

## 🎯 Critical Path (Get to 100% Compilation)

### 1. Fix squirrel-plugins (6-8 hours)
```bash
# Location: crates/squirrel-plugins/
# Errors: 84
# Main issues:
- Export CanonicalPluginOutput type
- Consolidate plugin trait definitions  
- Fix trait compatibility issues
```

### 2. Fix squirrel-ai-tools (6-8 hours)
```bash
# Location: crates/tools/ai-tools/
# Errors: 76
# Main issues:
- Migrate AI provider types to canonical
- Fix trait implementations
```

### 3. Workspace Validation (2-4 hours)
```bash
cargo check --workspace
cargo test --workspace
cargo clippy --workspace -- -D warnings
```

**Total**: 14-20 hours → **100% compilation** ✅

---

## 🔧 Quick Wins (High Impact, Low Effort)

### Test Helper Consolidation (4-6 hours)
**Impact**: Dramatically improves test utility discoverability

```
Move these files to test-utils crate:
├─ core/mcp/src/sync/tests/sync_modules/helpers.rs (212 lines)
├─ core/mcp/src/observability/tests/test_helpers.rs (185 lines)
├─ core/plugins/src/simple_test_utils.rs (91 lines)
├─ adapter-pattern-tests/src/test_utils.rs (49 lines)
└─ main/src/utils/test_helpers.rs (36 lines)

Organize as:
├─ test-utils/src/mcp.rs
├─ test-utils/src/plugins.rs
├─ test-utils/src/adapters.rs
└─ test-utils/src/common.rs
```

### Configuration Migration (8-10 hours)
**Impact**: Eliminates 148 deprecation warnings

```rust
// Find all uses of deprecated config
rg "CanonicalSquirrelConfig" --type rust

// Replace with
UnifiedSquirrelConfig

// Migration helper already exists:
config.to_unified()
ConfigMigrator::from_canonical(config)
```

---

## 📚 Canonical Systems Reference

### Error Handling
```rust
// ✅ USE THIS
use canonical_errors::{CanonicalError, CanonicalResult};

fn my_function() -> CanonicalResult<String> {
    Ok("success".to_string())
}

// ❌ DON'T USE THESE (deprecated)
type MyResult<T> = Result<T, MyError>;
type MainResult<T> = ...;
type PluginResult<T> = ...;
```

### Configuration
```rust
// ✅ USE THIS
use canonical_config::UnifiedSquirrelConfig;

let config = UnifiedSquirrelConfig::from_env()?;

// ❌ DON'T USE THIS (deprecated)
use canonical_config::CanonicalSquirrelConfig;
```

### Constants
```rust
// ✅ USE THIS
use universal_constants::{
    DEFAULT_TIMEOUT_SECS,
    DEFAULT_RETRY_DELAY_MS,
    DEFAULT_MAX_CONNECTIONS,
};

// ❌ DON'T USE THIS
const MY_TIMEOUT: u64 = 30; // Local constant
```

### Plugin Traits
```rust
// ✅ USE THIS (when consolidated)
use universal_patterns::traits::CanonicalPlugin;

// ❌ DON'T USE THESE (being consolidated)
use crate::local_plugin_trait::Plugin;
use some_other::UniversalPlugin;
```

---

## 🔍 Finding Fragments to Migrate

### Find Custom Result Types
```bash
find crates -name "*.rs" -exec grep -l "type.*Result.*=" {} \;
```

### Find Deprecated Config Usage
```bash
rg "CanonicalSquirrelConfig" --type rust
```

### Find Custom Error Types
```bash
rg "enum.*Error" --type rust | grep -v "CanonicalError"
```

### Find Test Helpers
```bash
find crates -name "*helper*.rs" -o -name "*test_util*.rs"
```

### Find TODO/FIXME Markers
```bash
rg "TODO|FIXME|HACK|XXX" --type rust
```

---

## 🚨 Common Migration Patterns

### Pattern 1: Migrate Result Type
```rust
// BEFORE
pub type MyResult<T> = Result<T, MyError>;

fn process() -> MyResult<String> {
    Err(MyError::SomeVariant)
}

// AFTER
use canonical_errors::{CanonicalError, CanonicalResult};

fn process() -> CanonicalResult<String> {
    Err(CanonicalError::internal("Some error"))
}
```

### Pattern 2: Migrate Configuration
```rust
// BEFORE
use canonical_config::CanonicalSquirrelConfig;

let config = CanonicalSquirrelConfig::from_env()?;

// AFTER
use canonical_config::UnifiedSquirrelConfig;

let config = UnifiedSquirrelConfig::from_env()?;

// Or use migration helper:
let unified_config = old_config.to_unified();
```

### Pattern 3: Consolidate Constants
```rust
// BEFORE (scattered across files)
const DEFAULT_TIMEOUT: u64 = 30;
const RETRY_DELAY: u64 = 500;

// AFTER (single source)
use universal_constants::{
    DEFAULT_TIMEOUT_SECS,
    DEFAULT_RETRY_DELAY_MS,
};
```

---

## 📋 Pre-Flight Checklist for New Code

Before committing new code, verify:

- [ ] Uses `CanonicalError` and `CanonicalResult<T>` (not custom Result types)
- [ ] Uses `UnifiedSquirrelConfig` (not deprecated CanonicalSquirrelConfig)
- [ ] Uses constants from `universal-constants` crate (not local constants)
- [ ] Uses canonical traits from `universal-patterns` (not local trait definitions)
- [ ] File is under 2000 lines (ideally under 500 for new files)
- [ ] No deprecated type aliases used
- [ ] No TODO/FIXME without ticket reference
- [ ] Tests are in test-utils or module-specific test dir
- [ ] Proper documentation with examples

---

## 🎯 Priority Matrix

```
HIGH IMPACT, HIGH EFFORT:
├─ Fix compilation errors (14-20h) → Enables testing
└─ Plugin trait consolidation (10-12h) → Resolves confusion

HIGH IMPACT, MEDIUM EFFORT:
├─ Configuration migration (8-10h) → Removes 148 warnings
├─ Result type migration (6-8h) → Unifies error handling
└─ Remove deprecated code (12-16h) → Reduces debt

HIGH IMPACT, LOW EFFORT:
├─ Test helper consolidation (4-6h) → Improves DX
└─ Error system finalization (6-8h) → Completes unification

LOW IMPACT, LOW EFFORT:
└─ Clean up deprecated constants (1-2h) → Minor cleanup
```

---

## 📞 Need Help?

### Resources
- **Full Audit Report**: `UNIFICATION_AUDIT_REPORT_2025_09_30.md`
- **Architecture Docs**: `docs/ARCHITECTURE.md`
- **Status Tracking**: `STATUS.md`
- **Session Progress**: `SESSION_PROGRESS_2025_09_30_DEEP_REFACTOR.md`

### Key Files
- **Canonical Errors**: `crates/canonical-errors/`
- **Unified Config**: `crates/canonical-config/`
- **Universal Constants**: `crates/universal-constants/`
- **Universal Patterns**: `crates/universal-patterns/`

### Tools
```bash
# Check compilation status
cargo check --workspace

# Count errors by crate
cargo check --workspace 2>&1 | grep "error\[" | cut -d'(' -f1 | sort | uniq -c

# Find deprecation warnings
cargo check --workspace 2>&1 | grep "warning: use of deprecated"

# Run tests
cargo test --workspace

# Format code
cargo fmt --all

# Run linter
cargo clippy --workspace -- -D warnings
```

---

**Last Updated**: September 30, 2025  
**Next Review**: After Phase 1 completion  
**Maintained By**: Development Team 