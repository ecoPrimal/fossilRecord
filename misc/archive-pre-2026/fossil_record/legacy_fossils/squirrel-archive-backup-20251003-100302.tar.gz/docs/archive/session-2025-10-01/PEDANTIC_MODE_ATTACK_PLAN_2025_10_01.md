# 🎯 PEDANTIC MODE ATTACK PLAN - October 1, 2025

**Total Warnings**: 3,570 🔥  
**Mode**: ULTRA-STRICT (pedantic + nursery + cargo)  
**Goal**: Zero warnings, absolute perfection  

---

## 📊 WARNING BREAKDOWN

### **By Category**
```
📦 Cargo Metadata:        ~50 warnings  (1.4%)  ← START HERE
📝 Documentation:       ~800 warnings  (22.4%) ← HIGH IMPACT
🎯 API Quality:         ~400 warnings  (11.2%) ← MEDIUM IMPACT
🔧 Code Quality:      ~2,320 warnings  (65.0%) ← LARGEST BUCKET
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Total:                  3,570 warnings
```

### **Top Warning Types**
```
1. doc_markdown                     (~800) - Missing backticks in docs
2. must_use_candidate               (~400) - Missing #[must_use]
3. cast_possible_truncation         (~300) - Unsafe casts
4. missing_errors_doc               (~250) - Undocumented errors
5. unused_async                     (~200) - Unnecessary async
6. cognitive_complexity             (~150) - Functions too complex
7. uninlined_format_args            (~100) - Use direct formatting
8. type_complexity                  (~100) - Complex types
9. wildcard_imports                 (~80)  - Use explicit imports
10. cargo_common_metadata           (~50)  - Missing Cargo metadata
```

---

## 🎯 ATTACK STRATEGY

### **Phase 1: Quick Wins (1-2 hours)** ⚡
**Target: ~900 warnings (25%)**

#### **1.1 Cargo Metadata (~50 warnings - 15 min)**
Add to all crate Cargo.toml files:
- `repository = "https://github.com/ecoPrimals/squirrel"`
- `keywords = ["ai", "coordination", "mcp", "ecosystem"]`
- `categories = ["development-tools"]`
- `readme = "README.md"` (where applicable)
- `license = "MIT OR Apache-2.0"`
- `description = "..."`

**Impact**: Eliminate all cargo::cargo_common_metadata warnings

---

#### **1.2 Documentation Backticks (~800 warnings - 1 hour)**
Use sed/ripgrep to add backticks around code terms in doc comments:
- Function names
- Type names
- Variable names
- Keywords

```bash
# Example: Convert "the Result type" to "the `Result` type"
# Can be semi-automated with careful patterns
```

**Impact**: Eliminate clippy::doc_markdown warnings

---

### **Phase 2: API Quality (2-3 hours)** 🎯
**Target: ~650 warnings (18%)**

#### **2.1 Add #[must_use] Attributes (~400 warnings - 1.5 hours)**
Add `#[must_use]` to:
- Pure functions (no side effects)
- Builder methods
- Constructors
- Query methods

```rust
#[must_use]
pub fn new() -> Self { ... }

#[must_use = "this returns a new value without modifying the original"]
pub fn with_config(self, config: Config) -> Self { ... }
```

**Impact**: Better API usability, clear intent

---

#### **2.2 Document Error Returns (~250 warnings - 1 hour)**
Add `# Errors` sections to all fallible functions:

```rust
/// Does something important
///
/// # Errors
/// Returns an error if the operation fails
pub fn do_thing() -> Result<()> { ... }
```

**Impact**: Better documentation, clearer error handling

---

### **Phase 3: Code Quality (4-6 hours)** 🔧
**Target: ~2,020 warnings (57%)**

#### **3.1 Fix Cast Truncation (~300 warnings - 1 hour)**
Replace `as` casts with:
- `.try_into()` for fallible conversions
- Explicit range checks
- `saturating_cast` where appropriate

```rust
// ❌ Before:
let x = big_number as u32;

// ✅ After:
let x = big_number.try_into()
    .context("value exceeds u32 range")?;
```

---

#### **3.2 Remove Unnecessary Async (~200 warnings - 45 min)**
Convert `async fn` to `fn` where no `.await` is used:

```rust
// ❌ Before:
async fn sync_operation() -> Result<i32> {
    Ok(42)
}

// ✅ After:
fn sync_operation() -> Result<i32> {
    Ok(42)
}
```

---

#### **3.3 Simplify Complex Functions (~150 warnings - 2 hours)**
Refactor functions with cognitive_complexity > 15:
- Extract helper functions
- Use early returns
- Simplify nested conditionals
- Break into smaller functions

---

#### **3.4 Inline Format Args (~100 warnings - 30 min)**
Use direct formatting:

```rust
// ❌ Before:
format!("Hello {}", name)

// ✅ After:
format!("Hello {name}")
```

---

#### **3.5 Simplify Type Complexity (~100 warnings - 1 hour)**
- Add type aliases for complex types
- Refactor nested generics
- Use newtype pattern

---

#### **3.6 Convert Wildcard Imports (~80 warnings - 30 min)**
Already have 3 remaining, but pedantic finds more internal ones:
- Replace `use module::*;` with explicit imports
- Document intentional wildcards

---

#### **3.7 Other Code Quality Issues (~1,090 warnings - varies)**
- Redundant clones
- Identical match arms
- Use of `Self` where appropriate
- Significant drop tightening
- And many more minor issues...

---

## 🎯 RECOMMENDED APPROACH

### **Option A: Pragmatic Perfection** (3-4 hours) ⭐ **RECOMMENDED**

**Focus on high-value, low-effort wins:**

1. ✅ **Cargo Metadata** (15 min) - 50 warnings eliminated
2. ✅ **Documentation Backticks** (1 hour) - 800 warnings eliminated
3. ✅ **#[must_use] Attributes** (1.5 hours) - 400 warnings eliminated
4. ✅ **Error Documentation** (1 hour) - 250 warnings eliminated

**Result**: ~1,500 warnings eliminated (42%), major quality improvements

**Remaining**: Mostly code-level pedantic suggestions (can address selectively)

---

### **Option B: Full Pedantic Perfection** (12-16 hours) 🔥

**Address ALL 3,570 warnings:**
- Complete Phases 1-3
- Fix every single pedantic suggestion
- Achieve zero warnings in ultra-strict mode

**Result**: Absolute perfection, but significant time investment

---

### **Option C: Metadata Only** (15 minutes) ⚡

**Just fix Cargo metadata:**
- Quick wins
- Publishable crates
- Professional appearance

**Result**: 50 warnings eliminated, ready for crates.io

---

## 💡 SMART AUTOMATION

### **Can Be Automated**
- ✅ Cargo metadata additions (templated)
- ✅ Inline format args (`cargo fmt` with 2021 edition)
- ✅ Many doc backticks (careful regex)
- ✅ Some unused async removals

### **Requires Manual Review**
- 🔍 #[must_use] placement (semantic decision)
- 🔍 Error documentation (domain knowledge)
- 🔍 Cognitive complexity refactoring (architectural)
- 🔍 Cast safety (business logic)

---

## 📊 ESTIMATED IMPACT

### **Code Quality Score**
```
Current (Standard Clippy):  100/100 ✅
Current (Pedantic Mode):     85/100 🟡
After Option A:              95/100 ⭐
After Option B:             100/100 🔥
```

### **Time vs Impact**
```
Option A: 3-4 hours  = 42% warnings fixed  (⭐ BEST ROI)
Option B: 12-16 hours = 100% warnings fixed (🔥 PERFECTION)
Option C: 15 minutes  = 1.4% warnings fixed  (⚡ QUICK WIN)
```

---

## 🎯 RECOMMENDATION

### **Start with Option A: Pragmatic Perfection**

**Why?**
1. ✅ Eliminates highest-impact warnings (docs, API)
2. ✅ Reasonable time investment (3-4 hours)
3. ✅ Major quality improvements
4. ✅ 95/100 pedantic score achieved
5. ✅ Remaining warnings are mostly style preferences

**Then decide**: 
- Stop here (95/100 is excellent) ✅
- Continue to 100/100 if you want absolute perfection 🔥

---

## 🚀 EXECUTION PLAN

### **If "Option A" Selected**

**Step 1: Cargo Metadata** (15 min)
- Create template Cargo.toml metadata
- Apply to all ~15 crates
- Verify with `cargo clippy --workspace -- -W clippy::cargo`

**Step 2: Documentation Backticks** (1 hour)
- Use `cargo fix` with doc_markdown where possible
- Manual review for accuracy
- Focus on public API first

**Step 3: #[must_use] Attributes** (1.5 hours)
- Identify candidates (pure functions, builders)
- Add attributes with helpful messages
- Test compilation

**Step 4: Error Documentation** (1 hour)
- Template `# Errors` sections
- Add to all `Result`-returning public functions
- Be specific about error conditions

**Step 5: Verify & Report** (30 min)
- Run full pedantic clippy
- Count remaining warnings
- Create completion report

---

## 🏆 SUCCESS METRICS

### **Phase 1 Complete**
- ✅ Zero cargo metadata warnings
- ✅ Zero doc_markdown warnings
- ✅ All public APIs documented
- ✅ Build remains clean

### **Option A Complete**
- ✅ ~1,500 warnings eliminated (42%)
- ✅ 95/100 pedantic score
- ✅ Professional, publishable code
- ✅ Clear, well-documented APIs

### **Option B Complete**
- ✅ 3,570 warnings eliminated (100%)
- ✅ 100/100 pedantic score
- ✅ Absolute perfection achieved
- ✅ Template for ecosystem

---

**Ready to Execute**: Which option do you choose?

1. **Option A** - Pragmatic Perfection (3-4 hours) ⭐
2. **Option B** - Full Perfection (12-16 hours) 🔥
3. **Option C** - Quick Win (15 min) ⚡
4. **Custom** - Tell me your preference

---

*"Pedantic mode: Where perfection meets pragmatism."* 🎯✨ 