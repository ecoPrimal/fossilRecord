# AdapterConfig Analysis & Consolidation Plan
**Date**: October 1, 2025  
**Status**: Review Complete  

---

## 📋 Summary

Found 8 AdapterConfig-related structs. Analysis reveals mix of legitimate domain-specific configs and one naming collision.

---

## ✅ Legitimate Domain-Specific Configs (Keep)

### 1. **ContextAdapterConfig** (2 definitions - need deduplication)
**Location 1**: `integration/context-adapter/src/adapter.rs`
**Location 2**: `core/context/src/adapter.rs`

**Purpose**: Context-specific configuration (max contexts, TTL, cleanup)
**Fields**: max_contexts, ttl_seconds, enable_auto_cleanup, enable_plugins

**Action**: Check if these are duplicates or serve different purposes. If duplicates, consolidate.

---

### 2. **MCPAdapterConfig**  
**Location**: `tools/ai-tools/src/router/mcp_adapter.rs`

**Purpose**: MCP protocol adapter configuration
**Domain**: MCP-specific routing and adaptation

**Action**: ✅ Keep - domain-specific for MCP protocol

---

### 3. **MonitoringAdapterConfig**  
**Location**: `core/mcp/src/observability/exporters/dashboard_exporter.rs`

**Purpose**: Monitoring/observability adapter configuration
**Domain**: Metrics export and dashboard integration

**Action**: ✅ Keep - domain-specific for monitoring

---

## 🟡 Configs Needing Review/Consolidation

### 4. **UniversalAdapterConfig** (DUPLICATE NAME - 2 different implementations!)
**Location 1**: `main/src/universal_adapter.rs`
- **Fields**: service_host, service_port
- **Purpose**: Simple service location config
- **Status**: ⚠️ NAMING COLLISION

**Location 2**: `main/src/universal/agnostic_adapter.rs`
- **Fields**: request_timeout, cache_ttl, circuit_breaker, load_balancing_strategy, max_retries, retry_delay, health_check_interval
- **Purpose**: Comprehensive adapter config with resilience features
- **Status**: ⚠️ NAMING COLLISION

**Problem**: Same name, different implementations, same crate!

**Recommendation**: 
- Rename #1 to `ServiceLocationConfig` or `UniversalAdapterServiceConfig`
- Keep #2 as `UniversalAdapterConfig` (more comprehensive)
- Or consolidate into one comprehensive config

---

### 5. **AdapterConfig** in `universal-patterns`
**Location**: `universal-patterns/src/adapter.rs`

**Fields**: timeout_seconds, max_retries, metrics_enabled, pool_size

**Analysis**: 
- Generic adapter configuration
- Overlaps with `ecosystem-api` AdapterConfig
- Less comprehensive than ecosystem-api version

**Recommendation**: 
- Consider deprecating in favor of `ecosystem-api` AdapterConfig
- Or position as lightweight alternative for simple use cases
- Document relationship between the two

---

### 6. **AdapterConfig** in `ecosystem-api` ✅
**Location**: `ecosystem-api/src/universal_adapter/config.rs`

**Fields**: network_coordination_enabled, discovery_timeout, service_timeout, max_retries, heartbeat_interval, standalone_fallback, known_endpoints

**Status**: ✅ Already consolidated (we cleaned up duplicate in types.rs)

**Action**: ✅ Keep as canonical for ecosystem networking

---

## 🎯 Action Plan

### High Priority

1. **Fix UniversalAdapterConfig Naming Collision**
   - Rename `main/universal_adapter.rs::UniversalAdapterConfig` → `ServiceLocationConfig`
   - Keep `main/universal/agnostic_adapter.rs::UniversalAdapterConfig`
   - Update all references

2. **Deduplicate ContextAdapterConfig**
   - Compare the two implementations
   - Keep one as canonical
   - Deprecate or remove the other

### Medium Priority

3. **Clarify AdapterConfig Relationship**
   - Document difference between `universal-patterns` and `ecosystem-api` versions
   - Consider deprecating `universal-patterns` version if truly redundant
   - Or document as "lightweight" vs "comprehensive"

---

## 📊 Summary Statistics

```
Total AdapterConfig-related structs: 8
├─ Legitimate domain-specific: 2 (MCPAdapterConfig, MonitoringAdapterConfig)
├─ Needs deduplication: 2 (ContextAdapterConfig x2)
├─ Naming collision: 2 (UniversalAdapterConfig x2)  ⚠️
├─ Needs relationship clarification: 2 (AdapterConfig in universal-patterns vs ecosystem-api)
└─ Already consolidated: 1 (ecosystem-api AdapterConfig) ✅
```

---

## 🔍 Detailed Findings

### Naming Collision Impact
The two `UniversalAdapterConfig` definitions in the same crate (main) create ambiguity:
- Different modules can't import both easily
- Confusing for developers
- Error-prone maintenance

### Recommended Structure
```
main/
  ├─ universal_adapter.rs
  │   └─ ServiceLocationConfig (renamed from UniversalAdapterConfig)
  └─ universal/agnostic_adapter.rs
      └─ UniversalAdapterConfig (comprehensive config)
```

---

**Status**: Ready for implementation  
**Estimated Time**: 30-45 minutes  
**Risk**: Low (mostly renames with clear migration paths) 