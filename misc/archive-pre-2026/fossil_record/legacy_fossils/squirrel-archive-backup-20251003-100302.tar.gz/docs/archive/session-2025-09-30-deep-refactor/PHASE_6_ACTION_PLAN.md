# 🎯 Phase 6 Unification Action Plan
**Current**: 97% Unified → **Target**: 100%  
**Estimated Time**: 15-20 hours  
**Breaking Changes**: ZERO (deprecation-based migration)

---

## 🔥 CRITICAL PRIORITIES (Do First)

### **Phase 6A: Config System Consolidation** - 2-3 hours
**Problem**: Two competing "canonical" configurations exist
- `CanonicalSquirrelConfig` (15 fields)
- `UnifiedSquirrelConfig` (18 fields) ← **Keep this one**

**Action Items**:
```bash
# 1. Audit current usage
grep -r "CanonicalSquirrelConfig" crates/ > config_audit_canonical.txt
grep -r "UnifiedSquirrelConfig" crates/ > config_audit_unified.txt

# 2. Count usages
wc -l config_audit_canonical.txt
wc -l config_audit_unified.txt

# 3. Deprecate CanonicalSquirrelConfig
# Edit: crates/canonical-config/src/lib.rs
# Add deprecation attribute to CanonicalSquirrelConfig

# 4. Update imports in primary crates
# - crates/main/src/lib.rs
# - crates/sdk/src/lib.rs
# - crates/universal-patterns/src/config/

# 5. Verify builds
cargo build --all-crates
cargo test --all-crates
```

**Files to Edit**:
- `crates/canonical-config/src/lib.rs` - Add deprecation
- `crates/main/src/config.rs` - Update imports
- `crates/sdk/src/lib.rs` - Update imports
- Documentation in `docs/`

---

### **Phase 6C: CommandHandler Consolidation** - 6-8 hours

**Problem**: 3+ duplicate CommandHandler trait definitions

**Locations**:
1. `crates/main/src/communication/commands.rs:30` (deprecated)
2. `crates/main/src/communication/mod.rs:48` (active)
3. `crates/sdk/src/communication/commands.rs:130` (deprecated)
4. `crates/universal-patterns/src/traits/ai_traits.rs` (canonical)

**Action Items**:
```bash
# 1. Find all CommandHandler references
find crates -name "*.rs" -exec grep -l "CommandHandler" {} \; > commandhandler_audit.txt

# 2. Review each file
cat commandhandler_audit.txt

# 3. Identify canonical trait
# Location: crates/universal-patterns/src/traits/ai_traits.rs or canonical_consolidated.rs

# 4. Create migration guide
# Document trait signature differences
# Provide migration examples

# 5. Deprecate duplicates incrementally
# Start with crates/main/, then crates/sdk/

# 6. Update implementations
# Focus on MCP server, plugin system first
```

**Files to Review** (20+):
- `crates/core/mcp/src/server/state/handlers.rs`
- `crates/core/plugins/src/commands/mod.rs`
- `crates/universal-patterns/src/traits/canonical_consolidated.rs`

---

## 🔧 HIGH PRIORITIES (Do Second)

### **Phase 6B: Result Type Consolidation** - 3-4 hours

**Problem**: 30+ domain-specific Result aliases remain

**Categories**:
1. **Pure Wrappers** (deprecate):
   - `OrchestrationResult<T>` → Use `CanonicalResult<T>`
   - `SovereigntyResult<T>` → Use `CanonicalResult<T>`

2. **Domain-Specific** (review, may keep):
   - `AuthResult<T>` - Auth crate
   - `CoreResult<T>` - Core crate
   - `PluginResult<T>` - Plugin system

3. **Placeholders** (remove):
   - `crates/core/mcp/src/protocol/types.rs:315`
     - `ValidationResult`, `RoutingResult`

**Action Items**:
```bash
# 1. List all Result type aliases
grep -r "pub type.*Result.*=" crates/ --include="*.rs" > result_aliases.txt

# 2. Categorize each
# Create spreadsheet: Alias | Location | Category | Action

# 3. Deprecate pure wrappers
# Add #[deprecated] with migration notes

# 4. Document domain-specific rationale
# Create docs/ERROR_HANDLING_GUIDE.md

# 5. Remove placeholders
# Delete or replace with concrete types
```

---

### **Phase 6D: Helper & Constant Consolidation** - 2-3 hours

**Tasks**:
1. **Environment Variable Helpers** (1 hour)
   - Find duplicates
   - Consolidate to `universal-patterns/helpers/env.rs`

2. **Validation Helpers** (30 min)
   - Consolidate to `universal-patterns/helpers/validation.rs`

3. **Constants Final Sweep** (1 hour)
   - Review module-level constants
   - Move cross-module constants to `universal-constants`
   - Document rationale for scattered constants

```bash
# Find scattered constants
grep -r "^const [A-Z_]" crates/ --include="*.rs" > constants_audit.txt

# Review and categorize
# Keep domain-specific, move shared
```

---

## ⚡ POLISH (Do Last)

### **Phase 6E: Deprecation Cleanup** - 2-3 hours

**Action Items**:
```bash
# 1. Find all deprecated items
grep -r "#\[deprecated" crates/ --include="*.rs" > deprecated_items.txt

# 2. Check usage of each
for item in $(grep -o "type [A-Za-z]*" deprecated_items.txt | cut -d' ' -f2); do
  echo "=== $item ==="
  grep -r "\b$item\b" crates/ --include="*.rs" | wc -l
done

# 3. Remove items with zero usage
# Edit files to remove deprecated definitions

# 4. Document removal timeline
# Update CHANGELOG.md
```

---

### **Phase 6F: TODO Elimination** - 15-30 minutes

**Single TODO Found**:
```rust
// Location: crates/core/plugins/src/zero_copy.rs:250
let endpoints = None; // TODO: Get from unified config

// Fix:
let endpoints = Some(config.network.endpoints.clone());
```

**Action Items**:
```bash
# 1. Fix the TODO
# Edit: crates/core/plugins/src/zero_copy.rs

# 2. Verify no other TODOs
grep -r "TODO" crates/ --include="*.rs" | grep -v "TaskStatus"

# 3. Document zero-TODO policy
# Add to CONTRIBUTING.md
```

---

## 📊 PROGRESS TRACKING

**Current Status**:
- [x] File Size Compliance: 100%
- [x] Error System: 95%
- [ ] **Config System: 92%** ← Phase 6A
- [x] Constants: 92%
- [ ] **Trait System: 85%** ← Phase 6C
- [x] Helper Functions: 95%
- [ ] **Deprecations: Managed** ← Phase 6E
- [x] Technical Debt: 99%

**Phase Completion**:
- [ ] Phase 6A: Config Consolidation (2-3h)
- [ ] Phase 6B: Result Types (3-4h)
- [ ] Phase 6C: Trait Consolidation (6-8h)
- [ ] Phase 6D: Helpers/Constants (2-3h)
- [ ] Phase 6E: Deprecation Cleanup (2-3h)
- [ ] Phase 6F: TODO Fix (15-30min)

**Total**: 15-20 hours → 100% Unified! 🎉

---

## 🎯 SESSION PLANNING

### **Session 1** (2-3 hours): Config Consolidation
```
Focus: Phase 6A
Goal: Single canonical config system
Output: Deprecated CanonicalSquirrelConfig, migration guide
```

### **Session 2** (3-4 hours): Result Types
```
Focus: Phase 6B
Goal: Review all Result aliases
Output: Deprecate pure wrappers, document domain-specific
```

### **Session 3** (3-4 hours): CommandHandler Start
```
Focus: Phase 6C.1 (partial)
Goal: Begin trait consolidation
Output: Migration guide, first deprecations
```

### **Session 4** (3-4 hours): CommandHandler Complete
```
Focus: Phase 6C.1-3 (complete)
Goal: All traits consolidated
Output: Canonical trait hierarchy established
```

### **Session 5** (2-3 hours): Final Consolidation
```
Focus: Phase 6D + 6E
Goal: Helpers, constants, deprecations
Output: 99.9% unified
```

### **Session 6** (30 min): Final Polish
```
Focus: Phase 6F
Goal: Fix TODO, final verification
Output: 100% UNIFIED! 🎉
```

---

## 🚀 QUICK START

**To begin immediately**:
```bash
# Step 1: Review the comprehensive report
cat COMPREHENSIVE_UNIFICATION_REPORT_2025_09_30.md

# Step 2: Start Phase 6A
cd /home/eastgate/Development/ecoPrimals/squirrel

# Audit configs
grep -r "CanonicalSquirrelConfig" crates/ > /tmp/config_canonical.txt
grep -r "UnifiedSquirrelConfig" crates/ > /tmp/config_unified.txt

# Review results
wc -l /tmp/config_*.txt

# Step 3: Begin editing
# Open: crates/canonical-config/src/lib.rs
# Add deprecation to CanonicalSquirrelConfig
```

---

## 📚 RELATED DOCUMENTS

- **Main Report**: `COMPREHENSIVE_UNIFICATION_REPORT_2025_09_30.md`
- **Previous Work**: `UNIFICATION_MODERNIZATION_REPORT_2025_09_30.md`
- **Phase 5 Plan**: `PHASE_5_UNIFICATION_PLAN.md`
- **Session Summary**: `SESSION_2025_09_30_SUMMARY.md`

---

## ✅ SUCCESS CRITERIA

**100% Unification Achieved When**:
- [ ] Single canonical config (no duplication)
- [ ] All traits consolidated
- [ ] All Result aliases reviewed
- [ ] 95%+ helpers centralized
- [ ] 95%+ constants in universal-constants
- [ ] All deprecated items have removal plans
- [ ] Zero TODO markers
- [ ] All crates building
- [ ] Documentation updated
- [ ] File size compliance maintained

---

**Last Updated**: September 30, 2025  
**Status**: Ready for Phase 6 Execution  
**Next Action**: Phase 6A - Config Consolidation 