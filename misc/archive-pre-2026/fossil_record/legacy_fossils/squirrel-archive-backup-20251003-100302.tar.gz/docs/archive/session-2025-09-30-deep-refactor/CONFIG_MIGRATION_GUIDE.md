# 🔧 Configuration Migration Guide
**Migration**: `CanonicalSquirrelConfig` → `UnifiedSquirrelConfig`  
**Status**: Incremental Migration (Phase 6A)  
**Timeline**: v4.3.0 (deprecation) → v5.0.0 (removal)

---

## 📊 MIGRATION STATUS

**Current State**:
- ✅ `CanonicalSquirrelConfig`: Deprecated as of v4.3.0 (258 usages)
- ✅ `UnifiedSquirrelConfig`: Target config (156 usages, growing)
- ⏳ Migration: **~40% complete** (156/414 total usages)

**Progress Tracking**:
```
Initial:  CanonicalSquirrelConfig (258) + UnifiedSquirrelConfig (156) = 414 total
Target:   UnifiedSquirrelConfig (414) = 100% migrated
Current:  38% migrated (156/414)
```

---

## 🎯 WHY MIGRATE?

### **Problems with CanonicalSquirrelConfig**:
1. **Flat structure** - All 19 fields at top level
2. **Mixed concerns** - System, network, security not properly separated
3. **Missing domains** - No MCP, edge, visualization, transport, production, resilience
4. **Legacy naming** - Doesn't follow "Unified*" convention
5. **Limited extensibility** - Hard to add new configuration domains

### **Benefits of UnifiedSquirrelConfig**:
1. ✅ **Hierarchical organization** - Clear domain separation
2. ✅ **Comprehensive** - 18 top-level domains covering all aspects
3. ✅ **Typed sub-configs** - UnifiedSystemConfig, UnifiedNetworkConfig, etc.
4. ✅ **Extensible** - Easy to add new domains
5. ✅ **Better validation** - Per-domain validation methods
6. ✅ **Modern design** - Follows unified architecture patterns

---

## 🚀 QUICK START MIGRATION

### **Option 1: Automatic Conversion** (Recommended)
```rust
use canonical_config::{CanonicalSquirrelConfig, UnifiedSquirrelConfig};

// Old code (deprecated)
let old_config = CanonicalSquirrelConfig::from_env()?;

// New code - automatic conversion
let new_config = old_config.to_unified();
```

### **Option 2: Direct Migration**
```rust
use canonical_config::UnifiedSquirrelConfig;

// Just use UnifiedSquirrelConfig directly
let config = UnifiedSquirrelConfig::from_env()?;
```

### **Option 3: Manual Migration with ConfigMigrator**
```rust
use canonical_config::{migration::ConfigMigrator, CanonicalSquirrelConfig};

let old_config = CanonicalSquirrelConfig::from_env()?;
let new_config = ConfigMigrator::from_canonical(old_config);
```

---

## 📋 FIELD MAPPING REFERENCE

### **CanonicalSquirrelConfig → UnifiedSquirrelConfig**

| Legacy Field (CanonicalSquirrelConfig) | Unified Field (UnifiedSquirrelConfig) | Notes |
|----------------------------------------|---------------------------------------|-------|
| `system` | `system` | Direct mapping, now typed as `UnifiedSystemConfig` |
| `network` | `network` | Direct mapping, now typed as `UnifiedNetworkConfig` |
| `security` | `security` | Direct mapping, now typed as `UnifiedSecurityConfig` |
| `ai` | `ai` | Direct mapping, now typed as `UnifiedAIConfig` |
| `monitoring` | `monitoring` | Direct mapping, now typed as `UnifiedMonitoringConfig` |
| `performance` | `performance` | Direct mapping, now typed as `UnifiedPerformanceConfig` |
| `testing` | `testing` | Direct mapping, now typed as `UnifiedTestingConfig` |
| `service_discovery` | `services.discovery` | **Moved** into services domain |
| `plugin_system` | `plugins` | **Renamed** to plugins |
| `storage` | `performance.storage` | **Moved** into performance domain |
| `environment` | `system.environment` | **Moved** into system domain |
| `universal_patterns` | `universal_patterns` | Separate field in UnifiedSquirrelConfig |
| `multi_instance` | `multi_instance` | Direct mapping |
| `federation` | `federation` | Direct mapping |
| `orchestration` | `services.orchestration` | **Moved** into services domain |
| `capability_discovery` | `services.capability_discovery` | **Moved** into services domain |
| `capability_based` | `services.capability_based` | **Moved** into services domain |
| `timeouts` | `network.timeouts` | **Moved** into network domain |
| `biomeos` | `biomeos` | Direct mapping, now typed as `UnifiedBiomeOSConfig` |
| _(missing)_ | `mcp` | **NEW** - MCP protocol configuration |
| _(missing)_ | `edge` | **NEW** - Edge computing configuration |
| _(missing)_ | `visualization` | **NEW** - Visualization configuration |
| _(missing)_ | `transport` | **NEW** - Transport layer configuration |
| _(missing)_ | `production` | **NEW** - Production deployment config |
| _(missing)_ | `resilience` | **NEW** - Fault tolerance configuration |

---

## 🛠️ MIGRATION PATTERNS

### **Pattern 1: Function Parameter Migration**

**Before**:
```rust
pub fn initialize(config: &CanonicalSquirrelConfig) -> Result<()> {
    let port = config.network.http_port;
    // ...
}
```

**After**:
```rust
pub fn initialize(config: &UnifiedSquirrelConfig) -> Result<()> {
    let port = config.network.http.port; // Note: hierarchical access
    // ...
}
```

---

### **Pattern 2: Struct Field Migration**

**Before**:
```rust
pub struct MyService {
    config: Arc<CanonicalSquirrelConfig>,
}

impl MyService {
    pub fn new(config: CanonicalSquirrelConfig) -> Self {
        Self {
            config: Arc::new(config),
        }
    }
}
```

**After**:
```rust
pub struct MyService {
    config: Arc<UnifiedSquirrelConfig>,
}

impl MyService {
    pub fn new(config: UnifiedSquirrelConfig) -> Self {
        Self {
            config: Arc::new(config),
        }
    }
    
    // Optional: Add compatibility method
    #[deprecated(since = "4.3.0", note = "Use new() with UnifiedSquirrelConfig")]
    pub fn from_legacy(legacy: CanonicalSquirrelConfig) -> Self {
        Self::new(legacy.to_unified())
    }
}
```

---

### **Pattern 3: Import Migration**

**Before**:
```rust
use canonical_config::{CanonicalSquirrelConfig, SystemConfig};
```

**After**:
```rust
use canonical_config::{UnifiedSquirrelConfig, UnifiedSystemConfig};
```

---

### **Pattern 4: Re-export Migration**

**Before**:
```rust
pub use canonical_config::CanonicalSquirrelConfig;
```

**After**:
```rust
pub use canonical_config::UnifiedSquirrelConfig;

// Optional: Provide backward compatibility alias
#[deprecated(since = "4.3.0", note = "Use UnifiedSquirrelConfig")]
pub type CanonicalSquirrelConfig = canonical_config::UnifiedSquirrelConfig;
```

---

## 📦 MODULE-BY-MODULE MIGRATION PLAN

### **Phase 1: Core Infrastructure** (High Priority)
- [ ] `crates/main/src/lib.rs` - Main entry point
- [ ] `crates/sdk/src/lib.rs` - SDK configuration
- [ ] `crates/canonical-config/src/optimizations.rs` - Config optimizations
- [ ] `crates/canonical-config/src/migration.rs` - Migration helpers

### **Phase 2: MCP System** (High Priority - 15+ files)
- [ ] `crates/core/mcp/src/lib.rs`
- [ ] `crates/core/mcp/src/server/state/api.rs`
- [ ] `crates/core/mcp/src/enhanced/service_composition/*.rs`
- [ ] `crates/core/mcp/src/protocol/production_handler.rs`
- [ ] `crates/core/mcp/src/observability/config.rs`
- [ ] `crates/core/mcp/src/resilience/config.rs`

### **Phase 3: Plugin System** (Medium Priority)
- [ ] `crates/core/plugins/src/production_manager.rs`
- [ ] `crates/plugins/src/*.rs`

### **Phase 4: Integration Layers** (Medium Priority)
- [ ] `crates/integration/api-clients/src/http/config.rs`
- [ ] `crates/ecosystem-api/src/*.rs`

### **Phase 5: Examples & Tests** (Low Priority)
- [ ] `crates/canonical-config/examples/unified_config_migration.rs`
- [ ] Test files using CanonicalSquirrelConfig

---

## ⚠️ BREAKING CHANGES (v5.0.0)

The following will be **removed** in v5.0.0:
- `CanonicalSquirrelConfig` struct
- `CanonicalConfig` type alias
- Legacy config field accessors

**Migration Timeline**:
- **v4.3.0** (now): Deprecation warnings added
- **v4.4.0 - v4.9.x**: Migration period, both configs supported
- **v5.0.0**: CanonicalSquirrelConfig removed

---

## 🔍 VERIFICATION

### **Check Your Migration**:
```bash
# Count remaining usages of deprecated config
grep -r "CanonicalSquirrelConfig" crates/ --include="*.rs" | wc -l

# Should see this decrease over time
```

### **Test Your Migration**:
```rust
#[test]
fn test_config_migration() {
    let legacy = CanonicalSquirrelConfig::default();
    let unified = legacy.to_unified();
    
    // Verify fields are preserved
    assert_eq!(legacy.system.name, unified.system.name);
    assert_eq!(legacy.network.http_port, unified.network.http.port);
}
```

---

## 💡 TIPS & BEST PRACTICES

### **Gradual Migration**:
1. ✅ Start with new code (use UnifiedSquirrelConfig)
2. ✅ Migrate one module at a time
3. ✅ Test after each module migration
4. ✅ Keep both configs working during transition
5. ✅ Update documentation as you migrate

### **Avoid These Mistakes**:
- ❌ Don't try to migrate all 258 usages at once
- ❌ Don't remove CanonicalSquirrelConfig before v5.0.0
- ❌ Don't forget to update tests
- ❌ Don't mix both configs in the same module

### **Do This Instead**:
- ✅ Migrate incrementally (5-10 files per session)
- ✅ Use `to_unified()` for easy conversion
- ✅ Provide backward compatibility where needed
- ✅ Update imports as you go
- ✅ Document any custom migration logic

---

## 📞 SUPPORT

### **Questions?**
- Review examples in `crates/canonical-config/examples/unified_config_migration.rs`
- Check existing UnifiedSquirrelConfig usage (156 examples)
- See migration helpers in `crates/canonical-config/src/migration.rs`

### **Issues?**
- Migration helper not working? Check field mapping reference above
- Tests failing? Verify new field paths (e.g., `network.http.port` not `network.http_port`)
- Type errors? Use `Unified*Config` types instead of legacy types

---

## 🎯 MIGRATION CHECKLIST

**For Each File You Migrate**:
- [ ] Update imports (CanonicalSquirrelConfig → UnifiedSquirrelConfig)
- [ ] Update function signatures
- [ ] Update struct fields
- [ ] Update field access paths (check hierarchical changes)
- [ ] Update tests
- [ ] Run `cargo build` to verify
- [ ] Run `cargo test` to verify tests pass
- [ ] Update documentation/comments
- [ ] Remove any `#[allow(deprecated)]` attributes

---

**Last Updated**: September 30, 2025  
**Status**: Active Migration (Phase 6A)  
**Next Review**: After Phase 2 completion

---

*This guide will be updated as migration progresses. Track progress in PHASE_6_ACTION_PLAN.md* 