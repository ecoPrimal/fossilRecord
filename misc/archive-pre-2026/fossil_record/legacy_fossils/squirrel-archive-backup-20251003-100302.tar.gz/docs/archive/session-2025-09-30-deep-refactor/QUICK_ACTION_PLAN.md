# 🎯 Quick Action Plan - Path to 100% Unification

**Status**: 97% Complete → Target: 100%  
**Estimated Time**: 2-3 days total  
**Current Blockers**: 5 crates with build errors

---

## 🚨 IMMEDIATE PRIORITY: Fix Build (Day 1-2)

### Failed Crates
1. **squirrel-plugins** - 84 errors
2. **squirrel-ai-tools** - 76 errors  
3. **service-discovery** - 5 errors
4. **squirrel-mcp** - 1 error
5. **squirrel_plugins_registry** - 1 error

### Commands to Run
```bash
# Check specific crates
cargo check -p squirrel-mcp 2>&1 | less
cargo check -p service-discovery 2>&1 | less
cargo check -p squirrel_plugins_registry 2>&1 | less
cargo check -p squirrel-plugins 2>&1 | less
cargo check -p squirrel-ai-tools 2>&1 | less

# Auto-fix warnings
cargo clippy --fix --allow-dirty --allow-staged -p <crate-name>
```

---

## 🔧 QUICK WINS (3-4 hours each)

### 1. Config System Unification
**Problem**: Two "canonical" configs exist
- `CanonicalSquirrelConfig` (lib.rs)
- `UnifiedSquirrelConfig` (unified/mod.rs)

**Solution**: Choose `UnifiedSquirrelConfig`, deprecate other
```bash
# Find all usages
rg "CanonicalSquirrelConfig" --type rust
```

### 2. Remove Deprecated Items
**50+ items** ready for removal
```bash
# Find all deprecated items
rg "#\[deprecated" --type rust

# Check for usage
rg "SquirrelResult" --type rust | grep -v "deprecated"
```

### 3. Consolidate Test Helpers
**7 files** to move to `test-utils`
```
crates/core/mcp/src/sync/tests/sync_modules/helpers.rs → test-utils
crates/core/mcp/src/integration/helpers.rs → test-utils
crates/core/mcp/src/observability/tests/test_helpers.rs → test-utils
crates/core/plugins/src/simple_test_utils.rs → test-utils
crates/main/src/utils/config_helpers.rs → canonical-config::helpers
crates/main/src/utils/test_helpers.rs → test-utils
crates/adapter-pattern-tests/src/test_utils.rs → test-utils
```

---

## 📊 PROGRESS TRACKING

### Current State
```
✅ Error System:       100% (CanonicalError)
✅ File Size:          100% (< 2000 lines)
✅ Constants:          92% (universal-constants)
⚠️  Build Status:       70% (5 crates failing)
⚠️  Config System:      95% (dual configs issue)
⏳ Helpers:            95% (7 files to move)
⏳ Deprecated Items:   Marked (ready for removal)
```

### Target State
```
✅ Error System:       100%
✅ File Size:          100%
✅ Constants:          95%+
✅ Build Status:       100%
✅ Config System:      100%
✅ Helpers:            100%
✅ Deprecated Items:   0 (removed)
```

---

## 🎯 DAILY BREAKDOWN

### Day 1: Build Stabilization
- [ ] Fix squirrel-mcp (1 error)
- [ ] Fix service-discovery (5 errors)
- [ ] Fix squirrel_plugins_registry (1 error)
- [ ] Start on squirrel-plugins (84 errors)
**Goal**: 3/5 crates building

### Day 2: Complete Build Fixes
- [ ] Finish squirrel-plugins
- [ ] Fix squirrel-ai-tools (76 errors)
- [ ] Run full workspace check
**Goal**: `cargo check --workspace` passes

### Day 3: Final Cleanup
- [ ] Config system unification (3-4 hours)
- [ ] Helper consolidation (2-3 hours)
- [ ] Deprecation removal (1-2 hours)
**Goal**: 100% unification complete

---

## 🏆 SUCCESS METRICS

- [ ] `cargo check --workspace` → 0 errors
- [ ] Single canonical config
- [ ] All helpers in canonical crates
- [ ] Zero deprecated code
- [ ] All files < 2000 lines (maintained)
- [ ] Documentation updated

---

## 📝 NOTES FOR REFERENCE

### Canonical Locations
- **Errors**: `canonical-errors::CanonicalError`
- **Config**: `canonical-config::UnifiedSquirrelConfig` (to be confirmed)
- **Constants**: `universal-constants::*`
- **Helpers**: `universal-constants::helpers`, `test-utils`, `canonical-config::helpers`
- **Traits**: `universal-patterns::traits::canonical_consolidated`

### Parent Directory Context
The parent `ecoPrimals/` directory contains:
- `beardog/`, `biomeOS/`, `songbird/`, `toadstool/` - related projects
- Reference only - we work on `squirrel/` exclusively

---

**Created**: September 30, 2025  
**For**: Squirrel Unification Sprint  
**See**: UNIFICATION_STATUS_2025_09_30_REVIEW.md (full details) 