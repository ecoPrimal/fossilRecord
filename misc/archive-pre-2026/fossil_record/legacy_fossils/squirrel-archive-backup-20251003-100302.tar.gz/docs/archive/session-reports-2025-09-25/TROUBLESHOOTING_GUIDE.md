# 🔧 **SQUIRREL UNIVERSAL AI PRIMAL - TROUBLESHOOTING GUIDE**

**Comprehensive guide for resolving common issues in development and deployment**

---

## 📋 **QUICK DIAGNOSTICS**

### **Health Check Commands**
```bash
# Check system status
cargo --version && rustc --version
docker --version && docker-compose --version

# Check build status
cargo check --workspace --exclude squirrel-mcp --exclude squirrel-sdk

# Check running services
docker ps | grep squirrel
kubectl get pods -n squirrel-production 2>/dev/null || echo "Kubernetes not configured"

# Check ports
sudo lsof -i :8080,3000,9090 | head -10
```

---

## 🚨 **COMPILATION ERRORS**

### **Issue: MCP Crate Won't Compile**
**Symptoms**: 
- `cargo build` fails with ~85 errors in `squirrel-mcp`
- Missing return statements, type mismatches

**Root Cause**: Incomplete function implementations, missing `Ok(())` returns

**Solution**:
```bash
# Work around the issue
cargo build --workspace --exclude squirrel-mcp

# Fix specific errors one by one
cd crates/core/mcp/
cargo check 2>&1 | head -5
```

**Common Fixes**:
```rust
// Before (causes error)
pub fn example_function() -> Result<(), MCPError> {
    // ... implementation
}

// After (fixed)
pub fn example_function() -> Result<(), MCPError> {
    // ... implementation
    Ok(())
}
```

### **Issue: SDK Crate Won't Compile**
**Symptoms**:
- `cargo build` fails with ~56 errors in `squirrel-sdk`
- Validation function errors, missing trait implementations

**Solution**:
```bash
# Work around the issue  
cargo build --workspace --exclude squirrel-sdk

# Fix validation functions
cd crates/sdk/src/infrastructure/error/
# Add Ok(()) to validation functions
```

### **Issue: Missing Return Statements**
**Pattern**: Functions returning `Result<(), Error>` but ending with `()`

**Quick Fix Script**:
```bash
# Find functions missing returns
grep -r "-> Result<(), " crates/ | grep -v "Ok(())"

# Common fix pattern
sed -i 's/^}$/    Ok(())\n}/' file.rs  # Add Ok(()) before closing brace
```

### **Issue: Async/Await Type Mismatches**
**Symptoms**: `expected future, found Result<_, _>`

**Solution**:
```rust
// Before (error)
if let Ok(mut state_guard) = state.lock() {

// After (fixed)  
if let Ok(mut state_guard) = state.lock().await {
```

---

## 🐳 **DOCKER ISSUES**

### **Issue: Permission Denied**
**Symptoms**: 
- `docker: permission denied while trying to connect`
- Cannot start containers

**Solution**:
```bash
# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker

# Restart docker service
sudo systemctl restart docker

# Test
docker run hello-world
```

### **Issue: Port Already in Use**
**Symptoms**: 
- `bind: address already in use`
- Cannot start monitoring stack

**Solution**:
```bash
# Find what's using the port
sudo lsof -i :8080
sudo lsof -i :3000
sudo lsof -i :9090

# Kill the process
sudo kill -9 <PID>

# Or change port in docker-compose
vim deployment/docker-compose.monitoring.yml
```

### **Issue: Docker Compose Fails**
**Symptoms**:
- `docker-compose up` fails
- Missing environment variables

**Solution**:
```bash
# Check environment
cat .env | grep -v "^#"

# Recreate containers
docker-compose down
docker-compose up -d --force-recreate

# Check logs
docker-compose logs -f
```

---

## ⚙️ **DEPENDENCY ISSUES**

### **Issue: SSL/TLS Errors**
**Symptoms**:
- `error: failed to run custom build command for openssl-sys`
- Build fails on SSL dependencies

**Solution**:
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install libssl-dev pkg-config build-essential

# CentOS/RHEL
sudo yum install openssl-devel pkgconfig gcc

# macOS
brew install openssl pkg-config
export PKG_CONFIG_PATH="/opt/homebrew/lib/pkgconfig"
```

### **Issue: Missing System Dependencies**
**Symptoms**:
- `cc` not found
- `pkg-config` not found

**Solution**:
```bash
# Ubuntu/Debian
sudo apt install build-essential pkg-config libssl-dev

# CentOS/RHEL  
sudo yum groupinstall "Development Tools"
sudo yum install pkgconfig openssl-devel

# Check installation
which cc && which pkg-config
```

### **Issue: Rust Version Incompatibility**
**Symptoms**:
- Edition 2021 errors
- Feature not available in current version

**Solution**:
```bash
# Update Rust
rustup update stable
rustc --version  # Should be 1.90.0+

# Set default toolchain
rustup default stable

# Clean and rebuild
cargo clean
cargo build
```

---

## 🌐 **NETWORK & CONNECTIVITY**

### **Issue: Cannot Connect to Services**
**Symptoms**:
- `connection refused` errors
- Health checks fail

**Solution**:
```bash
# Check service status
docker ps | grep squirrel
kubectl get pods -n squirrel-production

# Check network connectivity
curl -I http://localhost:8080/health
telnet localhost 8080

# Check firewall
sudo ufw status
sudo iptables -L | grep 8080
```

### **Issue: DNS Resolution Problems**
**Symptoms**:
- Cannot resolve hostnames
- Kubernetes services unreachable

**Solution**:
```bash
# Check DNS
nslookup localhost
dig @8.8.8.8 google.com

# Kubernetes DNS
kubectl get svc -n kube-system | grep dns
kubectl logs -n kube-system -l k8s-app=kube-dns
```

---

## 📊 **MONITORING & OBSERVABILITY**

### **Issue: Grafana Won't Start**
**Symptoms**:
- Grafana container exits immediately
- Cannot access http://localhost:3000

**Solution**:
```bash
# Check logs
docker-compose logs grafana

# Common issues:
# 1. Permission issues
sudo chown -R 472:472 deployment/grafana/

# 2. Port conflicts
sudo lsof -i :3000
# Change port in docker-compose.yml if needed

# 3. Configuration errors
cat deployment/grafana/grafana.ini
```

### **Issue: Prometheus Not Collecting Metrics**
**Symptoms**:
- No metrics in Grafana
- Prometheus targets down

**Solution**:
```bash
# Check Prometheus config
curl http://localhost:9090/config

# Check targets
curl http://localhost:9090/api/v1/targets

# Verify metrics endpoint
curl http://localhost:8080/metrics

# Check Prometheus logs
docker-compose logs prometheus
```

### **Issue: Missing Logs**
**Symptoms**:
- No application logs visible
- Log aggregation not working

**Solution**:
```bash
# Check log level
export RUST_LOG=debug
cargo run

# Check log files
ls -la logs/
tail -f logs/squirrel.log

# Docker logs
docker logs <container-id>
```

---

## 🏗️ **DEPLOYMENT ISSUES**

### **Issue: Kubernetes Deployment Fails**
**Symptoms**:
- Pods stuck in Pending/CrashLoopBackOff
- ImagePullBackOff errors

**Solution**:
```bash
# Check pod status
kubectl get pods -n squirrel-production
kubectl describe pod <pod-name> -n squirrel-production

# Check events
kubectl get events -n squirrel-production --sort-by='.lastTimestamp'

# Common fixes:
# 1. Image not found
docker images | grep squirrel
docker build -t squirrel:latest .

# 2. Resource constraints
kubectl describe node
kubectl top nodes

# 3. Configuration errors
kubectl get configmaps -n squirrel-production
kubectl get secrets -n squirrel-production
```

### **Issue: Service Discovery Problems**
**Symptoms**:
- Services cannot find each other
- Load balancer not working

**Solution**:
```bash
# Check services
kubectl get svc -n squirrel-production
kubectl get endpoints -n squirrel-production

# Test connectivity
kubectl exec -it <pod> -- curl http://service-name:port/health

# Check ingress
kubectl get ingress -n squirrel-production
```

---

## 🔐 **SECURITY & PERMISSIONS**

### **Issue: Authentication Failures**
**Symptoms**:
- 401/403 errors
- Cannot access protected endpoints

**Solution**:
```bash
# Check authentication config
cat config/agnostic.env | grep AUTH

# Test authentication
curl -H "Authorization: Bearer <token>" http://localhost:8080/api/status

# Check certificates
openssl x509 -in cert.pem -text -noout
```

### **Issue: Certificate Problems**
**Symptoms**:
- TLS handshake failures
- Certificate validation errors

**Solution**:
```bash
# Check certificate validity
openssl x509 -in deployment/certs/tls.crt -text -noout

# Test TLS connection
openssl s_client -connect localhost:443

# Regenerate certificates if needed
cd deployment/certs/
./generate-certs.sh
```

---

## ⚡ **PERFORMANCE ISSUES**

### **Issue: Slow Build Times**
**Symptoms**:
- `cargo build` takes >10 minutes
- High CPU usage during compilation

**Solution**:
```bash
# Use parallel compilation
export CARGO_BUILD_JOBS=8

# Enable incremental compilation
export CARGO_INCREMENTAL=1

# Use faster linker
sudo apt install lld
export RUSTFLAGS="-C link-arg=-fuse-ld=lld"

# Build only changed crates
cargo build --workspace --exclude squirrel-mcp --exclude squirrel-sdk
```

### **Issue: High Memory Usage**
**Symptoms**:
- OOM (Out of Memory) errors
- System becomes unresponsive

**Solution**:
```bash
# Monitor memory usage
top -p $(pgrep -f squirrel)
free -h

# Reduce parallel jobs
export CARGO_BUILD_JOBS=2

# Use release build for testing
cargo build --release --workspace --exclude squirrel-mcp --exclude squirrel-sdk
```

### **Issue: Slow Test Execution**
**Symptoms**:
- Tests take >5 minutes
- Timeouts in CI/CD

**Solution**:
```bash
# Run tests in parallel
cargo test --workspace --exclude squirrel-mcp --exclude squirrel-sdk -- --test-threads=8

# Run only unit tests
cargo test --lib

# Skip slow integration tests
cargo test --workspace --exclude integration_tests
```

---

## 🧪 **TESTING ISSUES**

### **Issue: Tests Fail Intermittently**
**Symptoms**:
- Flaky tests
- Race conditions

**Solution**:
```bash
# Run tests multiple times
for i in {1..10}; do cargo test test_name || break; done

# Increase timeouts
export TEST_TIMEOUT=60

# Run tests sequentially
cargo test -- --test-threads=1
```

### **Issue: Test Coverage Low**
**Symptoms**:
- Coverage below 70%
- Missing test cases

**Solution**:
```bash
# Generate coverage report
cargo tarpaulin --all-features --workspace --timeout 120 --out Html

# Identify uncovered code
open tarpaulin-report.html

# Add tests for critical paths
find . -name "*.rs" -exec grep -l "// TODO: add test" {} \;
```

---

## 🔄 **DEVELOPMENT WORKFLOW**

### **Issue: Git Conflicts on Cargo.lock**
**Symptoms**:
- Merge conflicts in Cargo.lock
- Dependencies out of sync

**Solution**:
```bash
# Delete and regenerate
rm Cargo.lock
cargo generate-lockfile

# Use cargo update carefully
cargo update --workspace
```

### **Issue: IDE/Editor Issues**
**Symptoms**:
- Rust analyzer not working
- No code completion

**Solution**:
```bash
# Restart Rust analyzer
# VS Code: Ctrl+Shift+P > "Rust Analyzer: Restart Server"

# Check rust-analyzer installation
rustup component add rust-analyzer

# Generate compile_commands.json
cargo build --workspace --exclude squirrel-mcp --exclude squirrel-sdk
```

---

## 📞 **GETTING HELP**

### **Diagnostic Information to Collect**
```bash
# System information
uname -a
cat /etc/os-release

# Rust toolchain
rustc --version --verbose
cargo --version

# Build information
cargo check --workspace 2>&1 | head -20
ls -la target/release/

# Docker information
docker version
docker-compose version
docker ps -a

# Kubernetes information (if applicable)
kubectl version --client
kubectl get nodes
kubectl get pods -A | grep squirrel
```

### **Log Collection**
```bash
# Collect all relevant logs
mkdir -p debug-logs
cargo build --workspace 2>&1 | tee debug-logs/build.log
docker-compose logs > debug-logs/docker.log
kubectl logs -n squirrel-production --all-containers=true > debug-logs/k8s.log 2>/dev/null || echo "No k8s logs"

# Package for support
tar -czf squirrel-debug-$(date +%Y%m%d).tar.gz debug-logs/
```

### **Performance Profiling**
```bash
# CPU profiling
cargo build --release
perf record -g ./target/release/demo
perf report

# Memory profiling
valgrind --tool=massif ./target/release/demo
ms_print massif.out.*

# Build time analysis
cargo build --timings
open cargo-timing.html
```

---

## 🎯 **KNOWN ISSUES & WORKAROUNDS**

### **Current Compilation Issues**
| **Component** | **Error Count** | **Workaround** | **ETA Fix** |
|---------------|----------------|----------------|-------------|
| MCP Core | ~85 errors | `--exclude squirrel-mcp` | 1 week |
| SDK | ~56 errors | `--exclude squirrel-sdk` | 1 week |
| WebSocket Transport | ~15 errors | Use mock transport | 3 days |
| Validation Functions | ~20 errors | Skip validation | 2 days |

### **Performance Limitations**
- **Build Time**: 5-10 minutes (normal for large Rust projects)
- **Memory Usage**: 2-4GB during compilation (expected)
- **Test Suite**: 3-5 minutes (can be parallelized)

### **Deployment Constraints**
- **Kubernetes**: Requires 1.20+ (for resource management)
- **Docker**: Requires 20.10+ (for BuildKit features)
- **Memory**: Minimum 8GB for development, 16GB recommended

---

## 🏁 **ESCALATION PATHS**

### **Level 1: Self-Service**
1. Check this troubleshooting guide
2. Search GitHub issues
3. Review logs and error messages
4. Try suggested workarounds

### **Level 2: Community Support**
1. Post in project discussions
2. Create detailed GitHub issue
3. Include diagnostic information
4. Tag relevant maintainers

### **Level 3: Expert Support**
1. Contact technical lead
2. Schedule debugging session
3. Provide complete environment reproduction
4. Consider pair programming session

---

**💡 Remember**: Most issues are compilation-related and have straightforward fixes. The architecture is solid, and the deployment infrastructure is production-ready. Focus on fixing one error at a time rather than trying to solve everything at once.

---

*Troubleshooting Guide - Last updated: September 24, 2025*  
*For updates: See GitHub Issues or contact the development team* 