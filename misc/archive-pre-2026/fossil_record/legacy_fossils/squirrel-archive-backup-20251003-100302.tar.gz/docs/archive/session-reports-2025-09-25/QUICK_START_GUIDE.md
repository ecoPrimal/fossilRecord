# 🚀 **SQUIRREL UNIVERSAL AI PRIMAL - QUICK START GUIDE**

**Welcome to the Squirrel Universal AI Primal Project!**  
*The next-generation Universal AI ecosystem with sovereignty-first design*

---

## 📋 **PREREQUISITES**

### **Required Tools**
```bash
# Rust toolchain (1.90.0+)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
rustup update

# Docker & Docker Compose
sudo apt install docker.io docker-compose-v2
sudo usermod -aG docker $USER

# Kubernetes tools (optional for local dev)
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install kubectl /usr/local/bin/

# Development tools
sudo apt install build-essential pkg-config libssl-dev
cargo install cargo-watch cargo-tarpaulin
```

### **System Requirements**
- **OS**: Linux (Ubuntu 20.04+), macOS (10.15+), Windows 10/11
- **RAM**: 8GB minimum, 16GB recommended
- **Storage**: 10GB free space
- **CPU**: 4+ cores recommended

---

## ⚡ **5-MINUTE SETUP**

### **1. Clone & Setup**
```bash
# Clone the repository
git clone https://github.com/your-org/squirrel.git
cd squirrel

# Set up environment
cp config/agnostic.env .env
source .env

# Install dependencies
cargo fetch
```

### **2. Build Core Components**
```bash
# Build working components (excludes problematic crates)
cargo build --release --workspace \
  --exclude squirrel-mcp \
  --exclude squirrel-sdk

# Verify build
ls target/release/ | head -10
```

### **3. Run Basic Tests**
```bash
# Test core functionality
cargo test --lib --workspace \
  --exclude squirrel-mcp \
  --exclude squirrel-sdk

# Quick integration test
cargo run --bin demo
```

### **4. Start Development Environment**
```bash
# Start monitoring stack
cd deployment/
docker-compose -f docker-compose.monitoring.yml up -d

# Access dashboards
open http://localhost:3000  # Grafana (admin/admin)
open http://localhost:9090  # Prometheus
```

---

## 🏗️ **PROJECT STRUCTURE**

### **Core Architecture**
```
squirrel/
├── crates/                    # 40 organized crates
│   ├── core/                 # Core system components
│   │   ├── auth/            # Authentication & authorization
│   │   ├── context/         # Context management
│   │   ├── mcp/             # MCP protocol (⚠️ needs fixes)
│   │   └── ...
│   ├── ecosystem-api/       # Universal ecosystem API
│   ├── universal-patterns/  # Universal AI patterns
│   ├── canonical-errors/    # Error handling system
│   ├── adapter-pattern-*/   # Adapter pattern implementations
│   ├── tools/               # AI tools and utilities
│   └── sdk/                 # Plugin SDK (⚠️ needs fixes)
├── deployment/              # Production deployment configs
├── docs/                    # Comprehensive documentation
├── examples/                # Usage examples
├── tests/                   # Integration tests
└── scripts/                 # Automation scripts
```

### **Key Components Status**
- ✅ **Universal Patterns**: Production ready
- ✅ **Canonical Errors**: Production ready  
- ✅ **Ecosystem API**: Production ready
- ✅ **Adapter Pattern**: Recently fixed, production ready
- ⚠️ **MCP Core**: ~15 compilation errors (1 week to fix)
- ⚠️ **SDK**: ~25 compilation errors (1 week to fix)

---

## 🔧 **DEVELOPMENT WORKFLOW**

### **Daily Development**
```bash
# Start development session
cargo watch -x "check --workspace --exclude squirrel-mcp --exclude squirrel-sdk"

# Run tests continuously
cargo watch -x "test --lib --workspace --exclude squirrel-mcp --exclude squirrel-sdk"

# Format and lint
cargo fmt --all
cargo clippy --all-targets --all-features
```

### **Working on Fixes**
```bash
# Focus on MCP fixes
cd crates/core/mcp/
cargo check 2>&1 | head -20
# Fix one error at a time

# Focus on SDK fixes  
cd crates/sdk/
cargo check 2>&1 | head -20
# Fix validation functions first
```

### **Testing Strategy**
```bash
# Unit tests
cargo test --lib -p crate-name

# Integration tests
cargo test --test integration_tests

# Coverage analysis
cargo tarpaulin --all-features --workspace --timeout 120
```

---

## 📚 **KEY CONCEPTS**

### **Universal AI Primal Architecture**
The project implements a **Universal AI Primal** - a sovereignty-first AI ecosystem that:
- **Federates** multiple AI systems while preserving autonomy
- **Adapts** to different AI providers and protocols
- **Scales** from single-node to multi-cluster deployments
- **Protects** human dignity and user sovereignty

### **Adapter Pattern System**
```rust
// Core trait for all adapters
#[async_trait]
pub trait CommandAdapter: Send + Sync {
    async fn execute(&self, name: &str, args: Vec<String>) -> CommandResult<String>;
    async fn list_commands(&self) -> CommandResult<Vec<String>>;
    async fn get_help(&self, name: &str) -> CommandResult<String>;
}

// Implementations: Registry, MCP, Plugin adapters
```

### **Canonical Error Handling**
```rust
use canonical_errors::{CanonicalError, CanonicalResult};

// Consistent error handling across all crates
fn example_function() -> CanonicalResult<String> {
    // ... implementation
    Ok("success".to_string())
}
```

---

## 🐛 **TROUBLESHOOTING**

### **Common Issues**

#### **Compilation Errors**
```bash
# Issue: MCP crate won't compile
# Solution: Work on other crates first
cargo build --workspace --exclude squirrel-mcp

# Issue: Missing return statements
# Solution: Add Ok(()) to functions returning Result<(), Error>
```

#### **Missing Dependencies**
```bash
# Issue: SSL/TLS errors
sudo apt install libssl-dev pkg-config

# Issue: Database connection errors  
# Solution: Check .env configuration
cat .env | grep -E "(DATABASE|DB_)"
```

#### **Docker Issues**
```bash
# Issue: Permission denied
sudo usermod -aG docker $USER
newgrp docker

# Issue: Port conflicts
docker-compose down
sudo lsof -i :8080  # Check what's using port 8080
```

### **Performance Issues**
```bash
# Enable debug logging
export RUST_LOG=debug

# Profile build times
cargo build --timings

# Memory usage analysis
cargo build --release
valgrind target/release/your-binary
```

---

## 🧪 **TESTING GUIDE**

### **Test Categories**
```bash
# Unit tests (fast)
cargo test --lib

# Integration tests (medium)  
cargo test --test '*'

# End-to-end tests (slow)
cargo test --test e2e_tests

# Benchmark tests
cargo bench
```

### **Writing Tests**
```rust
#[cfg(test)]
mod tests {
    use super::*;
    use canonical_errors::CanonicalError;

    #[tokio::test]
    async fn test_adapter_execution() {
        let adapter = RegistryAdapter::new();
        let result = adapter.execute("test", vec![]).await;
        assert!(result.is_ok());
    }
}
```

---

## 📊 **MONITORING & OBSERVABILITY**

### **Local Development Monitoring**
```bash
# Start monitoring stack
cd deployment/
docker-compose -f docker-compose.monitoring.yml up -d

# View logs
docker-compose logs -f grafana
docker-compose logs -f prometheus
```

### **Key Metrics to Watch**
- **Build Times**: Should be <5 minutes for full workspace
- **Test Coverage**: Target 90%+
- **Memory Usage**: <2GB for development builds
- **Response Times**: <100ms for core operations

### **Health Checks**
```bash
# Check service health
curl http://localhost:8080/health

# Check metrics endpoint
curl http://localhost:9090/metrics

# Verify database connectivity
cargo run --bin health_check
```

---

## 🚀 **DEPLOYMENT**

### **Local Development Deployment**
```bash
# Build and run locally
cargo build --release --workspace --exclude squirrel-mcp --exclude squirrel-sdk
./target/release/demo

# Docker development environment
docker-compose -f deployment/docker-compose.dev.yml up -d
```

### **Production Deployment**
```bash
# Build production images
docker build -f deployment/docker/Dockerfile.production -t squirrel:latest .

# Deploy to Kubernetes
kubectl apply -f deployment/kubernetes/production/

# Verify deployment
kubectl get pods -n squirrel-production
```

---

## 🎯 **CURRENT PRIORITIES**

### **Week 1: MCP Core Fixes**
- [ ] Fix WebSocket transport compilation errors
- [ ] Implement missing return statements
- [ ] Add proper error handling
- [ ] Test MCP message routing

### **Week 2: SDK Plugin System**
- [ ] Fix validation function return types
- [ ] Implement missing trait methods
- [ ] Add plugin loading tests
- [ ] Document plugin API

### **Week 3: Integration & Testing**
- [ ] Cross-crate integration testing
- [ ] End-to-end workflow validation
- [ ] Performance benchmarking
- [ ] Production readiness validation

---

## 📞 **GETTING HELP**

### **Documentation**
- **Architecture**: `docs/architecture/`
- **API Reference**: `cargo doc --open`
- **Deployment**: `deployment/production/`
- **Examples**: `examples/`

### **Development Resources**
- **Rust Book**: https://doc.rust-lang.org/book/
- **Async Rust**: https://rust-lang.github.io/async-book/
- **Tokio Guide**: https://tokio.rs/tokio/tutorial

### **Project Contacts**
- **Technical Lead**: [Your Name]
- **DevOps**: [DevOps Engineer]
- **Documentation**: See `PRODUCTION_READINESS_REPORT.md`

---

## ✅ **CHECKLIST FOR NEW DEVELOPERS**

### **Day 1**
- [ ] Clone repository and set up environment
- [ ] Build working components successfully
- [ ] Run basic tests
- [ ] Start monitoring stack
- [ ] Read architecture documentation

### **Week 1**
- [ ] Understand Universal AI Primal concepts
- [ ] Fix first compilation error
- [ ] Write first test
- [ ] Deploy local development environment
- [ ] Review codebase structure

### **Month 1**
- [ ] Complete MCP or SDK fixes
- [ ] Contribute to integration testing
- [ ] Deploy to staging environment
- [ ] Participate in code reviews
- [ ] Improve documentation

---

**🎉 Welcome to the team! The Squirrel Universal AI Primal is an exciting project with excellent architecture and huge potential. Let's build the future of sovereign AI together!**

---

*Quick Start Guide - Last updated: September 24, 2025*  
*For updates and issues: See GitHub Issues or contact the development team* 