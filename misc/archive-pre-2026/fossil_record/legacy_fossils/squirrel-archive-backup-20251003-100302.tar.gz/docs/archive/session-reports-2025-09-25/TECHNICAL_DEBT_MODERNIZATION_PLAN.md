# 🔧 **TECHNICAL DEBT MODERNIZATION PLAN**

**Squirrel Universal AI Primal - Deep Debt Elimination & Modernization**

---

## 🎯 **EXECUTIVE SUMMARY**

**Current Status**: ~141 compilation errors blocking production deployment  
**Root Cause**: Accumulated technical debt from rapid prototyping phase  
**Strategy**: Systematic modernization focusing on core compilation issues  
**Timeline**: 2-3 weeks focused debt elimination  

---

## 📊 **COMPILATION ERROR ANALYSIS**

### **Error Distribution by Category**

| **Category** | **Count** | **Priority** | **Effort** | **Crates Affected** |
|--------------|-----------|--------------|------------|-------------------|
| **Missing Return Statements** | ~45 | 🔴 HIGH | 2 days | MCP, SDK, Core |
| **Async/Await Type Mismatches** | ~25 | 🔴 HIGH | 3 days | MCP Transport |
| **Missing Trait Implementations** | ~20 | 🟡 MEDIUM | 2 days | SDK, Validation |
| **Undefined Types/Variants** | ~18 | 🔴 HIGH | 1 day | MCP Protocol |
| **Configuration/Environment** | ~15 | 🟡 MEDIUM | 1 day | SDK Config |
| **Import/Module Issues** | ~12 | 🟢 LOW | 1 day | Cross-crate |
| **Validation Function Issues** | ~6 | 🟡 MEDIUM | 1 day | SDK Validation |

### **Critical Path Dependencies**

```mermaid
graph TD
    A[Fix Return Types] --> B[Fix Async Patterns]
    B --> C[Complete Trait Implementations]
    C --> D[Resolve Type Definitions]
    D --> E[Fix Configuration Loading]
    E --> F[Integration Testing]
    F --> G[Production Ready]
```

---

## 🔥 **PRIORITY 1: MISSING RETURN STATEMENTS** 

### **Problem Pattern**
```rust
// ❌ BROKEN: Function promises Result but returns ()
pub fn validate_something() -> Result<(), Error> {
    if condition {
        return Err(Error::Invalid);
    }
    // Missing Ok(()) here!
}
```

### **Solution Pattern**
```rust
// ✅ FIXED: Explicit success return
pub fn validate_something() -> Result<(), Error> {
    if condition {
        return Err(Error::Invalid);
    }
    Ok(()) // Explicit success
}
```

### **Automated Fix Strategy**
```bash
# Script to identify and fix missing returns
find crates/ -name "*.rs" -exec grep -l "-> Result<(), " {} \; | \
while read file; do
    # Check if function ends without Ok(())
    if ! grep -q "Ok(())" "$file"; then
        echo "Needs fix: $file"
    fi
done
```

### **Files Requiring Fixes** (45 functions)
- `crates/core/mcp/src/utils.rs` - 8 validation functions
- `crates/sdk/src/infrastructure/error/validation.rs` - 12 functions  
- `crates/core/mcp/src/transport/mod.rs` - 6 trait implementations
- `crates/sdk/src/core/plugin.rs` - 15 WASM plugin functions
- `crates/core/mcp/src/lib.rs` - 4 initialization functions

---

## 🔥 **PRIORITY 2: ASYNC/AWAIT TYPE MISMATCHES**

### **Problem Pattern**
```rust
// ❌ BROKEN: Treating async Mutex like sync
if let Ok(mut state_guard) = state.lock() {
    // This expects sync lock, but state.lock() returns Future
}
```

### **Solution Pattern**
```rust
// ✅ FIXED: Proper async handling
if let Ok(mut state_guard) = state.lock().await {
    // Now properly awaits the Future
}
```

### **Critical Files** (25 errors)
- `crates/core/mcp/src/transport/websocket/mod.rs` - 15 async lock issues
- `crates/core/mcp/src/protocol/websocket.rs` - 6 future handling
- `crates/sdk/src/communication/mcp/` - 4 async client issues

---

## 🔥 **PRIORITY 3: UNDEFINED TYPES & VARIANTS**

### **Problem Areas**
```rust
// ❌ Missing enum variants
enum SocketCommand {
    Close,
    // Missing: SendMessage, Ping variants
}

// ❌ Missing enum variants  
enum ControlMessage {
    Shutdown,
    // Missing: MessageSent, ConnectionClosed variants
}
```

### **Solution Strategy**
1. **Complete enum definitions** in protocol modules
2. **Add missing struct fields** for configuration types
3. **Implement missing traits** for validation

---

## 🛠️ **MODERNIZATION STRATEGY**

### **Phase 1: Foundation Fixes (Week 1)**

#### **Day 1-2: Return Type Standardization**
```bash
# Target: Fix all missing Ok(()) returns
find crates/ -name "*.rs" -exec grep -l "-> Result<(), " {} \; | \
head -10 | xargs -I {} sh -c 'echo "Fixing: {}"; cargo check --manifest-path {} 2>&1 | head -5'
```

**Action Items**:
- [x] Identify all functions returning `Result<(), Error>` without `Ok(())`
- [ ] Create automated fix script
- [ ] Apply fixes to MCP utils (8 functions)
- [ ] Apply fixes to SDK validation (12 functions)
- [ ] Apply fixes to transport traits (6 functions)

#### **Day 3-4: Async Pattern Modernization**
```rust
// Modern async pattern template
async fn modern_async_function() -> Result<(), Error> {
    let mut guard = self.state.lock().await;
    guard.update_something()?;
    
    // Proper async error handling
    self.async_operation().await
        .map_err(|e| Error::Operation(e.to_string()))?;
    
    Ok(())
}
```

**Action Items**:
- [ ] Fix WebSocket transport async locks (15 errors)
- [ ] Modernize MCP protocol async handling (6 errors)
- [ ] Update SDK async client patterns (4 errors)

#### **Day 5: Type System Completion**
```rust
// Complete enum definitions
#[derive(Debug, Clone, PartialEq)]
pub enum SocketCommand {
    Close,
    SendMessage(String),
    Ping,
    Pong,
}

#[derive(Debug, Clone)]
pub enum ControlMessage {
    Shutdown,
    MessageSent { id: String, timestamp: u64 },
    ConnectionClosed { peer: String },
}
```

### **Phase 2: Architecture Modernization (Week 2)**

#### **Modern Error Handling Pattern**
```rust
// ✅ MODERN: Structured error handling
#[derive(thiserror::Error, Debug)]
pub enum ModernError {
    #[error("Configuration error: {message}")]
    Configuration { message: String },
    
    #[error("Network error: {source}")]
    Network { #[from] source: std::io::Error },
    
    #[error("Validation failed for field '{field}': {reason}")]
    Validation { field: String, reason: String },
}

// Result type alias for consistency
pub type ModernResult<T> = Result<T, ModernError>;
```

#### **Modern Async Patterns**
```rust
// ✅ MODERN: Proper async trait implementation
#[async_trait]
pub trait ModernTransport: Send + Sync {
    async fn connect(&self) -> ModernResult<()>;
    async fn send_message(&self, msg: Message) -> ModernResult<()>;
    async fn disconnect(&self) -> ModernResult<()>;
}

// ✅ MODERN: Structured async state management
pub struct ModernState {
    inner: Arc<RwLock<StateInner>>,
}

impl ModernState {
    pub async fn update<F, R>(&self, f: F) -> ModernResult<R> 
    where
        F: FnOnce(&mut StateInner) -> ModernResult<R> + Send,
    {
        let mut guard = self.inner.write().await;
        f(&mut *guard)
    }
}
```

### **Phase 3: Integration & Testing (Week 3)**

#### **Modern Testing Patterns**
```rust
// ✅ MODERN: Comprehensive async testing
#[cfg(test)]
mod tests {
    use super::*;
    use tokio_test;
    
    #[tokio::test]
    async fn test_modern_async_operation() {
        let service = ModernService::new().await.unwrap();
        
        let result = service.process_request(test_request()).await;
        
        assert!(result.is_ok());
        assert_eq!(result.unwrap().status, "success");
    }
    
    #[tokio::test]
    async fn test_error_handling() {
        let service = ModernService::new().await.unwrap();
        
        let result = service.process_invalid_request().await;
        
        assert!(matches!(result, Err(ModernError::Validation { .. })));
    }
}
```

---

## 📋 **DETAILED REMEDIATION PLAN**

### **MCP Core Fixes** (85 errors → 0 errors)

#### **File: `crates/core/mcp/src/utils.rs`**
```rust
// Fix 8 validation functions
pub fn validate_required_fields(fields: &[(&str, &str)]) -> Result<()> {
    for (field_name, field_value) in fields {
        if field_value.trim().is_empty() {
            return Err(MCPError::Validation(format!(
                "Required field '{field_name}' is empty"
            )));
        }
    }
    Ok(()) // ← ADD THIS
}

pub fn validate_string_length(value: &str, min: usize, max: usize) -> Result<()> {
    let length = value.len();
    if length < min || length > max {
        return Err(MCPError::Validation(format!(
            "String length {length} is not between {min} and {max}"
        )));
    }
    Ok(()) // ← ADD THIS
}
```

#### **File: `crates/core/mcp/src/transport/websocket/mod.rs`**
```rust
// Fix async lock patterns (15 errors)
async fn connect(&mut self) -> Result<()> {
    let mut state = self.connection_state.lock().await; // ← ADD .await
    if *state == WebSocketState::Connecting {
        *state = WebSocketState::Connected;
        info!("WebSocket transport connected successfully.");
    } else {
        warn!("WebSocket state changed during connection ({:?})", *state);
    }
    Ok(()) // ← ADD THIS
}

async fn send_raw(&self, bytes: &[u8]) -> Result<()> {
    if let Some(sender) = &*self.command_sender.lock().await {
        let cmd = SocketCommand::SendRaw(bytes.to_vec());
        if sender.send(cmd).await.is_err() {
            error!("WebSocket: Failed to send raw bytes command to writer task");
            return Err(MCPError::Transport(TransportError::SendError(
                "Writer task channel closed".to_string(),
            )));
        }
    }
    Ok(()) // ← ADD THIS
}
```

### **SDK Fixes** (56 errors → 0 errors)

#### **File: `crates/sdk/src/infrastructure/error/validation.rs`**
```rust
// Fix validation functions (12 errors)
pub fn validate_string_length(
    value: &str,
    field: &str,
    min: usize,
    max: usize,
) -> PluginResult<()> {
    let len = value.len();
    if len < min || len > max {
        return Err(crate::param_error!(
            field,
            format!("length {} not in range {}-{}", len, min, max)
        ));
    }
    Ok(()) // ← ADD THIS
}

pub fn validate_required_object_fields(
    obj: &serde_json::Map<String, serde_json::Value>,
    required_fields: &[&str],
) -> PluginResult<()> {
    for field in required_fields {
        if !obj.contains_key(*field) {
            return Err(crate::missing_param!(field));
        }
    }
    Ok(()) // ← ADD THIS
}
```

---

## ⚡ **IMPLEMENTATION TIMELINE**

### **Week 1: Core Compilation Fixes**
- **Mon**: Fix return type issues (45 functions)
- **Tue**: Fix async/await patterns (25 errors) 
- **Wed**: Complete missing type definitions (18 errors)
- **Thu**: Fix configuration loading (15 errors)
- **Fri**: Resolve import/module issues (12 errors)

### **Week 2: Architecture Modernization**
- **Mon**: Implement modern error handling patterns
- **Tue**: Modernize async trait implementations
- **Wed**: Update state management patterns
- **Thu**: Refactor configuration system
- **Fri**: Integration testing

### **Week 3: Validation & Production Prep**
- **Mon**: Comprehensive testing
- **Tue**: Performance validation
- **Wed**: Security audit
- **Thu**: Documentation updates
- **Fri**: Production deployment prep

---

## 🚀 **IMMEDIATE ACTION ITEMS**

### **Today: Start with Highest Impact Fixes**
```bash
# 1. Fix the easiest wins first - missing returns
cd crates/core/mcp/src/
grep -n "-> Result<(), " utils.rs | head -5

# 2. Create fix script
cat > fix_returns.sh << 'EOF'
#!/bin/bash
for file in $(find crates/ -name "*.rs" -exec grep -l "-> Result<(), " {} \;); do
    echo "Processing: $file"
    # Add Ok(()) before closing braces of functions that need it
    # (This is a simplified example - actual implementation needs more sophistication)
done
EOF

# 3. Test one file at a time
cargo check -p squirrel-mcp --lib 2>&1 | head -10
```

### **This Week: Systematic Debt Elimination**
1. **Focus on MCP core first** (highest error count)
2. **Fix one error type at a time** (don't mix concerns)
3. **Test after each batch** (prevent regression)
4. **Document patterns** (for team consistency)

---

## 📊 **SUCCESS METRICS**

### **Compilation Health**
- **Target**: 0 compilation errors by end of Week 2
- **Milestone 1**: MCP core compiles (Week 1, Day 3)
- **Milestone 2**: SDK compiles (Week 1, Day 5)
- **Milestone 3**: Full workspace compiles (Week 2, Day 1)

### **Code Quality Metrics**
- **Error Handling**: 100% structured error types
- **Async Patterns**: 100% modern async/await usage
- **Test Coverage**: 80%+ (up from current ~60%)
- **Documentation**: 95%+ (up from current ~80%)

---

## 🎯 **CONCLUSION**

The technical debt is **well-understood and fixable**. The issues are primarily:
1. **Mechanical fixes** (missing returns, async patterns)
2. **Incomplete implementations** (missing enum variants, trait methods)
3. **Legacy patterns** (old error handling, sync thinking in async code)

**This is NOT architectural debt** - the Universal AI Primal design is excellent. This is **implementation debt** from rapid prototyping that can be systematically eliminated.

**Recommended approach**: Start immediately with the highest-impact, lowest-risk fixes (missing returns) and work systematically through the categories.

---

*Technical Debt Modernization Plan - Created: September 24, 2025*  
*Next Review: October 1, 2025 (after Week 1 completion)* 