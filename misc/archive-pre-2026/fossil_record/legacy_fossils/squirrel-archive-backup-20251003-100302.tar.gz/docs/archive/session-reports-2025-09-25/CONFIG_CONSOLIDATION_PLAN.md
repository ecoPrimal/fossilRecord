# 🔧 Configuration Consolidation Plan
**Status**: Implementation Ready  
**Priority**: Critical - 795 Config structs need consolidation  
**Target**: Single canonical configuration system  

---

## 📊 Current State Analysis

### Configuration System Fragmentation
- **Total Config Structs**: 795 across codebase
- **Canonical System**: `canonical-config` crate (already exists!)
- **Parallel Systems**: `config/src/core/agnostic_config.rs` (921 lines)
- **Scattered Configs**: Domain-specific configs across 50+ files

### Top Fragmentation Sources
```
23 configs - crates/config/src/core/agnostic_config.rs
22 configs - crates/universal-patterns/src/config/types.rs
14 configs - crates/main/src/biomeos_integration/manifest.rs
13 configs - crates/ecosystem-api/src/config/domains/ai.rs
12 configs - Multiple files (context, canonical-config, etc.)
```

### Existing Canonical System Structure
```rust
// ALREADY EXISTS: canonical-config/src/lib.rs
pub struct CanonicalSquirrelConfig {
    pub system: SystemConfig,
    pub network: NetworkConfig,
    pub security: SecurityConfig,
    pub service_discovery: ServiceDiscoveryConfig,
    pub plugin_system: PluginSystemConfig,
    pub monitoring: MonitoringConfig,
    pub performance: PerformanceConfig,
    pub storage: StorageConfig,
    pub ai: AIConfig,
    pub environment: EnvironmentConfig,
    pub universal_patterns: UniversalPatternsConfig,
    pub multi_instance: MultiInstanceConfig,
    pub federation: FederationConfig,
    pub orchestration: OrchestrationConfig,
    pub capability_discovery: CapabilityDiscoveryConfig,
    pub timeouts: TimeoutConfig,
}
```

---

## 🎯 Consolidation Strategy

### Phase 1: Eliminate Parallel Systems (Priority 1)

#### 1.1 Merge Agnostic Config System
**Target**: `config/src/core/agnostic_config.rs` (23 configs, 921 lines)

**Action Plan**:
```rust
// CONSOLIDATE: Move valuable patterns from agnostic_config.rs to canonical-config
// ELIMINATE: Remove parallel AgnosticConfig system
// MIGRATE: Update all usages to CanonicalSquirrelConfig
```

**Migration Steps**:
1. Extract unique config patterns from `agnostic_config.rs`
2. Enhance `canonical-config` with missing capabilities
3. Update all imports to use `canonical-config::CanonicalSquirrelConfig`
4. Remove `config/src/core/agnostic_config.rs`

#### 1.2 Consolidate Universal Patterns Config
**Target**: `universal-patterns/src/config/types.rs` (22 configs)

**Action Plan**:
```rust
// MIGRATE: Move universal patterns configs to canonical-config/src/
// ENHANCE: CanonicalSquirrelConfig.universal_patterns field
// REMOVE: Duplicate config definitions
```

### Phase 2: Domain-Specific Consolidation (Priority 2)

#### 2.1 BiomeOS Integration Configs
**Target**: `main/src/biomeos_integration/manifest.rs` (14 configs)

```rust
// CONSOLIDATE INTO: CanonicalSquirrelConfig.biomeos_integration
pub struct BiomeOSIntegrationConfig {
    pub service: ServiceConfig,
    pub load_balancer: LoadBalancerConfig,
    pub health_check: HealthCheckConfig,
    pub scaling: ScalingConfig,
    pub service_mesh: ServiceMeshConfig,
    pub authentication: AuthenticationConfig,
    pub authorization: AuthorizationConfig,
    pub encryption: EncryptionConfig,
    pub ingress: IngressConfig,
    pub dns: DnsConfig,
    pub primal: PrimalConfig,
    pub manifest_parser: ManifestParserConfig,
}
```

#### 2.2 AI Domain Configs
**Target**: `ecosystem-api/src/config/domains/ai.rs` (13 configs)

```rust
// ENHANCE: CanonicalSquirrelConfig.ai field with comprehensive AI config
pub struct AIConfig {
    pub domain: CanonicalAIDomainConfig,
    pub model_management: ModelManagementConfig,
    pub inference_pipeline: InferencePipelineConfig,
    pub batch_processing: BatchProcessingConfig,
    pub streaming: StreamingConfig,
    pub optimization: PipelineOptimizationConfig,
    pub validation: ModelValidationConfig,
    pub providers: AIProvidersConfig,
    pub performance: AIPerformanceConfig,
    pub security: AISecurityConfig,
    pub routing: AIRoutingConfig,
    pub monitoring: AIMonitoringConfig,
}
```

### Phase 3: Test Configuration Consolidation (Priority 3)

#### 3.1 Eliminate Test Config Fragmentation
**Current Issue**: Test configs scattered across test files

**Solution**:
```rust
// CREATE: canonical-config/src/testing.rs
pub struct TestingConfig {
    pub deployment: DeploymentConfig,
    pub performance: PerformanceConfig,
    pub chaos: ChaosConfig,
    pub e2e: E2EConfig,
    pub fault_tolerance: FaultToleranceConfig,
}

// UPDATE: CanonicalSquirrelConfig.testing field
pub testing: Option<TestingConfig>, // Already exists!
```

---

## 🔧 Implementation Plan

### Week 1: Core Consolidation

#### Day 1-2: Audit and Plan
- [x] Complete config fragmentation audit (795 configs found)
- [x] Identify consolidation targets
- [ ] Create migration scripts for automated conversion

#### Day 3-4: Eliminate Parallel Systems
```bash
# Priority actions:
1. Enhance canonical-config with missing capabilities from agnostic_config.rs
2. Create migration script: agnostic_config → canonical-config
3. Update all imports across codebase
4. Remove parallel config systems
```

#### Day 5-7: Domain Consolidation
```bash
# Consolidate top fragmentation sources:
1. BiomeOS integration configs → canonical-config/src/biomeos.rs
2. AI domain configs → enhance canonical-config/src/ai.rs  
3. Universal patterns configs → canonical-config/src/universal_patterns.rs
4. Context configs → canonical-config/src/context.rs
```

### Week 2: Migration and Validation

#### Day 8-10: Codebase Migration
- [ ] Update all config usage to canonical system
- [ ] Remove fragmented config files
- [ ] Update tests to use unified config

#### Day 11-14: Validation and Testing
- [ ] Verify all configs load correctly
- [ ] Run comprehensive test suite
- [ ] Performance validation
- [ ] Documentation updates

---

## 🎯 Target Architecture

### Single Configuration Entry Point
```rust
// GOAL: Single import for all configuration needs
use canonical_config::CanonicalSquirrelConfig;

// ELIMINATE: Multiple config imports across codebase
// use some_crate::SomeConfig;
// use another_crate::AnotherConfig;
// use third_crate::YetAnotherConfig;
```

### Unified Configuration Loading
```rust
// GOAL: Consistent configuration loading pattern
let config = CanonicalSquirrelConfig::from_env()?;
config.validate()?;

// ELIMINATE: Multiple config loading patterns
// let config1 = SomeConfig::load()?;
// let config2 = AnotherConfig::from_file()?;
// let config3 = YetAnotherConfig::default();
```

### Domain-Specific Access
```rust
// GOAL: Clear domain boundaries within unified system
let ai_config = &config.ai;
let network_config = &config.network;
let security_config = &config.security;

// ELIMINATE: Scattered domain configs
// let ai_config = AIConfig::load()?;
// let network_config = NetworkConfig::new()?;
// let security_config = SecurityConfig::from_env()?;
```

---

## 📈 Success Metrics

### Quantitative Targets
- [ ] **<50 Config structs** (from 795)
- [ ] **Single config entry point** (`CanonicalSquirrelConfig`)
- [ ] **Zero parallel config systems**
- [ ] **100% canonical config usage**

### Qualitative Goals
- [ ] **Single source of truth** for all configuration
- [ ] **Consistent loading patterns**
- [ ] **Clear domain boundaries**
- [ ] **Maintainable structure**

---

## 🚀 Immediate Next Steps

### 1. Enhance Canonical Config System
```bash
# Add missing capabilities from agnostic_config.rs
cd crates/canonical-config/src/
# Review and enhance each domain module
```

### 2. Create Migration Scripts
```bash
# Automated migration tools
./scripts/migrate-configs.sh
```

### 3. Begin Systematic Migration
```bash
# Start with highest-impact files
1. config/src/core/agnostic_config.rs → Remove
2. universal-patterns/src/config/ → Migrate
3. main/src/biomeos_integration/manifest.rs → Consolidate
```

---

## 🔍 Validation Strategy

### Automated Validation
```bash
# Config consolidation progress tracking
echo "Config struct count: $(grep -r 'pub struct.*Config' crates --include='*.rs' | wc -l)"
echo "Canonical config usage: $(grep -r 'CanonicalSquirrelConfig' crates --include='*.rs' | wc -l)"
echo "Parallel config systems: $(grep -r 'AgnosticConfig\|SomeOtherConfig' crates --include='*.rs' | wc -l)"
```

### Integration Testing
- [ ] All configs load without errors
- [ ] Environment variable parsing works
- [ ] Validation catches configuration errors
- [ ] Performance benchmarks pass

---

## 🏁 Expected Outcome

**Before**: 795 scattered Config structs across 50+ files  
**After**: <50 Config structs in unified `canonical-config` system

**Impact**: 
- 90%+ reduction in configuration complexity
- Single source of truth for all configuration
- Consistent patterns across entire codebase
- Maintainable, scalable configuration architecture

**Status**: Ready to begin implementation immediately 🚀 