# 🔧 PLUGIN METADATA CONSOLIDATION PLAN

**Date**: October 1, 2025  
**Status**: IN PROGRESS  
**Priority**: 🔴 CRITICAL  
**Estimated Effort**: 8-13 hours

---

## 🔍 DISCOVERY: WORSE THAN EXPECTED

### Critical Finding
Not only do we have 15+ `PluginMetadata` definitions, we also have **3 different `CanonicalPluginMetadata` definitions**!

This means the "canonical" versions themselves are fragmented.

---

## 📊 CANONICAL VERSION ANALYSIS

### Found 3 "Canonical" Versions:

#### 1. `crates/core/plugins/src/canonical_metadata.rs` ⭐ MOST COMPREHENSIVE
```rust
pub struct CanonicalPluginMetadata {
    // Required
    pub id: Uuid,
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    
    // Identity & Discovery
    pub id_alias: Option<String>,
    pub plugin_type: PluginType,
    pub categories: Vec<String>,
    pub tags: Vec<String>,
    pub keywords: Vec<String>,
    
    // Capabilities & Dependencies
    pub capabilities: Vec<String>,
    pub dependencies: Vec<PluginDependency>,
    pub interfaces: Vec<String>,
    
    // Legal & Documentation
    pub license: Option<String>,
    pub homepage: Option<String>,
    pub repository: Option<String>,
    pub documentation: Option<String>,
    
    // Compatibility & Versioning
    pub api_version: Option<String>,
    pub min_squirrel_version: Option<String>,
    pub max_squirrel_version: Option<String>,
    
    // Runtime
    pub entry_point: Option<String>,
    pub additional_metadata: HashMap<String, serde_json::Value>,
}
```
**Status**: ✅ KEEP - Most complete, well-documented, has builder pattern

#### 2. `crates/universal-patterns/src/traits/plugin_canonical.rs` 
```rust
pub struct CanonicalPluginMetadata {
    pub id: String,  // ⚠️ String not Uuid
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub plugin_type: CanonicalPluginType,
    pub capabilities: Vec<String>,
    pub dependencies: Vec<String>,
    pub memory_limit: Option<u64>,
    pub timeout_ms: Option<u64>,
    pub enabled: bool,
    pub security_level: CanonicalSecurityLevel,
    pub config_schema: Option<serde_json::Value>,
    pub metadata: HashMap<String, serde_json::Value>,
}
```
**Status**: 🔄 MERGE - Has runtime fields (memory_limit, timeout_ms, enabled, security_level)

#### 3. `crates/universal-patterns/src/traits/plugin_traits.rs`
```rust
pub struct CanonicalPluginMetadata {
    pub id: String,  // ⚠️ String not Uuid
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub license: Option<String>,
    pub homepage: Option<String>,
    pub capabilities: Vec<String>,
    pub dependencies: Vec<CanonicalPluginDependency>,
    pub config_schema: Option<serde_json::Value>,
    pub tags: Vec<String>,
    pub min_runtime_version: Option<String>,
    pub priority: i32,
    pub enabled_by_default: bool,
}
```
**Status**: 🔄 MERGE - Has priority and enabled_by_default fields

---

## 📋 FRAGMENTED PluginMetadata LOCATIONS

### Already Deprecated (Good!) ✅
1. `crates/sdk/src/infrastructure/config.rs` - deprecated, minimal fields
2. `crates/core/plugins/src/types.rs` - deprecated
3. `crates/core/plugins/src/plugin.rs` - deprecated

### Not Yet Deprecated ⚠️
4. `crates/sdk/src/infrastructure/config_broken.rs` - **DELETE THIS FILE**
5. `crates/plugins/src/wasm_manager.rs`
6. `crates/tools/cli/src/plugins/plugin.rs`
7. `crates/core/plugins/src/zero_copy.rs` - PluginMetadataBuilder
8. `crates/core/plugins/src/plugins/dynamic.rs`
9. `crates/main/src/core/plugin_manager.rs`
10. `crates/core/interfaces/src/plugins.rs`
11. `crates/core/mcp/src/plugins/production_plugin_manager.rs`
12. `crates/core/mcp/src/plugins/types.rs` - uses String ID and PluginVersion struct
13. `crates/core/mcp/src/plugins/zero_cost_plugin.rs`

---

## 🎯 CONSOLIDATION STRATEGY

### Phase 1: Create Single Canonical Version (2-3 hours)

**Decision**: Use `crates/core/plugins/src/canonical_metadata.rs` as PRIMARY

**Actions**:
1. ✅ Keep `core/plugins/src/canonical_metadata.rs` as the main definition
2. Merge unique fields from other canonical versions:
   - Add `memory_limit: Option<u64>` (from plugin_canonical.rs)
   - Add `timeout_ms: Option<u64>` (from plugin_canonical.rs)
   - Add `enabled: bool` (from plugin_canonical.rs, default: true)
   - Add `security_level: CanonicalSecurityLevel` (from plugin_canonical.rs)
   - Add `priority: i32` (from plugin_traits.rs, default: 0)
   - Add `enabled_by_default: bool` (from plugin_traits.rs, default: true)
3. Ensure builder pattern supports all fields
4. Add comprehensive documentation
5. Export from `squirrel_plugins` crate root

### Phase 2: Remove Duplicate Canonicals (1-2 hours)

**Replace in `universal-patterns/src/traits/plugin_canonical.rs`**:
```rust
// Re-export from core plugins
pub use squirrel_plugins::canonical_metadata::CanonicalPluginMetadata;
```

**Replace in `universal-patterns/src/traits/plugin_traits.rs`**:
```rust
// Re-export from core plugins
pub use squirrel_plugins::canonical_metadata::CanonicalPluginMetadata;
```

### Phase 3: Delete Broken File (IMMEDIATE)

```bash
rm crates/sdk/src/infrastructure/config_broken.rs
```

Update `crates/sdk/src/infrastructure/mod.rs` to remove the import.

### Phase 4: Deprecate Remaining PluginMetadata (2-3 hours)

For each non-deprecated PluginMetadata:
1. Add deprecation attribute with clear message
2. Add type alias pointing to canonical version
3. Add conversion impl if needed

Example:
```rust
#[deprecated(
    since = "4.2.0",
    note = "Use squirrel_plugins::canonical_metadata::CanonicalPluginMetadata"
)]
pub struct PluginMetadata {
    // ... existing fields
}

// Migration helper
pub type CanonicalPluginMetadata = squirrel_plugins::canonical_metadata::CanonicalPluginMetadata;

impl From<PluginMetadata> for CanonicalPluginMetadata {
    fn from(old: PluginMetadata) -> Self {
        CanonicalPluginMetadata::new(
            &old.name,
            &old.version,
            &old.description,
            &old.author,
        )
        // ... map other fields
    }
}
```

### Phase 5: Update All Imports (3-4 hours)

Search and replace pattern:
```bash
# Find all imports
grep -r "use.*PluginMetadata" crates/*/src/

# Update to canonical version
# This will be done file by file with testing
```

### Phase 6: Testing & Validation (1-2 hours)

1. Run full test suite after each major change
2. Verify no compilation errors
3. Check that all plugin-related tests pass
4. Update integration tests if needed

---

## 📝 EXECUTION PLAN

### Step 1: Enhance Canonical Metadata ✅ IN PROGRESS
- [ ] Read complete canonical_metadata.rs
- [ ] Add missing fields from other canonical versions
- [ ] Update builder pattern
- [ ] Add conversion impls from String ID to Uuid

### Step 2: Delete Broken File
- [ ] Delete config_broken.rs
- [ ] Update sdk/infrastructure/mod.rs
- [ ] Verify build still works

### Step 3: Remove Duplicate Canonicals
- [ ] Replace plugin_canonical.rs version with re-export
- [ ] Replace plugin_traits.rs version with re-export
- [ ] Update any dependent code
- [ ] Test compilation

### Step 4: Deprecate Remaining
- [ ] Add deprecations to 10 remaining PluginMetadata structs
- [ ] Add type aliases
- [ ] Add conversion impls where needed

### Step 5: Migrate Usage
- [ ] Update imports in key files
- [ ] Run tests after each file
- [ ] Document any breaking changes

### Step 6: Cleanup
- [ ] Remove all deprecated definitions (after stabilization)
- [ ] Update documentation
- [ ] Add migration guide

---

## ⏰ TIME TRACKING

| Phase | Estimated | Actual | Status |
|-------|-----------|--------|--------|
| Phase 1: Enhance Canonical | 2-3h | - | IN PROGRESS |
| Phase 2: Remove Duplicates | 1-2h | - | PENDING |
| Phase 3: Delete Broken | 0.5h | - | PENDING |
| Phase 4: Deprecate | 2-3h | - | PENDING |
| Phase 5: Migrate Usage | 3-4h | - | PENDING |
| Phase 6: Testing | 1-2h | - | PENDING |
| **TOTAL** | **10-16h** | - | - |

---

## 🎯 SUCCESS CRITERIA

✅ Single `CanonicalPluginMetadata` definition in `core/plugins/src/canonical_metadata.rs`  
✅ All other locations either deprecated or re-exported  
✅ `config_broken.rs` deleted  
✅ All tests passing  
✅ No compilation errors  
✅ Clear migration guide for external users  
✅ Builder pattern for ergonomic construction  

---

## 🚧 RISKS & MITIGATION

### Risk 1: Breaking Changes
**Mitigation**: Keep deprecated versions for 2-3 releases, provide clear migration path

### Risk 2: Field Incompatibility
**Mitigation**: Make all new fields optional with sensible defaults

### Risk 3: Test Failures
**Mitigation**: Test incrementally after each major change

### Risk 4: External Dependencies
**Mitigation**: Check if any external crates depend on specific PluginMetadata versions

---

*Plan Created: October 1, 2025*  
*Last Updated: October 1, 2025*  
*Status: READY TO EXECUTE* 