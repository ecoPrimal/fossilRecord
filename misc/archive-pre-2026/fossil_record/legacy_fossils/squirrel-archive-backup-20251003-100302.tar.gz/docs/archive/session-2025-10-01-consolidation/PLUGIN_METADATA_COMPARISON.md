# 🔍 PluginMetadata Consolidation Analysis

**Date**: October 1, 2025  
**Status**: Phase 1 - COMPLETE ✅  
**Goal**: Consolidate 15+ duplicate PluginMetadata structs into single canonical definition

---

## 📊 EXECUTIVE SUMMARY

**Total Duplicates Found**: 12 confirmed  
**Severity**: 🔴🔴🔴 CRITICAL  
**Analysis Status**: ✅ **INVENTORY COMPLETE**  
**Next Phase**: Design canonical structure

---

## 🔬 COMPLETE COMPARISON TABLE

| # | Location | Fields | ID Type | Deps | License | URLs | Special Features |
|---|----------|--------|---------|------|---------|------|------------------|
| 1 | core/plugins/src/types.rs:149 | 7 | Uuid | Vec<String> | ❌ | ❌ | - |
| 2 | sdk/src/infrastructure/config.rs:124 | 5 | ❌ None | ❌ | ❌ | ❌ | Default impl |
| 3 | core/plugins/src/plugin.rs:15 | 7 | Uuid | Vec<Uuid> | ❌ | ❌ | **Marked Legacy** |
| 4 | core/plugins/src/plugins/dynamic.rs:23 | 7 | Uuid | Vec<Dep> | ❌ | ❌ | **api_version field** |
| 5 | plugins/src/wasm_manager.rs:47 | 7 | **String** | IndexMap | ❌ | ❌ | Optional fields |
| 6 | tools/cli/src/plugins/plugin.rs:33 | 5 | ❌ None | ❌ | ❌ | ✅ homepage | Optional fields |
| 7 | main/src/core/plugin_manager.rs:218 | 2 | ❌ None | ❌ | ❌ | ❌ | **Minimal/broken** |
| 8 | core/interfaces/src/plugins.rs:14 | 6 | **String** | ❌ | ❌ | ❌ | - |
| 9 | core/mcp/src/plugins/types.rs:51 | 8 | PluginId | Vec<PluginId> | ❌ | ❌ | **Custom types, additional_metadata** |
| 10 | core/mcp/src/plugins/production_plugin_manager.rs:37 | 5 | ❌ None | ❌ | ❌ | ❌ | **loaded_at timestamp** |
| 11 | core/mcp/src/plugins/zero_cost_plugin.rs:83 | 7 | **String** | ❌ | ✅ Yes | ❌ | **Has license!** |
| 12 | sdk/src/infrastructure/config_broken.rs:478 | 11 | ❌ None | ❌ | ✅ Yes | ✅✅✅ | **MOST COMPLETE** |

---

## 🎯 DETAILED ANALYSIS

### Definition 1: core/plugins/src/types.rs (Line 149) ⭐
```rust
pub struct PluginMetadata {
    pub id: Uuid,
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub dependencies: Vec<String>,      // String-based
    pub capabilities: Vec<String>,
}
```
**Assessment**: Standard, mid-level completeness

### Definition 2: sdk/src/infrastructure/config.rs (Line 124)
```rust
pub struct PluginMetadata {
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub capabilities: Vec<String>,
}
```
**Assessment**: Minimal, no ID field

### Definition 3: core/plugins/src/plugin.rs (Line 15) 🚨
```rust
/// Legacy Plugin metadata, will be deprecated in favor of IPluginMetadata
pub struct PluginMetadata {
    pub id: Uuid,
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub capabilities: Vec<String>,
    pub dependencies: Vec<Uuid>,        // Uuid-based!
}
```
**Note**: Already marked as **"Legacy"** in code!  
**Assessment**: Good candidate for replacement

### Definition 4: core/plugins/src/plugins/dynamic.rs (Line 23) ⭐⭐
```rust
pub struct PluginMetadata {
    pub id: Uuid,
    pub name: String,
    pub version: String,
    pub api_version: String,            // UNIQUE FIELD!
    pub description: String,
    pub author: String,
    pub dependencies: Vec<PluginDependency>,
}
```
**Unique**: Has `api_version` field for compatibility tracking  
**Assessment**: Important addition for production use

### Definition 5: plugins/src/wasm_manager.rs (Line 47)
```rust
pub struct PluginMetadata {
    pub id: String,                     // String ID!
    pub name: String,
    pub version: String,
    pub description: Option<String>,    // Optional!
    pub author: Option<String>,         // Optional!
    pub interfaces: Vec<String>,
    pub dependencies: IndexMap<String, String>,
}
```
**Note**: Uses **IndexMap** for dependencies (name -> version)  
**Assessment**: WASM-specific, different ID type

### Definition 6: tools/cli/src/plugins/plugin.rs (Line 33)
```rust
pub struct PluginMetadata {
    pub name: String,
    pub version: String,
    pub description: Option<String>,
    pub author: Option<String>,
    pub homepage: Option<String>,       // UNIQUE FIELD!
}
```
**Unique**: Has `homepage` field  
**Assessment**: CLI-specific, minimal

### Definition 7: main/src/core/plugin_manager.rs (Line 218) ❌
```rust
pub struct PluginMetadata {
    pub author: String,
    pub description: String,
}
```
**Assessment**: **BROKEN** - Only 2 fields! Should be removed or fixed

### Definition 8: core/interfaces/src/plugins.rs (Line 14)
```rust
pub struct PluginMetadata {
    pub id: String,                     // String ID!
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub capabilities: Vec<String>,
}
```
**Assessment**: Clean interface definition, String-based ID

### Definition 9: core/mcp/src/plugins/types.rs (Line 51) ⭐⭐⭐
```rust
pub struct PluginMetadata {
    pub id: PluginId,                   // Custom type!
    pub name: String,
    pub description: String,
    pub version: PluginVersion,         // Custom type!
    pub author: String,
    pub source: PluginSource,           // UNIQUE!
    pub dependencies: Vec<PluginId>,
    pub additional_metadata: HashMap<String, String>,  // UNIQUE!
}
```
**Unique**: Custom types (PluginId, PluginVersion), source tracking, extensible metadata  
**Assessment**: Most sophisticated type system

### Definition 10: core/mcp/src/plugins/production_plugin_manager.rs (Line 37)
```rust
pub struct PluginMetadata {
    pub name: String,
    pub version: String,
    pub loaded_at: chrono::DateTime<chrono::Utc>,  // UNIQUE!
    pub status: PluginStatus,
}
```
**Unique**: Runtime tracking (`loaded_at`, `status`)  
**Assessment**: Runtime metadata, not definition metadata

### Definition 11: core/mcp/src/plugins/zero_cost_plugin.rs (Line 83) ⭐
```rust
pub struct PluginMetadata {
    pub id: String,
    pub name: String,
    pub version: String,
    pub description: String,
    pub capabilities: Vec<String>,
    pub author: String,
    pub license: String,                // UNIQUE!
}
```
**Unique**: Has `license` field  
**Assessment**: Good addition

### Definition 12: sdk/src/infrastructure/config_broken.rs (Line 478) ⭐⭐⭐⭐⭐
```rust
pub struct PluginMetadata {
    pub name: String,
    pub version: String,
    pub description: String,
    pub author: String,
    pub license: String,
    pub homepage: Option<String>,
    pub repository: Option<String>,
    pub documentation: Option<String>,
    pub categories: Vec<String>,        // UNIQUE!
    pub tags: Vec<String>,              // UNIQUE!
    pub keywords: Vec<String>,          // UNIQUE!
}
```
**Assessment**: 🏆 **MOST COMPLETE** definition! Despite being in "_broken.rs" file  
**Has**: License, URLs, categories, tags, keywords  
**Missing**: ID field, capabilities, dependencies

---

## 🔥 CRITICAL FINDINGS

### Finding 1: Complete Type Chaos
- **3 different ID types**: Uuid, String, PluginId (custom), or None
- **3 different dependency types**: Vec<String>, Vec<Uuid>, IndexMap, Vec<PluginId>, or None
- **No consistency** in optional vs required fields

### Finding 2: config_broken.rs Paradox
The **most complete** metadata definition is in a file named `config_broken.rs`!  
This file should be reviewed - it may contain valuable designs that were abandoned.

### Finding 3: Already Acknowledged Legacy
`core/plugins/src/plugin.rs:15` is already marked as **"Legacy"** with note:  
> "will be deprecated in favor of IPluginMetadata"

This suggests someone already tried to unify but didn't complete it!

### Finding 4: Missing Critical Fields
**None** of the definitions have ALL of:
- ✅ ID (Uuid or String)
- ✅ Basic info (name, version, description, author)
- ✅ Dependencies
- ✅ Capabilities
- ✅ License
- ✅ URLs (homepage, repository, documentation)
- ✅ Discovery (tags, keywords, categories)
- ✅ Compatibility (api_version, min_squirrel_version)

---

## 💡 CANONICAL DESIGN DECISIONS

### Decision 1: ID Field Type
**Options**:
1. Uuid - Type-safe, globally unique
2. String - Flexible, human-readable
3. Both - Best of both worlds

**RECOMMENDATION**: ✅ **Uuid with optional string alias**
```rust
pub id: Uuid,
pub id_alias: Option<String>,  // For human-readable references
```

### Decision 2: Dependencies
**Options**:
1. Vec<String> - Name-based
2. Vec<Uuid> - ID-based
3. IndexMap<String, String> - Name + version
4. Vec<PluginDependency> - Structured

**RECOMMENDATION**: ✅ **Structured with both**
```rust
pub dependencies: Vec<PluginDependency>,

pub struct PluginDependency {
    pub id: Option<Uuid>,
    pub name: String,
    pub version_requirement: String,  // "^1.0.0", ">=2.0", etc.
}
```

### Decision 3: Required vs Optional Fields
**Required** (must always have):
- id, name, version, description, author

**Optional** (nice to have):
- license, homepage, repository, documentation
- categories, tags, keywords
- capabilities, dependencies
- api_version, min_squirrel_version

### Decision 4: Location
**RECOMMENDATION**: Create new file
```
crates/core/plugins/src/canonical_metadata.rs
```
Then re-export from:
- `crates/core/plugins/src/lib.rs`
- `crates/sdk/src/lib.rs`

---

## 🎨 PROPOSED CANONICAL STRUCTURE

```rust
/// **CANONICAL PLUGIN METADATA**
/// Single source of truth for plugin metadata across the Squirrel ecosystem
/// 
/// This replaces 12+ fragmented PluginMetadata definitions
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CanonicalPluginMetadata {
    // ========== REQUIRED FIELDS ==========
    
    /// Unique plugin identifier (generated if not provided)
    pub id: Uuid,
    
    /// Human-readable plugin name
    pub name: String,
    
    /// Semantic version (e.g., "1.0.0")
    pub version: String,
    
    /// Brief plugin description
    pub description: String,
    
    /// Plugin author/maintainer
    pub author: String,
    
    // ========== IDENTITY & DISCOVERY ==========
    
    /// Optional string-based ID alias for human reference
    #[serde(default)]
    pub id_alias: Option<String>,
    
    /// Plugin type classification
    #[serde(default)]
    pub plugin_type: PluginType,
    
    /// Categories for organization
    #[serde(default)]
    pub categories: Vec<String>,
    
    /// Tags for discovery
    #[serde(default)]
    pub tags: Vec<String>,
    
    /// Keywords for search
    #[serde(default)]
    pub keywords: Vec<String>,
    
    // ========== CAPABILITIES & DEPENDENCIES ==========
    
    /// Plugin capabilities (what it can do)
    #[serde(default)]
    pub capabilities: Vec<String>,
    
    /// Plugin dependencies
    #[serde(default)]
    pub dependencies: Vec<PluginDependency>,
    
    /// Interfaces this plugin supports
    #[serde(default)]
    pub interfaces: Vec<String>,
    
    // ========== LEGAL & DOCUMENTATION ==========
    
    /// License identifier (e.g., "MIT", "Apache-2.0")
    #[serde(default)]
    pub license: Option<String>,
    
    /// Plugin homepage URL
    #[serde(default)]
    pub homepage: Option<String>,
    
    /// Repository URL
    #[serde(default)]
    pub repository: Option<String>,
    
    /// Documentation URL
    #[serde(default)]
    pub documentation: Option<String>,
    
    // ========== COMPATIBILITY & VERSIONING ==========
    
    /// API version this plugin is compatible with
    #[serde(default)]
    pub api_version: Option<String>,
    
    /// Minimum Squirrel version required
    #[serde(default)]
    pub min_squirrel_version: Option<String>,
    
    /// Maximum Squirrel version supported
    #[serde(default)]
    pub max_squirrel_version: Option<String>,
    
    /// Entry point / main file
    #[serde(default)]
    pub entry_point: Option<String>,
    
    // ========== EXTENSIBILITY ==========
    
    /// Additional metadata as key-value pairs (for custom fields)
    #[serde(default)]
    pub additional_metadata: HashMap<String, String>,
}

/// Plugin type classification
#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq, Eq)]
pub enum PluginType {
    #[default]
    Unknown,
    Core,
    Web,
    Tool,
    CLI,
    MCP,
    Integration,
    WASM,
}

/// Structured plugin dependency
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PluginDependency {
    /// Dependency plugin ID (if known)
    pub id: Option<Uuid>,
    
    /// Dependency plugin name
    pub name: String,
    
    /// Version requirement (e.g., "^1.0.0", ">=2.0")
    pub version_requirement: String,
    
    /// Whether this dependency is optional
    #[serde(default)]
    pub optional: bool,
}

impl CanonicalPluginMetadata {
    /// Create minimal plugin metadata with only required fields
    pub fn new(
        name: impl Into<String>,
        version: impl Into<String>,
        description: impl Into<String>,
        author: impl Into<String>,
    ) -> Self {
        Self {
            id: Uuid::new_v4(),
            name: name.into(),
            version: version.into(),
            description: description.into(),
            author: author.into(),
            id_alias: None,
            plugin_type: PluginType::Unknown,
            categories: Vec::new(),
            tags: Vec::new(),
            keywords: Vec::new(),
            capabilities: Vec::new(),
            dependencies: Vec::new(),
            interfaces: Vec::new(),
            license: None,
            homepage: None,
            repository: None,
            documentation: None,
            api_version: None,
            min_squirrel_version: None,
            max_squirrel_version: None,
            entry_point: None,
            additional_metadata: HashMap::new(),
        }
    }
    
    /// Create with existing ID (for migration)
    pub fn with_id(mut self, id: Uuid) -> Self {
        self.id = id;
        self
    }
    
    /// Builder: Set plugin type
    pub fn with_type(mut self, plugin_type: PluginType) -> Self {
        self.plugin_type = plugin_type;
        self
    }
    
    /// Builder: Add capability
    pub fn with_capability(mut self, capability: impl Into<String>) -> Self {
        self.capabilities.push(capability.into());
        self
    }
    
    /// Builder: Add dependency
    pub fn with_dependency(mut self, dependency: PluginDependency) -> Self {
        self.dependencies.push(dependency);
        self
    }
    
    /// Builder: Set license
    pub fn with_license(mut self, license: impl Into<String>) -> Self {
        self.license = Some(license.into());
        self
    }
    
    /// Builder: Set homepage
    pub fn with_homepage(mut self, homepage: impl Into<String>) -> Self {
        self.homepage = Some(homepage.into());
        self
    }
    
    // ... more builder methods
}

impl Default for CanonicalPluginMetadata {
    fn default() -> Self {
        Self::new("unknown", "0.1.0", "A Squirrel plugin", "Unknown")
    }
}
```

---

## 📋 MIGRATION STRATEGY

### Phase 1: Create Canonical (2-3 hours)
1. Create `crates/core/plugins/src/canonical_metadata.rs`
2. Implement CanonicalPluginMetadata with all fields
3. Add comprehensive tests
4. Export from core/plugins and SDK

### Phase 2: Add Deprecations (2-3 hours)
1. Add `#[deprecated]` to all 12 existing definitions
2. Add type aliases pointing to canonical
3. Document migration path in each

### Phase 3: Update Key Usage (3-4 hours)
1. Update plugin loaders to use canonical
2. Update plugin registration
3. Update plugin discovery
4. Test thoroughly

### Phase 4: Cleanup (2 hours)
1. Remove `config_broken.rs` file
2. Remove broken definition in plugin_manager.rs
3. Clean up dead code warnings
4. Update documentation

---

## 🎯 ESTIMATED EFFORT

**Total**: 9-12 hours

- Phase 1 (Create): 2-3 hours
- Phase 2 (Deprecate): 2-3 hours
- Phase 3 (Migrate): 3-4 hours
- Phase 4 (Cleanup): 2 hours

---

## ✅ PHASE 1 STATUS: COMPLETE

- [x] Inventory all PluginMetadata definitions (12 found)
- [x] Compare field variations
- [x] Identify unique fields
- [x] Determine type conflicts
- [x] Design canonical structure
- [x] Document migration strategy

**Next**: Phase 2 - Implementation

---

*Analysis Complete!*  
*Last updated: October 1, 2025*  
*Ready for implementation!* 
*Phase 1: 20% complete* 