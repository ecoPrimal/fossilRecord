# 🎯 UNIFICATION ACTION PLAN - IMMEDIATE NEXT STEPS

**Date**: October 1, 2025  
**Current Status**: 99% Unified  
**Target**: 100% Unification  
**Timeline**: 1-2 weeks

---

## 🔴 PRIORITY 1: IMMEDIATE FIXES (2-4 hours)

### 1.1 Fix Compilation Error ✅ DONE
- **File**: `crates/universal-patterns/src/security/client.rs:91`
- **Issue**: `SecurityConfig` should be `UnifiedSecurityConfig`
- **Status**: ✅ Fixed
- **Time**: 5 minutes

### 1.2 Consolidate Duplicate PluginError Types (1-2 hours)
**Issue**: Duplicate PluginError definitions in SDK and core/plugins

**Files to Review**:
```
crates/sdk/src/infrastructure/error/core.rs
crates/core/plugins/src/errors.rs
```

**Action**:
1. Compare the two PluginError enums
2. Keep the more comprehensive version in SDK
3. Re-export from SDK in core/plugins
4. Update all imports

**Expected Impact**: -10 to -15 error type definitions

### 1.3 Document Adapter Purposes (1 hour)
**Issue**: Multiple adapter implementations without clear documentation

**Files to Document**:
```
crates/main/src/universal/unified_adapter.rs
crates/main/src/universal/evolved_adapter.rs
crates/ecosystem-api/src/universal_adapter/
```

**Action**:
Add clear module-level documentation explaining:
- Purpose and use case for each adapter
- When to use which adapter
- Relationships between adapters
- Migration path if consolidation is planned

---

## 🟡 PRIORITY 2: SHORT-TERM CONSOLIDATION (8-12 hours)

### 2.1 Security Trait Migration (4-6 hours)
**Issue**: 26 deprecation warnings for SecurityProvider traits

**Goal**: Complete migration to `CanonicalSecurityProvider`

**Action Plan**:
1. Find all uses of deprecated SecurityProvider (2 hours)
   ```bash
   rg "SecurityProvider" --type rust | grep -v "CanonicalSecurityProvider"
   ```

2. Update trait implementations (2 hours)
   - Update trait bounds
   - Update method signatures
   - Test each change

3. Remove deprecation attributes (1 hour)

4. Verify all tests pass (1 hour)

**Expected Impact**: -26 deprecation warnings

### 2.2 Handler Trait Consolidation (4-6 hours)
**Issue**: 19 Handler trait variations with potential duplicates

**Handlers to Review**:
```rust
CommandHandler       (5 locations)
EventHandler         (6 locations)
MessageHandler       (4 locations)
ConnectionHandler    (3 locations)
ShutdownHandler      (1 location)
```

**Action Plan**:
1. Catalog each Handler trait (1 hour)
   - Document purpose
   - List implementations
   - Identify true duplicates vs. domain specializations

2. Consolidate duplicates (2-3 hours)
   - Keep domain-specific handlers (MCP, Command, Event are separate)
   - Merge true duplicates
   - Update imports

3. Test and verify (1-2 hours)

**Expected Impact**: -3 to -5 duplicate trait definitions

### 2.3 Adapter Layer Cleanup (4-6 hours)
**Issue**: Multiple adapter implementations with unclear relationships

**Investigation Phase** (2 hours):
1. Document UnifiedUniversalAdapter purpose and usage
2. Document EvolvedUniversalAdapter purpose and usage
3. Document ecosystem-api adapter purpose and usage
4. Identify overlaps and redundancies

**Decision Phase** (1 hour):
- Determine if all three are needed
- Plan consolidation if appropriate
- Document decision

**Implementation Phase** (1-3 hours):
- Consolidate if decided
- Update documentation
- Test changes

---

## 🟢 PRIORITY 3: MEDIUM-TERM POLISH (12-20 hours)

### 3.1 Constants Final Consolidation (8-12 hours)
**Goal**: Achieve 100% constants consolidation

**Phase 1: Audit** (4-6 hours)
```bash
# Find magic numbers
rg "\b[0-9]{2,}\b" --type rust crates/core crates/main | grep -v "//" | grep -v "#"

# Find hardcoded strings
rg "\"http[s]?://" --type rust crates/

# Find timeout values
rg "timeout.*[0-9]+" --type rust crates/
```

**Phase 2: Consolidate** (2-3 hours)
- Move identified constants to `universal-constants`
- Organize by category (timeouts, endpoints, limits, etc.)

**Phase 3: Update References** (2-3 hours)
- Replace magic numbers with named constants
- Update imports

**Expected Impact**: 100% constants consolidation

### 3.2 Test Config Migration (2-3 hours)
**Issue**: 183 test/bench references still using fragmented configs

**Action**:
```bash
# Find test config usage
rg "ChaosConfig|E2EConfig|DeploymentConfig|PerformanceConfig" tests/ benches/

# Replace with UnifiedSquirrelConfig subsections
# This is non-critical and can be done incrementally
```

**Priority**: LOW (non-blocking for production)

### 3.3 Documentation Improvements (2-4 hours)
**Goal**: Address 26 missing documentation warnings

**Action**:
1. Run `cargo doc --workspace 2>&1 | grep "missing documentation"`
2. Add documentation to flagged items
3. Focus on public API surface
4. Private items can use `#[allow(missing_docs)]` if appropriate

### 3.4 Async Lifetime Resolution (4-6 hours)
**Issue**: 4 async lifetime TODOs in MCP code

**Action**:
1. Research async trait lifetime best practices
2. Design proper lifetime annotations
3. Implement and test
4. Remove TODO comments

**Priority**: MEDIUM (workarounds exist)

---

## ⚪ PRIORITY 4: NICE-TO-HAVE (Optional)

### 4.1 Remove Re-export Compatibility Layers (6-7 hours)
**Goal**: Remove migration helper re-exports

**Files**:
```
crates/main/src/universal/adapter.rs
crates/main/src/universal/types.rs
```

**Action**:
1. Audit usage of re-exported names (2 hours)
2. Update consumers to use canonical imports (3-4 hours)
3. Remove re-export layers (1 hour)

**When**: After 2-3 months of stability with current system

### 4.2 Enhanced Error Context (4-6 hours)
**Goal**: Add richer context to domain bridge errors

**Action**:
- Review domain_bridges in canonical-errors
- Add structured context fields
- Improve error messages

### 4.3 Dead Code Cleanup (2-3 hours)
**Issue**: 18 dead code warnings

**Action**:
1. Review each dead code warning
2. Determine if code is:
   - Intentional API (add `#[allow(dead_code)]` with comment)
   - Feature-gated (add proper cfg attributes)
   - Truly unused (remove)

---

## 📊 PROGRESS TRACKING

### Week 1 Goals
- [x] Fix SecurityConfig compilation error
- [ ] Consolidate duplicate PluginError types
- [ ] Document adapter purposes
- [ ] Complete security trait migration
- [ ] Handler trait consolidation

**Target**: 99.5% unification

### Week 2 Goals  
- [ ] Constants final consolidation
- [ ] Adapter layer cleanup
- [ ] Documentation improvements
- [ ] Async lifetime resolution

**Target**: 100% unification

---

## 🎯 SUCCESS METRICS

### Quantitative
- Warning count: 87 → <20 (target: 77% reduction)
- Error type count: 45 → <30 (target: 33% reduction)
- Handler traits: 19 → <15 (target: 21% reduction)
- Constants consolidation: 92% → 100%

### Qualitative
- ✅ Clear adapter architecture documentation
- ✅ Complete security trait migration
- ✅ World-class code quality maintained
- ✅ Zero compilation breaks

---

## 🛠️ TOOLS & COMMANDS

### Find Patterns
```bash
# Find all error types
rg "pub enum.*Error" --type rust

# Find all config types
rg "pub struct.*Config" --type rust

# Find handler traits
rg "pub trait.*Handler" --type rust

# Find adapter implementations
rg "Adapter" --type rust -g '!target'

# Find TODOs
rg "TODO|FIXME" --type rust
```

### Build & Test
```bash
# Check compilation
cargo build --workspace

# Count warnings
cargo build --workspace 2>&1 | grep -i "warning:" | wc -l

# Run specific crate tests
cargo test -p universal-patterns
cargo test -p canonical-errors
cargo test -p canonical-config
```

---

## 📞 DECISION POINTS

### Adapter Consolidation Decision
**Question**: Should we consolidate UnifiedUniversalAdapter and EvolvedUniversalAdapter?

**Considerations**:
- Are they serving different use cases?
- Is there significant code duplication?
- What's the migration impact?

**Timeline**: Decide by end of Week 1

### Test Config Migration Timing
**Question**: Migrate test configs now or incrementally?

**Decision**: INCREMENTAL
- Test configs don't block production
- Can be done as tests are modified
- Focus on production code first

---

## 🎓 PRINCIPLES

### During Unification Work
1. **Zero Breaks**: Never break compilation
2. **Test After Each Change**: Verify immediately
3. **Document Decisions**: Record why choices were made
4. **Incremental Progress**: Small, verified steps
5. **Production First**: Prioritize production code over tests

### Quality Standards
1. Files must stay under 2000 lines
2. Use canonical patterns consistently
3. Document public APIs
4. Test new consolidations
5. Track progress in reports

---

## 🎉 CELEBRATION MILESTONES

### 99.5% Unification (End of Week 1)
- Security trait migration complete
- Handler traits consolidated
- Adapter architecture documented

### 100% Unification (End of Week 2)
- Constants fully consolidated
- All Priority 1-3 items complete
- World-class architecture achieved

---

*Action Plan Created: October 1, 2025*  
*Status: READY FOR EXECUTION*  
*Next Review: After Priority 1 completion* 