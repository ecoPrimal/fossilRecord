# 🔍 FRAGMENTATION DISCOVERIES - October 1, 2025

**Assessment Date**: October 1, 2025  
**Purpose**: Catalog all major code duplication and fragmentation for systematic cleanup  
**Status**: ACTIVE CLEANUP IN PROGRESS

---

## 📊 EXECUTIVE SUMMARY

### Critical Fragmentation Hotspots
| Type | Count | Status | Priority |
|------|-------|--------|----------|
| SecurityConfig structs | 11+ | 4/11 renamed | 🔴 HIGH |
| PluginMetadata structs | 15+ | Not started | 🔴 HIGH |
| PluginError enums | 2+ | Not started | 🔴 HIGH |
| Handler traits | 19+ | Not started | 🟡 MEDIUM |
| CorePlugin/ToolPlugin/WebPluginExt traits | 5+ | Not started | 🟡 MEDIUM |
| Other Config structs | 100+ | Ongoing | 🟢 LOW |

---

## 🔥 CRITICAL: SecurityConfig Fragmentation

### Discovered: 11+ Duplicate SecurityConfig Structs

**Impact**: Causes compilation ambiguity, maintenance burden, unclear which config to use

#### ✅ COMPLETED - Renamed & Deprecated (4/11)

1. **ecosystem-api/src/types/security.rs**
   ```rust
   SecurityConfig → ServiceSecurityConfig
   Purpose: Service-level security configuration
   Fields: require_auth, min_security_level, allowed_auth_methods, rate_limits
   ```

2. **main/src/ecosystem/types.rs**
   ```rust
   SecurityConfig → EcosystemSecurityConfig
   Purpose: Ecosystem-level operations security
   Fields: authentication_required, authorization_level, encryption_enabled
   ```

3. **main/src/security/config.rs**
   ```rust
   SecurityConfig → SecurityServiceCoordination
   Purpose: BearDog security service integration
   Fields: security_service_endpoint, enabled, timeout_seconds
   ```

4. **core/mcp/src/security/manager.rs**
   ```rust
   SecurityConfig → MCPSecurityConfig
   Purpose: MCP security manager configuration
   Fields: enable_audit, enable_encryption, enable_rbac, token_expiry_minutes
   ```

#### ⏳ PENDING - To Be Renamed (7/11)

5. **core/mcp/src/config/mod.rs** - SecurityConfig
   - Purpose: TBD
   - Action: Rename to MCPCoreSecurityConfig or consolidate

6. **core/mcp/src/enhanced/workflow/types.rs** - SecurityConfig
   - Purpose: Workflow security configuration
   - Action: Rename to WorkflowSecurityConfig

7. **core/mcp/src/enhanced/config_manager.rs** - SecurityConfig
   - Purpose: Enhanced config manager security
   - Action: Rename or consolidate

8. **core/mcp/src/enhanced/service_composition/types.rs** - SecurityConfig
   - Purpose: Service composition security
   - Action: Rename to CompositionSecurityConfig

9. **core/mcp/src/enhanced/service_composition/types/config.rs** - SecurityConfig
   - Purpose: Duplicate of #8?
   - Action: Check if duplicate, consolidate if yes

10. **canonical-config/src/security.rs** - SecurityConfig (legacy)
    - Purpose: Old canonical config (superseded by UnifiedSecurityConfig)
    - Action: Remove file if deprecated

11. **TBD** - May be others in generated code

### Recommended Actions
1. ✅ Continue renaming remaining 7 instances
2. ✅ Check for duplicate definitions within same namespace
3. ✅ Document each renamed type's purpose
4. ✅ Add deprecation warnings with migration guidance
5. 🔄 Eventually consolidate related types into UnifiedSecurityConfig sub-modules

---

## 🔥 CRITICAL: PluginMetadata Fragmentation

### Discovered: 15+ Duplicate PluginMetadata Structs

**Impact**: SEVERE - Complete confusion about canonical plugin metadata structure

#### Locations Found

1. **sdk/src/infrastructure/config.rs** - PluginMetadata
2. **sdk/src/infrastructure/config_broken.rs** - PluginMetadata (BROKEN FILE!)
3. **plugins/src/wasm_manager.rs** - PluginMetadata
4. **tools/cli/src/plugins/plugin.rs** - PluginMetadata
5. **core/plugins/src/plugin.rs** - PluginMetadata
6. **core/plugins/src/zero_copy.rs** - PluginMetadataBuilder
7. **core/plugins/src/plugins/dynamic.rs** - PluginMetadata
8. **core/plugins/src/plugin_v2.rs** - (likely has PluginMetadata)
9. **core/plugins/src/types.rs** - PluginMetadata
10. **main/src/core/plugin_manager.rs** - PluginMetadata
11. **core/interfaces/src/plugins.rs** - PluginMetadata
12. **core/mcp/src/plugins/production_plugin_manager.rs** - PluginMetadata
13. **core/mcp/src/plugins/types.rs** - PluginMetadata
14. **core/mcp/src/plugins/zero_cost_plugin.rs** - PluginMetadata
15. **Additional**: Likely more in other modules

### Severity Assessment
- 🔴 **CRITICAL**: This is the most severe fragmentation found
- 🔴 **15+ definitions** of the same core type
- 🔴 **No single source of truth** for plugin metadata
- 🔴 **High maintenance burden** - changes require updating 15+ locations
- 🔴 **Compilation ambiguity** - which PluginMetadata to import?

### Recommended Strategy

#### Phase 1: Identify Canonical Definition (1-2 hours)
1. Compare all PluginMetadata structs
2. Identify the most complete/modern version
3. Document fields in each version
4. Determine if they're truly identical or domain-specific

#### Phase 2: Establish Single Source (2-3 hours)
1. Choose canonical location (likely `core/plugins/src/types.rs` or `sdk`)
2. Create comprehensive CanonicalPluginMetadata
3. Add all necessary fields from various versions
4. Add clear documentation

#### Phase 3: Migrate All References (4-6 hours)
1. Add deprecated type aliases in old locations
2. Update all imports to use canonical version
3. Remove redundant definitions
4. Test compilation

#### Phase 4: Cleanup (1-2 hours)
1. Remove deprecated aliases after migration period
2. Remove dead code from _broken.rs files
3. Document in migration guide

**Total Effort**: 8-13 hours (HIGH PRIORITY)

---

## 🔥 CRITICAL: Plugin Trait Fragmentation

### Discovered: Multiple Duplicate Plugin Traits

#### CorePlugin Trait
- **Locations**: core/plugins/src/types.rs
- **Status**: Unused warning
- **Action**: Consolidate or remove

#### ToolPlugin Trait
- **Locations**: 
  - core/plugins/src/tools/mod.rs
  - core/plugins/src/types.rs
- **Status**: Unused warning
- **Action**: Consolidate to single definition or remove

#### WebPluginExt Trait
- **Locations**:
  - core/plugins/src/plugin.rs
  - core/plugins/src/plugin_v2.rs (WebPluginExtV2)
- **Status**: Unused warning
- **Action**: Consolidate or remove

### Recommended Actions
1. Determine if these traits are part of planned plugin API
2. If yes: Consolidate to single location, document, remove unused warning
3. If no: Remove entirely
4. Update plugin system to use canonical traits

**Effort**: 2-3 hours

---

## 🟡 MEDIUM: PluginError Fragmentation

### Discovered: 2+ Duplicate PluginError Enums

#### Locations
1. **sdk/src/infrastructure/error/core.rs** - PluginError
2. **core/plugins/src/errors.rs** - PluginError

### Recommended Actions
1. Compare both PluginError definitions
2. Keep more comprehensive version in SDK
3. Re-export from SDK in core/plugins
4. Update all imports
5. Document migration

**Effort**: 1-2 hours (PRIORITY 1)

---

## 🟡 MEDIUM: Handler Trait Variations

### Discovered: 19+ Handler Trait Instances

#### CommandHandler (5 locations)
- Investigation needed to determine if domain-specific or duplicates

#### EventHandler (6 locations)
- Investigation needed to determine if domain-specific or duplicates

#### MessageHandler (4 locations)
- Investigation needed to determine if domain-specific or duplicates

#### ConnectionHandler (3 locations)
- Investigation needed to determine if domain-specific or duplicates

#### ShutdownHandler (1 location)
- Appears unique

### Recommended Actions
1. Catalog each Handler trait (1 hour)
2. Identify true duplicates vs. domain specializations (1 hour)
3. Consolidate duplicates (2-3 hours)
4. Keep domain-specific variants (MCP vs Command vs Event)

**Effort**: 4-6 hours

---

## 🟢 LOW: Dead Code in Plugins

### Discovered: 23 Dead Code Warnings in squirrel-plugins

#### Unused Structs
- `DefaultPluginLoader` - Never constructed
- `WebEndpoint` - Never constructed
- `ExampleData` - Never constructed
- `PluginMetadata` - Multiple definitions, some unused
- `PluginState` enum - Never used
- `PluginDataFormat` enum - Never used

#### Unused Constants
- `PLUGIN_TYPE_CORE` - Never used
- `PLUGIN_TYPE_WEB` - Never used
- `PLUGIN_TYPE_MCP` - Never used
- `PLUGIN_TYPE_TOOL` - Never used
- `PLUGIN_TYPE_CLI` - Never used

#### Unused Fields
- `name_to_id`, `state_manager`, `discovery` - Never read
- `dependencies` - Never read
- `dependency_resolver` - Never read
- `manager` - Never read

#### Unused Methods
- `to_metadata()` - Never used
- `to_string()` - Never used
- `handle_get_example_details()` - Never used
- `handle_activate_example()` - Never used

### Recommended Actions
1. **Intentional Public API**: Add `#[allow(dead_code)]` with documentation
2. **Truly Unused**: Remove entirely
3. **Feature-Gated**: Add proper `#[cfg(...)]` attributes

**Effort**: 2-3 hours

---

## 🟢 LOW: Dead Code in canonical-modernization

### Discovered: 5 Dead Code Warnings

#### Unused Fields
- `start_time` in `CanonicalHealthMonitor` - Never read

#### Unused Methods
- `perform_health_checks()` - Never used
- `check_component_alerts()` - Never used
- `calculate_overall_status()` - Never used
- `collect_system_metrics()` - Never used

#### Unused Functions
- `generate_alert_id()` - Never used
- `get_memory_usage()` - Never used
- `get_cpu_usage()` - Never used

### Recommended Actions
1. If planned for future health monitoring: Add `#[allow(dead_code)]` with "TODO: Implement health monitoring"
2. If not needed: Remove entirely

**Effort**: 1 hour

---

## 📈 CONSOLIDATION ROADMAP

### Phase 1: Critical Fixes (This Week)
- [ ] Complete SecurityConfig consolidation (7 remaining)
- [ ] PluginMetadata consolidation (15+ files)
- [ ] PluginError consolidation (2 files)
- **Effort**: 12-18 hours

### Phase 2: Important Cleanup (Next Week)
- [ ] Handler trait consolidation (19+ files)
- [ ] Plugin trait consolidation (CorePlugin, ToolPlugin, WebPluginExt)
- [ ] Dead code cleanup (28 warnings)
- **Effort**: 8-12 hours

### Phase 3: Final Polish (Following Week)
- [ ] Remove all deprecated type aliases
- [ ] Update all documentation
- [ ] Final verification
- **Effort**: 4-6 hours

**Total Estimated Effort**: 24-36 hours (1.5-2 weeks)

---

## 🎯 SUCCESS METRICS

### Targets
- SecurityConfig types: 11 → 1 canonical + domain-specific named types
- PluginMetadata types: 15+ → 1 canonical
- PluginError types: 2+ → 1 canonical
- Handler traits: 19+ → 5-6 domain-specific (no duplicates)
- Dead code warnings: 28 → 0
- Total warnings: 120 → <20

---

## 💡 KEY INSIGHTS

### Pattern of Fragmentation
1. **Type Name Reuse**: Same name (SecurityConfig, PluginMetadata) used for different purposes
2. **Copy-Paste Development**: Developers copied structs instead of importing
3. **Lack of Central Definition**: No clear "this is the canonical version" documentation
4. **Module Isolation**: Modules developed independently without cross-checking

### Prevention Strategy
1. ✅ Clear canonical types in dedicated crates (canonical-config, canonical-errors)
2. ✅ Documentation stating "this is the single source of truth"
3. ✅ Deprecation warnings on duplicates
4. ✅ Regular fragmentation audits
5. ✅ Code review focus on imports and type definitions

---

*Document Status: ACTIVE*  
*Last Updated: October 1, 2025*  
*Consolidation Session: IN PROGRESS* 